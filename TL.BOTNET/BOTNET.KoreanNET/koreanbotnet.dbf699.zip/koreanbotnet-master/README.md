# koreanbotnet
A HTTP botnet with various options


// when i read the source code I see so many things I could do way better, I will probarly be ending up rewriting the entire thing within couple of months
