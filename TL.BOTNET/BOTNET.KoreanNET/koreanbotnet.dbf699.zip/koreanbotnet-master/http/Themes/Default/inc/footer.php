<br><br><br>
<center>
<p class="small-intro"><?php echo PanelName; ?><p>
</center>

</div>

