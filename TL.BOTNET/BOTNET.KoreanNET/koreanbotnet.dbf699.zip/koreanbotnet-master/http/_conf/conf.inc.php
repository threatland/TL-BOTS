<?php 


/*********************
Panel config
**********************/
define("BASE", "http://192.168.2.6/panel 2");

define("PanelTheme", "Default");
define("PanelName", "KoreanBotnet");

define('PanelReq', 'themes/' . PanelTheme);
define("PanelPATH", BASE . "/themes/" . PanelTheme);

define("PanelSecretURL", "hehtest");
define("PanelSecretPass", "test213");
define('PanelSecretEN', true);

/*********************
Bot config
**********************/

define("PanelBotCookie", "HeHdOngS");


/*********************
Mysql config
**********************/
define("DBhost", "127.0.0.1");
define("DBuser", "root");
define("DBpass", "");
define("DBname", "test")



?>
