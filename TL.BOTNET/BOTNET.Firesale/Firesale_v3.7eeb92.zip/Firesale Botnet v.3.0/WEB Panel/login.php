<?php 
include("sc_prefs.php");
$user = $_POST['user'];
$pas = $_POST['passwort'];
if($user != "" and $pas != ""){
 if(md5($user) == $sc_username and md5($pas) == $sc_passwort){
  setcookie("sc_cloginuser",md5($user),Time()+$sc_time);
  setcookie("sc_cloginpas",md5($pas),Time()+$sc_time);
  header("Location: ".$sc_site.$sc_goto);    
 }
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Firesale Login</title>
</head>
<body>
<div align="center">
	<table border="1" cellpadding="0" cellspacing="0" width="480" bordercolorlight="#E8FBFF" bordercolordark="#000000" bgcolor="#E8FBFF">
		<tr>
			<td valign="top">
			<table border="0" width="100%" cellpadding="0" cellspacing="3">
				<tr>
					<td width="96">
					<p align="center"><u>Firesale Login</u></td>
					<td>
					<p align="center"><?php echo $sc_site; ?></td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td valign="top">
			<div align="center">
				 <p> </p>
				<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
				<table border="0" cellspacing="7" width="100%">
					<tr>
						<td width="88"><b>Username:</b></td>
						<td>
							<input name="user" type="text" size="28">
						</td>
					</tr>
					<tr>
						<td width="88"><b>Passwort:</b></td>
						<td>
							<input name="passwort" type="password" size="28">
						</td>
					</tr>
					<tr>
						<td width="88">&nbsp;</td>
						<td>
							<input type="submit" value="Login" name="login"><br>
						</td>
					</tr>
				</table>
				</form>
			</div>
			</td>
		</tr>
		<tr>
			<td valign="top">
			<table border="0" width="100%" cellspacing="3" cellpadding="0">
				<tr>
					<td>Cookies m�ssen aktiviert sein!</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	<br>
</div>
</body>
</html>