<?php
$servername = "localhost";
$dbuser		= "root";         //MYSQLDB Username
$dbpass		= "";         //MYSQLDB Password
$database	= "botpanel";         //MYSQLDB Name
//////////////////////////////////////////////////////
$table		= "botpanel"; //Don't change!
$timer    = "40";         //Don't change!
$dead     = "432000";     //Don't change!
?>