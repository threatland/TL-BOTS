<?php
include("sc_prefs.php");
if($_COOKIE["sc_cloginuser"] != $sc_username or $_COOKIE["sc_cloginpas"] != $sc_passwort){
  header("Location: ".$sc_site.$sc_login);
}
?>