<?php
$sc_username = md5("loginname");   // Login username
$sc_passwort = md5("loginpw");     // Login password
$sc_site = "http://localhost/panel";  // Your website adress
////////////////////////////////////////////////////////////////////////////////////////////////////////////
$sc_goto = "/index.php";     //Don't change!
$sc_login = "/login.php";    //Don't change!
$sc_time = "600";            //Don't change!
?>
