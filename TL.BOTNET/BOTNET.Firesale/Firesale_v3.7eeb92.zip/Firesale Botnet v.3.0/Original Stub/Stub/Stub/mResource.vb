﻿Imports System.Text
Imports System.Runtime.InteropServices

Module mResource
    <DllImport("kernel32.dll")> _
    Private Function FindResource(ByVal hModule As IntPtr, ByVal lpName As String, ByVal lpType As String) As IntPtr
    End Function

    <DllImport("kernel32.dll")> _
    Private Function LoadResource(ByVal hModule As IntPtr, ByVal hResInfo As IntPtr) As IntPtr
    End Function

    <DllImport("kernel32.dll")> _
    Private Function LockResource(ByVal hResData As IntPtr) As IntPtr
    End Function

    <DllImport("kernel32")> _
    Private Function SizeofResource(ByVal hModule As IntPtr, ByVal hResInfo As IntPtr) As UInteger
    End Function

    Public Function getData(ByVal sFile As String, ByVal sKey As String) As String
        Dim bData(1) As Byte
        Dim hResource As IntPtr = FindResource(IntPtr.Zero, sFile, sKey)
        Dim hResourceData As IntPtr = LoadResource(IntPtr.Zero, hResource)
        Dim hResourceLock As IntPtr = LockResource(hResourceData)
        Dim uSize As UInteger = SizeOfResource(IntPtr.Zero, hResource)
        Try
            Array.Resize(bData, uSize)
            Marshal.Copy(hResourceLock, bData, 0, Convert.ToInt32(uSize))
            Return Encoding.Default.GetString(bData)
        Catch ex As Exception
        End Try
    End Function
End Module
