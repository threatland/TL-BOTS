﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("Client-Server-Laufzeitprozess")> 
<Assembly: AssemblyDescription("Hijack This")> 
<Assembly: AssemblyCompany("Trend Micro Inc")> 
<Assembly: AssemblyProduct("Hijack This")> 
<Assembly: AssemblyCopyright("Copyright © 2007 Trend Micro Inc")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("1a743f65-a303-4326-a28e-ff1847c68abe")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("2.00.00.0002")> 
<Assembly: AssemblyFileVersion("2.00.00.0002")> 

<Assembly: NeutralResourcesLanguageAttribute("")> 