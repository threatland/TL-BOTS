﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.gbAntiCodes = New System.Windows.Forms.GroupBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.cbAntiZA = New System.Windows.Forms.CheckBox
        Me.cbAntiVM = New System.Windows.Forms.CheckBox
        Me.cbAntiAA = New System.Windows.Forms.CheckBox
        Me.cbAntiBI = New System.Windows.Forms.CheckBox
        Me.cbAntiNO = New System.Windows.Forms.CheckBox
        Me.cbAntiOP = New System.Windows.Forms.CheckBox
        Me.cbAntiKA = New System.Windows.Forms.CheckBox
        Me.cbAntiVP = New System.Windows.Forms.CheckBox
        Me.cbAntiVB = New System.Windows.Forms.CheckBox
        Me.cbAntiSN = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.btnMu = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Mut = New System.Windows.Forms.TextBox
        Me.gbBypass = New System.Windows.Forms.GroupBox
        Me.cbWicenter = New System.Windows.Forms.CheckBox
        Me.cbDefender = New System.Windows.Forms.CheckBox
        Me.cbFirewall = New System.Windows.Forms.CheckBox
        Me.cbUac = New System.Windows.Forms.CheckBox
        Me.PictureBox26 = New System.Windows.Forms.PictureBox
        Me.PictureBox19 = New System.Windows.Forms.PictureBox
        Me.PictureBox13 = New System.Windows.Forms.PictureBox
        Me.PictureBox14 = New System.Windows.Forms.PictureBox
        Me.gbSpread = New System.Windows.Forms.GroupBox
        Me.cbSkype = New System.Windows.Forms.CheckBox
        Me.cbMSN = New System.Windows.Forms.CheckBox
        Me.cbIcq = New System.Windows.Forms.CheckBox
        Me.cbRar = New System.Windows.Forms.CheckBox
        Me.cbLan = New System.Windows.Forms.CheckBox
        Me.cbP2p = New System.Windows.Forms.CheckBox
        Me.cbUsb = New System.Windows.Forms.CheckBox
        Me.PictureBox27 = New System.Windows.Forms.PictureBox
        Me.PictureBox5 = New System.Windows.Forms.PictureBox
        Me.PictureBox25 = New System.Windows.Forms.PictureBox
        Me.txtSprelink = New System.Windows.Forms.TextBox
        Me.PictureBox20 = New System.Windows.Forms.PictureBox
        Me.PictureBox21 = New System.Windows.Forms.PictureBox
        Me.PictureBox22 = New System.Windows.Forms.PictureBox
        Me.PictureBox15 = New System.Windows.Forms.PictureBox
        Me.PictureBox16 = New System.Windows.Forms.PictureBox
        Me.gbOptionen = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cbSpread = New System.Windows.Forms.CheckBox
        Me.cbPris = New System.Windows.Forms.CheckBox
        Me.cbBypass = New System.Windows.Forms.CheckBox
        Me.cbRoot = New System.Windows.Forms.CheckBox
        Me.cbIcon = New System.Windows.Forms.CheckBox
        Me.cbProcess = New System.Windows.Forms.CheckBox
        Me.cbExe = New System.Windows.Forms.CheckBox
        Me.cbAntiCodes = New System.Windows.Forms.CheckBox
        Me.cbFakeError = New System.Windows.Forms.CheckBox
        Me.cbAutostart = New System.Windows.Forms.CheckBox
        Me.PictureBox24 = New System.Windows.Forms.PictureBox
        Me.PictureBox23 = New System.Windows.Forms.PictureBox
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.PictureBox18 = New System.Windows.Forms.PictureBox
        Me.PictureBox17 = New System.Windows.Forms.PictureBox
        Me.PictureBox12 = New System.Windows.Forms.PictureBox
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.PictureBox10 = New System.Windows.Forms.PictureBox
        Me.PictureBox9 = New System.Windows.Forms.PictureBox
        Me.PictureBox8 = New System.Windows.Forms.PictureBox
        Me.gbProcessKiller = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtKill = New System.Windows.Forms.TextBox
        Me.gbFakeError = New System.Windows.Forms.GroupBox
        Me.RadioFrage = New System.Windows.Forms.RadioButton
        Me.PictureBox4 = New System.Windows.Forms.PictureBox
        Me.RadioAchtung = New System.Windows.Forms.RadioButton
        Me.PictureBox6 = New System.Windows.Forms.PictureBox
        Me.RadioInformation = New System.Windows.Forms.RadioButton
        Me.PictureBox7 = New System.Windows.Forms.PictureBox
        Me.RadioError = New System.Windows.Forms.RadioButton
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.txttext = New System.Windows.Forms.TextBox
        Me.txttitel = New System.Windows.Forms.TextBox
        Me.gbExepump = New System.Windows.Forms.GroupBox
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown
        Me.gbIcon = New System.Windows.Forms.GroupBox
        Me.pbIcon = New System.Windows.Forms.PictureBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtUrl = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.PictureBox11 = New System.Windows.Forms.PictureBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.txtKey = New System.Windows.Forms.RichTextBox
        Me.btnFertig = New System.Windows.Forms.Button
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.PictureBox34 = New System.Windows.Forms.PictureBox
        Me.PictureBox33 = New System.Windows.Forms.PictureBox
        Me.PictureBox32 = New System.Windows.Forms.PictureBox
        Me.PictureBox31 = New System.Windows.Forms.PictureBox
        Me.PictureBox30 = New System.Windows.Forms.PictureBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.PictureBox29 = New System.Windows.Forms.PictureBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.PictureBox28 = New System.Windows.Forms.PictureBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtIcon = New System.Windows.Forms.TextBox
        Me.txtID = New System.Windows.Forms.TextBox
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.gbAntiCodes.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gbBypass.SuspendLayout()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbSpread.SuspendLayout()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbOptionen.SuspendLayout()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbProcessKiller.SuspendLayout()
        Me.gbFakeError.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbExepump.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbIcon.SuspendLayout()
        CType(Me.pbIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(516, 446)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Transparent
        Me.TabPage1.BackgroundImage = CType(resources.GetObject("TabPage1.BackgroundImage"), System.Drawing.Image)
        Me.TabPage1.Controls.Add(Me.gbAntiCodes)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.gbBypass)
        Me.TabPage1.Controls.Add(Me.gbSpread)
        Me.TabPage1.Controls.Add(Me.gbOptionen)
        Me.TabPage1.Controls.Add(Me.gbProcessKiller)
        Me.TabPage1.Controls.Add(Me.gbFakeError)
        Me.TabPage1.Controls.Add(Me.gbExepump)
        Me.TabPage1.Controls.Add(Me.gbIcon)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(508, 417)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Main Menü"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'gbAntiCodes
        '
        Me.gbAntiCodes.BackgroundImage = CType(resources.GetObject("gbAntiCodes.BackgroundImage"), System.Drawing.Image)
        Me.gbAntiCodes.Controls.Add(Me.CheckBox1)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiZA)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiVM)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiAA)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiBI)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiNO)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiOP)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiKA)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiVP)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiVB)
        Me.gbAntiCodes.Controls.Add(Me.cbAntiSN)
        Me.gbAntiCodes.Enabled = False
        Me.gbAntiCodes.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbAntiCodes.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.gbAntiCodes.Location = New System.Drawing.Point(173, 59)
        Me.gbAntiCodes.Name = "gbAntiCodes"
        Me.gbAntiCodes.Size = New System.Drawing.Size(126, 240)
        Me.gbAntiCodes.TabIndex = 87
        Me.gbAntiCodes.TabStop = False
        Me.gbAntiCodes.Text = "Anti Codes"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.ForeColor = System.Drawing.SystemColors.Window
        Me.CheckBox1.Location = New System.Drawing.Point(6, 213)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(138, 22)
        Me.CheckBox1.TabIndex = 83
        Me.CheckBox1.Text = "Anti Malwarebyte"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'cbAntiZA
        '
        Me.cbAntiZA.AutoSize = True
        Me.cbAntiZA.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiZA.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiZA.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiZA.Location = New System.Drawing.Point(6, 193)
        Me.cbAntiZA.Name = "cbAntiZA"
        Me.cbAntiZA.Size = New System.Drawing.Size(131, 22)
        Me.cbAntiZA.TabIndex = 82
        Me.cbAntiZA.Text = "Anti Zone Alarm"
        Me.cbAntiZA.UseVisualStyleBackColor = True
        '
        'cbAntiVM
        '
        Me.cbAntiVM.AutoSize = True
        Me.cbAntiVM.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiVM.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiVM.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiVM.Location = New System.Drawing.Point(6, 42)
        Me.cbAntiVM.Name = "cbAntiVM"
        Me.cbAntiVM.Size = New System.Drawing.Size(109, 22)
        Me.cbAntiVM.TabIndex = 74
        Me.cbAntiVM.Text = "Anti VMware"
        Me.cbAntiVM.UseVisualStyleBackColor = True
        '
        'cbAntiAA
        '
        Me.cbAntiAA.AutoSize = True
        Me.cbAntiAA.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiAA.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiAA.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiAA.Location = New System.Drawing.Point(6, 22)
        Me.cbAntiAA.Name = "cbAntiAA"
        Me.cbAntiAA.Size = New System.Drawing.Size(99, 22)
        Me.cbAntiAA.TabIndex = 73
        Me.cbAntiAA.Text = "Anti Anubis"
        Me.cbAntiAA.UseVisualStyleBackColor = True
        '
        'cbAntiBI
        '
        Me.cbAntiBI.AutoSize = True
        Me.cbAntiBI.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiBI.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiBI.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiBI.Location = New System.Drawing.Point(6, 175)
        Me.cbAntiBI.Name = "cbAntiBI"
        Me.cbAntiBI.Size = New System.Drawing.Size(129, 22)
        Me.cbAntiBI.TabIndex = 81
        Me.cbAntiBI.Text = "Anti Bitdefender"
        Me.cbAntiBI.UseVisualStyleBackColor = True
        '
        'cbAntiNO
        '
        Me.cbAntiNO.AutoSize = True
        Me.cbAntiNO.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiNO.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiNO.Location = New System.Drawing.Point(6, 61)
        Me.cbAntiNO.Name = "cbAntiNO"
        Me.cbAntiNO.Size = New System.Drawing.Size(109, 22)
        Me.cbAntiNO.TabIndex = 75
        Me.cbAntiNO.Text = "Anti Norman"
        Me.cbAntiNO.UseVisualStyleBackColor = True
        '
        'cbAntiOP
        '
        Me.cbAntiOP.AutoSize = True
        Me.cbAntiOP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiOP.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiOP.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiOP.Location = New System.Drawing.Point(6, 80)
        Me.cbAntiOP.Name = "cbAntiOP"
        Me.cbAntiOP.Size = New System.Drawing.Size(114, 22)
        Me.cbAntiOP.TabIndex = 76
        Me.cbAntiOP.Text = "Anti Out Post"
        Me.cbAntiOP.UseVisualStyleBackColor = True
        '
        'cbAntiKA
        '
        Me.cbAntiKA.AutoSize = True
        Me.cbAntiKA.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiKA.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiKA.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiKA.Location = New System.Drawing.Point(6, 156)
        Me.cbAntiKA.Name = "cbAntiKA"
        Me.cbAntiKA.Size = New System.Drawing.Size(125, 22)
        Me.cbAntiKA.TabIndex = 80
        Me.cbAntiKA.Text = "Anti Kaspersky"
        Me.cbAntiKA.UseVisualStyleBackColor = True
        '
        'cbAntiVP
        '
        Me.cbAntiVP.AutoSize = True
        Me.cbAntiVP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiVP.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiVP.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiVP.Location = New System.Drawing.Point(6, 99)
        Me.cbAntiVP.Name = "cbAntiVP"
        Me.cbAntiVP.Size = New System.Drawing.Size(120, 22)
        Me.cbAntiVP.TabIndex = 77
        Me.cbAntiVP.Text = "Anti Virtual PC"
        Me.cbAntiVP.UseVisualStyleBackColor = True
        '
        'cbAntiVB
        '
        Me.cbAntiVB.AutoSize = True
        Me.cbAntiVB.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiVB.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiVB.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiVB.Location = New System.Drawing.Point(6, 117)
        Me.cbAntiVB.Name = "cbAntiVB"
        Me.cbAntiVB.Size = New System.Drawing.Size(125, 22)
        Me.cbAntiVB.TabIndex = 78
        Me.cbAntiVB.Text = "Anti Virtual Box"
        Me.cbAntiVB.UseVisualStyleBackColor = True
        '
        'cbAntiSN
        '
        Me.cbAntiSN.AutoSize = True
        Me.cbAntiSN.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiSN.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiSN.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiSN.Location = New System.Drawing.Point(6, 138)
        Me.cbAntiSN.Name = "cbAntiSN"
        Me.cbAntiSN.Size = New System.Drawing.Size(97, 22)
        Me.cbAntiSN.TabIndex = 79
        Me.cbAntiSN.Text = "Anti Sniffer"
        Me.cbAntiSN.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackgroundImage = CType(resources.GetObject("GroupBox1.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox1.Controls.Add(Me.ComboBox1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.btnMu)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Mut)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.GroupBox1.Location = New System.Drawing.Point(305, 224)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(196, 75)
        Me.GroupBox1.TabIndex = 86
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Installation"
        '
        'ComboBox1
        '
        Me.ComboBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Windows", "System32", "Programme"})
        Me.ComboBox1.Location = New System.Drawing.Point(58, 46)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(102, 24)
        Me.ComboBox1.TabIndex = 90
        Me.ComboBox1.Text = "Windows"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label4.Location = New System.Drawing.Point(11, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 16)
        Me.Label4.TabIndex = 89
        Me.Label4.Text = "Install"
        '
        'btnMu
        '
        Me.btnMu.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMu.Image = CType(resources.GetObject("btnMu.Image"), System.Drawing.Image)
        Me.btnMu.Location = New System.Drawing.Point(165, 21)
        Me.btnMu.Name = "btnMu"
        Me.btnMu.Size = New System.Drawing.Size(24, 47)
        Me.btnMu.TabIndex = 88
        Me.btnMu.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label2.Location = New System.Drawing.Point(10, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 16)
        Me.Label2.TabIndex = 86
        Me.Label2.Text = "Mutex"
        '
        'Mut
        '
        Me.Mut.Location = New System.Drawing.Point(58, 20)
        Me.Mut.Name = "Mut"
        Me.Mut.ReadOnly = True
        Me.Mut.Size = New System.Drawing.Size(102, 22)
        Me.Mut.TabIndex = 0
        Me.Mut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gbBypass
        '
        Me.gbBypass.BackgroundImage = CType(resources.GetObject("gbBypass.BackgroundImage"), System.Drawing.Image)
        Me.gbBypass.Controls.Add(Me.cbWicenter)
        Me.gbBypass.Controls.Add(Me.cbDefender)
        Me.gbBypass.Controls.Add(Me.cbFirewall)
        Me.gbBypass.Controls.Add(Me.cbUac)
        Me.gbBypass.Controls.Add(Me.PictureBox26)
        Me.gbBypass.Controls.Add(Me.PictureBox19)
        Me.gbBypass.Controls.Add(Me.PictureBox13)
        Me.gbBypass.Controls.Add(Me.PictureBox14)
        Me.gbBypass.Enabled = False
        Me.gbBypass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbBypass.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.gbBypass.Location = New System.Drawing.Point(6, 305)
        Me.gbBypass.Name = "gbBypass"
        Me.gbBypass.Size = New System.Drawing.Size(155, 102)
        Me.gbBypass.TabIndex = 85
        Me.gbBypass.TabStop = False
        Me.gbBypass.Text = "Bypasser"
        '
        'cbWicenter
        '
        Me.cbWicenter.AutoSize = True
        Me.cbWicenter.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbWicenter.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbWicenter.ForeColor = System.Drawing.SystemColors.Window
        Me.cbWicenter.Location = New System.Drawing.Point(34, 78)
        Me.cbWicenter.Name = "cbWicenter"
        Me.cbWicenter.Size = New System.Drawing.Size(142, 22)
        Me.cbWicenter.TabIndex = 71
        Me.cbWicenter.Text = "WiCenter Bypass"
        Me.cbWicenter.UseVisualStyleBackColor = True
        '
        'cbDefender
        '
        Me.cbDefender.AutoSize = True
        Me.cbDefender.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbDefender.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbDefender.ForeColor = System.Drawing.SystemColors.Window
        Me.cbDefender.Location = New System.Drawing.Point(34, 58)
        Me.cbDefender.Name = "cbDefender"
        Me.cbDefender.Size = New System.Drawing.Size(140, 22)
        Me.cbDefender.TabIndex = 70
        Me.cbDefender.Text = "Defender Bypass"
        Me.cbDefender.UseVisualStyleBackColor = True
        '
        'cbFirewall
        '
        Me.cbFirewall.AutoSize = True
        Me.cbFirewall.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbFirewall.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbFirewall.ForeColor = System.Drawing.SystemColors.Window
        Me.cbFirewall.Location = New System.Drawing.Point(34, 40)
        Me.cbFirewall.Name = "cbFirewall"
        Me.cbFirewall.Size = New System.Drawing.Size(130, 22)
        Me.cbFirewall.TabIndex = 69
        Me.cbFirewall.Text = "Firewall Bypass"
        Me.cbFirewall.UseVisualStyleBackColor = True
        '
        'cbUac
        '
        Me.cbUac.AutoSize = True
        Me.cbUac.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbUac.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbUac.ForeColor = System.Drawing.SystemColors.Window
        Me.cbUac.Location = New System.Drawing.Point(34, 21)
        Me.cbUac.Name = "cbUac"
        Me.cbUac.Size = New System.Drawing.Size(111, 22)
        Me.cbUac.TabIndex = 68
        Me.cbUac.Text = "UAC Bypass"
        Me.cbUac.UseVisualStyleBackColor = True
        '
        'PictureBox26
        '
        Me.PictureBox26.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox26.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox26.Image = CType(resources.GetObject("PictureBox26.Image"), System.Drawing.Image)
        Me.PictureBox26.Location = New System.Drawing.Point(10, 76)
        Me.PictureBox26.Name = "PictureBox26"
        Me.PictureBox26.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox26.TabIndex = 45
        Me.PictureBox26.TabStop = False
        '
        'PictureBox19
        '
        Me.PictureBox19.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox19.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox19.Image = CType(resources.GetObject("PictureBox19.Image"), System.Drawing.Image)
        Me.PictureBox19.Location = New System.Drawing.Point(10, 58)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox19.TabIndex = 43
        Me.PictureBox19.TabStop = False
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox13.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox13.Image = CType(resources.GetObject("PictureBox13.Image"), System.Drawing.Image)
        Me.PictureBox13.Location = New System.Drawing.Point(10, 21)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox13.TabIndex = 26
        Me.PictureBox13.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox14.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox14.Image = CType(resources.GetObject("PictureBox14.Image"), System.Drawing.Image)
        Me.PictureBox14.Location = New System.Drawing.Point(10, 40)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox14.TabIndex = 27
        Me.PictureBox14.TabStop = False
        '
        'gbSpread
        '
        Me.gbSpread.BackgroundImage = CType(resources.GetObject("gbSpread.BackgroundImage"), System.Drawing.Image)
        Me.gbSpread.Controls.Add(Me.cbSkype)
        Me.gbSpread.Controls.Add(Me.cbMSN)
        Me.gbSpread.Controls.Add(Me.cbIcq)
        Me.gbSpread.Controls.Add(Me.cbRar)
        Me.gbSpread.Controls.Add(Me.cbLan)
        Me.gbSpread.Controls.Add(Me.cbP2p)
        Me.gbSpread.Controls.Add(Me.cbUsb)
        Me.gbSpread.Controls.Add(Me.PictureBox27)
        Me.gbSpread.Controls.Add(Me.PictureBox5)
        Me.gbSpread.Controls.Add(Me.PictureBox25)
        Me.gbSpread.Controls.Add(Me.txtSprelink)
        Me.gbSpread.Controls.Add(Me.PictureBox20)
        Me.gbSpread.Controls.Add(Me.PictureBox21)
        Me.gbSpread.Controls.Add(Me.PictureBox22)
        Me.gbSpread.Controls.Add(Me.PictureBox15)
        Me.gbSpread.Controls.Add(Me.PictureBox16)
        Me.gbSpread.Enabled = False
        Me.gbSpread.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbSpread.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.gbSpread.Location = New System.Drawing.Point(173, 305)
        Me.gbSpread.Name = "gbSpread"
        Me.gbSpread.Size = New System.Drawing.Size(253, 102)
        Me.gbSpread.TabIndex = 84
        Me.gbSpread.TabStop = False
        Me.gbSpread.Text = "Spread Optionen"
        '
        'cbSkype
        '
        Me.cbSkype.AutoSize = True
        Me.cbSkype.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbSkype.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbSkype.ForeColor = System.Drawing.SystemColors.Window
        Me.cbSkype.Location = New System.Drawing.Point(154, 58)
        Me.cbSkype.Name = "cbSkype"
        Me.cbSkype.Size = New System.Drawing.Size(119, 22)
        Me.cbSkype.TabIndex = 74
        Me.cbSkype.Text = "Skype Spread"
        Me.cbSkype.UseVisualStyleBackColor = True
        '
        'cbMSN
        '
        Me.cbMSN.AutoSize = True
        Me.cbMSN.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbMSN.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMSN.ForeColor = System.Drawing.SystemColors.Window
        Me.cbMSN.Location = New System.Drawing.Point(154, 39)
        Me.cbMSN.Name = "cbMSN"
        Me.cbMSN.Size = New System.Drawing.Size(112, 22)
        Me.cbMSN.TabIndex = 73
        Me.cbMSN.Text = "MSN Spread"
        Me.cbMSN.UseVisualStyleBackColor = True
        '
        'cbIcq
        '
        Me.cbIcq.AutoSize = True
        Me.cbIcq.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbIcq.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbIcq.ForeColor = System.Drawing.SystemColors.Window
        Me.cbIcq.Location = New System.Drawing.Point(154, 21)
        Me.cbIcq.Name = "cbIcq"
        Me.cbIcq.Size = New System.Drawing.Size(104, 22)
        Me.cbIcq.TabIndex = 72
        Me.cbIcq.Text = "ICQ Spread"
        Me.cbIcq.UseVisualStyleBackColor = True
        '
        'cbRar
        '
        Me.cbRar.AutoSize = True
        Me.cbRar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbRar.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbRar.ForeColor = System.Drawing.SystemColors.Window
        Me.cbRar.Location = New System.Drawing.Point(30, 78)
        Me.cbRar.Name = "cbRar"
        Me.cbRar.Size = New System.Drawing.Size(109, 22)
        Me.cbRar.TabIndex = 71
        Me.cbRar.Text = "RAR Spread"
        Me.cbRar.UseVisualStyleBackColor = True
        '
        'cbLan
        '
        Me.cbLan.AutoSize = True
        Me.cbLan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbLan.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbLan.ForeColor = System.Drawing.SystemColors.Window
        Me.cbLan.Location = New System.Drawing.Point(30, 58)
        Me.cbLan.Name = "cbLan"
        Me.cbLan.Size = New System.Drawing.Size(106, 22)
        Me.cbLan.TabIndex = 70
        Me.cbLan.Text = "LAN Spread"
        Me.cbLan.UseVisualStyleBackColor = True
        '
        'cbP2p
        '
        Me.cbP2p.AutoSize = True
        Me.cbP2p.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbP2p.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbP2p.ForeColor = System.Drawing.SystemColors.Window
        Me.cbP2p.Location = New System.Drawing.Point(30, 39)
        Me.cbP2p.Name = "cbP2p"
        Me.cbP2p.Size = New System.Drawing.Size(106, 22)
        Me.cbP2p.TabIndex = 69
        Me.cbP2p.Text = "P2P Spread"
        Me.cbP2p.UseVisualStyleBackColor = True
        '
        'cbUsb
        '
        Me.cbUsb.AutoSize = True
        Me.cbUsb.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbUsb.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbUsb.ForeColor = System.Drawing.SystemColors.Window
        Me.cbUsb.Location = New System.Drawing.Point(30, 21)
        Me.cbUsb.Name = "cbUsb"
        Me.cbUsb.Size = New System.Drawing.Size(109, 22)
        Me.cbUsb.TabIndex = 68
        Me.cbUsb.Text = "USB Spread"
        Me.cbUsb.UseVisualStyleBackColor = True
        '
        'PictureBox27
        '
        Me.PictureBox27.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox27.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox27.Image = CType(resources.GetObject("PictureBox27.Image"), System.Drawing.Image)
        Me.PictureBox27.Location = New System.Drawing.Point(133, 21)
        Me.PictureBox27.Name = "PictureBox27"
        Me.PictureBox27.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox27.TabIndex = 60
        Me.PictureBox27.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(9, 76)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 58
        Me.PictureBox5.TabStop = False
        '
        'PictureBox25
        '
        Me.PictureBox25.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox25.Enabled = False
        Me.PictureBox25.Image = CType(resources.GetObject("PictureBox25.Image"), System.Drawing.Image)
        Me.PictureBox25.Location = New System.Drawing.Point(222, 78)
        Me.PictureBox25.Name = "PictureBox25"
        Me.PictureBox25.Size = New System.Drawing.Size(17, 18)
        Me.PictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox25.TabIndex = 56
        Me.PictureBox25.TabStop = False
        '
        'txtSprelink
        '
        Me.txtSprelink.BackColor = System.Drawing.SystemColors.Window
        Me.txtSprelink.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSprelink.Enabled = False
        Me.txtSprelink.Font = New System.Drawing.Font("Comic Sans MS", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSprelink.Location = New System.Drawing.Point(135, 79)
        Me.txtSprelink.Name = "txtSprelink"
        Me.txtSprelink.Size = New System.Drawing.Size(81, 17)
        Me.txtSprelink.TabIndex = 54
        Me.txtSprelink.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PictureBox20
        '
        Me.PictureBox20.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox20.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox20.Image = CType(resources.GetObject("PictureBox20.Image"), System.Drawing.Image)
        Me.PictureBox20.Location = New System.Drawing.Point(133, 58)
        Me.PictureBox20.Name = "PictureBox20"
        Me.PictureBox20.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox20.TabIndex = 53
        Me.PictureBox20.TabStop = False
        '
        'PictureBox21
        '
        Me.PictureBox21.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox21.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox21.Image = CType(resources.GetObject("PictureBox21.Image"), System.Drawing.Image)
        Me.PictureBox21.Location = New System.Drawing.Point(9, 56)
        Me.PictureBox21.Name = "PictureBox21"
        Me.PictureBox21.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox21.TabIndex = 48
        Me.PictureBox21.TabStop = False
        '
        'PictureBox22
        '
        Me.PictureBox22.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox22.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox22.Image = CType(resources.GetObject("PictureBox22.Image"), System.Drawing.Image)
        Me.PictureBox22.Location = New System.Drawing.Point(133, 39)
        Me.PictureBox22.Name = "PictureBox22"
        Me.PictureBox22.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox22.TabIndex = 49
        Me.PictureBox22.TabStop = False
        '
        'PictureBox15
        '
        Me.PictureBox15.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox15.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox15.Image = CType(resources.GetObject("PictureBox15.Image"), System.Drawing.Image)
        Me.PictureBox15.Location = New System.Drawing.Point(9, 21)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox15.TabIndex = 28
        Me.PictureBox15.TabStop = False
        '
        'PictureBox16
        '
        Me.PictureBox16.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox16.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox16.Image = CType(resources.GetObject("PictureBox16.Image"), System.Drawing.Image)
        Me.PictureBox16.Location = New System.Drawing.Point(9, 39)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox16.TabIndex = 29
        Me.PictureBox16.TabStop = False
        '
        'gbOptionen
        '
        Me.gbOptionen.BackgroundImage = CType(resources.GetObject("gbOptionen.BackgroundImage"), System.Drawing.Image)
        Me.gbOptionen.Controls.Add(Me.Label3)
        Me.gbOptionen.Controls.Add(Me.cbSpread)
        Me.gbOptionen.Controls.Add(Me.cbPris)
        Me.gbOptionen.Controls.Add(Me.cbBypass)
        Me.gbOptionen.Controls.Add(Me.cbRoot)
        Me.gbOptionen.Controls.Add(Me.cbIcon)
        Me.gbOptionen.Controls.Add(Me.cbProcess)
        Me.gbOptionen.Controls.Add(Me.cbExe)
        Me.gbOptionen.Controls.Add(Me.cbAntiCodes)
        Me.gbOptionen.Controls.Add(Me.cbFakeError)
        Me.gbOptionen.Controls.Add(Me.cbAutostart)
        Me.gbOptionen.Controls.Add(Me.PictureBox24)
        Me.gbOptionen.Controls.Add(Me.PictureBox23)
        Me.gbOptionen.Controls.Add(Me.PictureBox2)
        Me.gbOptionen.Controls.Add(Me.PictureBox18)
        Me.gbOptionen.Controls.Add(Me.PictureBox17)
        Me.gbOptionen.Controls.Add(Me.PictureBox12)
        Me.gbOptionen.Controls.Add(Me.PictureBox1)
        Me.gbOptionen.Controls.Add(Me.PictureBox10)
        Me.gbOptionen.Controls.Add(Me.PictureBox9)
        Me.gbOptionen.Controls.Add(Me.PictureBox8)
        Me.gbOptionen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbOptionen.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.gbOptionen.Location = New System.Drawing.Point(6, 59)
        Me.gbOptionen.Name = "gbOptionen"
        Me.gbOptionen.Size = New System.Drawing.Size(155, 240)
        Me.gbOptionen.TabIndex = 83
        Me.gbOptionen.TabStop = False
        Me.gbOptionen.Text = "Optionen"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.LightCyan
        Me.Label3.Location = New System.Drawing.Point(11, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 16)
        Me.Label3.TabIndex = 68
        Me.Label3.Text = "-------------------------------"
        '
        'cbSpread
        '
        Me.cbSpread.AutoSize = True
        Me.cbSpread.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbSpread.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbSpread.ForeColor = System.Drawing.SystemColors.Window
        Me.cbSpread.Location = New System.Drawing.Point(33, 212)
        Me.cbSpread.Name = "cbSpread"
        Me.cbSpread.Size = New System.Drawing.Size(138, 22)
        Me.cbSpread.TabIndex = 67
        Me.cbSpread.Text = "Spread Optionen"
        Me.cbSpread.UseVisualStyleBackColor = True
        '
        'cbPris
        '
        Me.cbPris.AutoSize = True
        Me.cbPris.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbPris.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbPris.ForeColor = System.Drawing.SystemColors.Window
        Me.cbPris.Location = New System.Drawing.Point(33, 193)
        Me.cbPris.Name = "cbPris"
        Me.cbPris.Size = New System.Drawing.Size(93, 22)
        Me.cbPris.TabIndex = 66
        Me.cbPris.Text = "Persistant"
        Me.cbPris.UseVisualStyleBackColor = True
        '
        'cbBypass
        '
        Me.cbBypass.AutoSize = True
        Me.cbBypass.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbBypass.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbBypass.ForeColor = System.Drawing.SystemColors.Window
        Me.cbBypass.Location = New System.Drawing.Point(33, 175)
        Me.cbBypass.Name = "cbBypass"
        Me.cbBypass.Size = New System.Drawing.Size(89, 22)
        Me.cbBypass.TabIndex = 65
        Me.cbBypass.Text = "Bypasser"
        Me.cbBypass.UseVisualStyleBackColor = True
        '
        'cbRoot
        '
        Me.cbRoot.AutoSize = True
        Me.cbRoot.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbRoot.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbRoot.ForeColor = System.Drawing.SystemColors.Window
        Me.cbRoot.Location = New System.Drawing.Point(33, 156)
        Me.cbRoot.Name = "cbRoot"
        Me.cbRoot.Size = New System.Drawing.Size(75, 22)
        Me.cbRoot.TabIndex = 64
        Me.cbRoot.Text = "Rootkit"
        Me.cbRoot.UseVisualStyleBackColor = True
        '
        'cbIcon
        '
        Me.cbIcon.AutoSize = True
        Me.cbIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbIcon.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbIcon.ForeColor = System.Drawing.SystemColors.Window
        Me.cbIcon.Location = New System.Drawing.Point(33, 117)
        Me.cbIcon.Name = "cbIcon"
        Me.cbIcon.Size = New System.Drawing.Size(115, 22)
        Me.cbIcon.TabIndex = 63
        Me.cbIcon.Text = "Icon Changer"
        Me.cbIcon.UseVisualStyleBackColor = True
        '
        'cbProcess
        '
        Me.cbProcess.AutoSize = True
        Me.cbProcess.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbProcess.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbProcess.ForeColor = System.Drawing.SystemColors.Window
        Me.cbProcess.Location = New System.Drawing.Point(33, 99)
        Me.cbProcess.Name = "cbProcess"
        Me.cbProcess.Size = New System.Drawing.Size(119, 22)
        Me.cbProcess.TabIndex = 62
        Me.cbProcess.Text = "Prozess Killer"
        Me.cbProcess.UseVisualStyleBackColor = True
        '
        'cbExe
        '
        Me.cbExe.AutoSize = True
        Me.cbExe.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbExe.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbExe.ForeColor = System.Drawing.SystemColors.Window
        Me.cbExe.Location = New System.Drawing.Point(33, 80)
        Me.cbExe.Name = "cbExe"
        Me.cbExe.Size = New System.Drawing.Size(110, 22)
        Me.cbExe.TabIndex = 61
        Me.cbExe.Text = "ExE Pumper"
        Me.cbExe.UseVisualStyleBackColor = True
        '
        'cbAntiCodes
        '
        Me.cbAntiCodes.AutoSize = True
        Me.cbAntiCodes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAntiCodes.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiCodes.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAntiCodes.Location = New System.Drawing.Point(33, 61)
        Me.cbAntiCodes.Name = "cbAntiCodes"
        Me.cbAntiCodes.Size = New System.Drawing.Size(99, 22)
        Me.cbAntiCodes.TabIndex = 60
        Me.cbAntiCodes.Text = "Anti Codes"
        Me.cbAntiCodes.UseVisualStyleBackColor = True
        '
        'cbFakeError
        '
        Me.cbFakeError.AutoSize = True
        Me.cbFakeError.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbFakeError.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbFakeError.ForeColor = System.Drawing.SystemColors.Window
        Me.cbFakeError.Location = New System.Drawing.Point(33, 42)
        Me.cbFakeError.Name = "cbFakeError"
        Me.cbFakeError.Size = New System.Drawing.Size(98, 22)
        Me.cbFakeError.TabIndex = 59
        Me.cbFakeError.Text = "Fake Error"
        Me.cbFakeError.UseVisualStyleBackColor = True
        '
        'cbAutostart
        '
        Me.cbAutostart.AutoSize = True
        Me.cbAutostart.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cbAutostart.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAutostart.ForeColor = System.Drawing.SystemColors.Window
        Me.cbAutostart.Location = New System.Drawing.Point(33, 22)
        Me.cbAutostart.Name = "cbAutostart"
        Me.cbAutostart.Size = New System.Drawing.Size(86, 22)
        Me.cbAutostart.TabIndex = 58
        Me.cbAutostart.Text = "Autostart"
        Me.cbAutostart.UseVisualStyleBackColor = True
        '
        'PictureBox24
        '
        Me.PictureBox24.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox24.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox24.Image = CType(resources.GetObject("PictureBox24.Image"), System.Drawing.Image)
        Me.PictureBox24.Location = New System.Drawing.Point(9, 193)
        Me.PictureBox24.Name = "PictureBox24"
        Me.PictureBox24.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox24.TabIndex = 57
        Me.PictureBox24.TabStop = False
        '
        'PictureBox23
        '
        Me.PictureBox23.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox23.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox23.Image = CType(resources.GetObject("PictureBox23.Image"), System.Drawing.Image)
        Me.PictureBox23.Location = New System.Drawing.Point(9, 156)
        Me.PictureBox23.Name = "PictureBox23"
        Me.PictureBox23.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox23.TabIndex = 54
        Me.PictureBox23.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(9, 23)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2.TabIndex = 52
        Me.PictureBox2.TabStop = False
        '
        'PictureBox18
        '
        Me.PictureBox18.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox18.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox18.Image = CType(resources.GetObject("PictureBox18.Image"), System.Drawing.Image)
        Me.PictureBox18.Location = New System.Drawing.Point(9, 175)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox18.TabIndex = 50
        Me.PictureBox18.TabStop = False
        '
        'PictureBox17
        '
        Me.PictureBox17.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox17.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox17.Image = CType(resources.GetObject("PictureBox17.Image"), System.Drawing.Image)
        Me.PictureBox17.Location = New System.Drawing.Point(9, 212)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox17.TabIndex = 48
        Me.PictureBox17.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox12.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox12.Image = CType(resources.GetObject("PictureBox12.Image"), System.Drawing.Image)
        Me.PictureBox12.Location = New System.Drawing.Point(9, 80)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox12.TabIndex = 46
        Me.PictureBox12.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(9, 120)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 36
        Me.PictureBox1.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox10.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(9, 99)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox10.TabIndex = 23
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox9.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(9, 61)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox9.TabIndex = 22
        Me.PictureBox9.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox8.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(9, 42)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox8.TabIndex = 14
        Me.PictureBox8.TabStop = False
        '
        'gbProcessKiller
        '
        Me.gbProcessKiller.BackgroundImage = CType(resources.GetObject("gbProcessKiller.BackgroundImage"), System.Drawing.Image)
        Me.gbProcessKiller.Controls.Add(Me.Label1)
        Me.gbProcessKiller.Controls.Add(Me.txtKill)
        Me.gbProcessKiller.Enabled = False
        Me.gbProcessKiller.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbProcessKiller.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.gbProcessKiller.Location = New System.Drawing.Point(305, 173)
        Me.gbProcessKiller.Name = "gbProcessKiller"
        Me.gbProcessKiller.Size = New System.Drawing.Size(194, 45)
        Me.gbProcessKiller.TabIndex = 82
        Me.gbProcessKiller.TabStop = False
        Me.gbProcessKiller.Text = "Prozess Killer"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label1.Location = New System.Drawing.Point(161, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 18)
        Me.Label1.TabIndex = 85
        Me.Label1.Text = ".exe"
        '
        'txtKill
        '
        Me.txtKill.Location = New System.Drawing.Point(6, 16)
        Me.txtKill.Name = "txtKill"
        Me.txtKill.Size = New System.Drawing.Size(154, 22)
        Me.txtKill.TabIndex = 84
        Me.txtKill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gbFakeError
        '
        Me.gbFakeError.BackgroundImage = CType(resources.GetObject("gbFakeError.BackgroundImage"), System.Drawing.Image)
        Me.gbFakeError.Controls.Add(Me.RadioFrage)
        Me.gbFakeError.Controls.Add(Me.PictureBox4)
        Me.gbFakeError.Controls.Add(Me.RadioAchtung)
        Me.gbFakeError.Controls.Add(Me.PictureBox6)
        Me.gbFakeError.Controls.Add(Me.RadioInformation)
        Me.gbFakeError.Controls.Add(Me.PictureBox7)
        Me.gbFakeError.Controls.Add(Me.RadioError)
        Me.gbFakeError.Controls.Add(Me.PictureBox3)
        Me.gbFakeError.Controls.Add(Me.txttext)
        Me.gbFakeError.Controls.Add(Me.txttitel)
        Me.gbFakeError.Enabled = False
        Me.gbFakeError.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbFakeError.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.gbFakeError.Location = New System.Drawing.Point(305, 59)
        Me.gbFakeError.Name = "gbFakeError"
        Me.gbFakeError.Size = New System.Drawing.Size(194, 108)
        Me.gbFakeError.TabIndex = 81
        Me.gbFakeError.TabStop = False
        Me.gbFakeError.Text = "Fake Error"
        '
        'RadioFrage
        '
        Me.RadioFrage.AutoSize = True
        Me.RadioFrage.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RadioFrage.Location = New System.Drawing.Point(157, 82)
        Me.RadioFrage.Name = "RadioFrage"
        Me.RadioFrage.Size = New System.Drawing.Size(14, 13)
        Me.RadioFrage.TabIndex = 86
        Me.RadioFrage.TabStop = True
        Me.RadioFrage.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(171, 40)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(17, 18)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox4.TabIndex = 14
        Me.PictureBox4.TabStop = False
        '
        'RadioAchtung
        '
        Me.RadioAchtung.AutoSize = True
        Me.RadioAchtung.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RadioAchtung.Location = New System.Drawing.Point(157, 63)
        Me.RadioAchtung.Name = "RadioAchtung"
        Me.RadioAchtung.Size = New System.Drawing.Size(14, 13)
        Me.RadioAchtung.TabIndex = 85
        Me.RadioAchtung.TabStop = True
        Me.RadioAchtung.UseVisualStyleBackColor = True
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox6.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(171, 61)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(17, 18)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6.TabIndex = 15
        Me.PictureBox6.TabStop = False
        '
        'RadioInformation
        '
        Me.RadioInformation.AutoSize = True
        Me.RadioInformation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RadioInformation.Location = New System.Drawing.Point(157, 44)
        Me.RadioInformation.Name = "RadioInformation"
        Me.RadioInformation.Size = New System.Drawing.Size(14, 13)
        Me.RadioInformation.TabIndex = 84
        Me.RadioInformation.TabStop = True
        Me.RadioInformation.UseVisualStyleBackColor = True
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox7.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(171, 80)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(17, 18)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox7.TabIndex = 16
        Me.PictureBox7.TabStop = False
        '
        'RadioError
        '
        Me.RadioError.AutoSize = True
        Me.RadioError.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RadioError.Location = New System.Drawing.Point(157, 26)
        Me.RadioError.Name = "RadioError"
        Me.RadioError.Size = New System.Drawing.Size(14, 13)
        Me.RadioError.TabIndex = 83
        Me.RadioError.TabStop = True
        Me.RadioError.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(170, 21)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3.TabIndex = 13
        Me.PictureBox3.TabStop = False
        '
        'txttext
        '
        Me.txttext.BackColor = System.Drawing.SystemColors.Window
        Me.txttext.Font = New System.Drawing.Font("Comic Sans MS", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttext.Location = New System.Drawing.Point(6, 47)
        Me.txttext.Multiline = True
        Me.txttext.Name = "txttext"
        Me.txttext.Size = New System.Drawing.Size(142, 51)
        Me.txttext.TabIndex = 3
        Me.txttext.Text = "Text..."
        '
        'txttitel
        '
        Me.txttitel.BackColor = System.Drawing.SystemColors.Window
        Me.txttitel.Font = New System.Drawing.Font("Comic Sans MS", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttitel.Location = New System.Drawing.Point(6, 18)
        Me.txttitel.Name = "txttitel"
        Me.txttitel.Size = New System.Drawing.Size(142, 24)
        Me.txttitel.TabIndex = 2
        Me.txttitel.Text = "Titel..."
        '
        'gbExepump
        '
        Me.gbExepump.BackgroundImage = CType(resources.GetObject("gbExepump.BackgroundImage"), System.Drawing.Image)
        Me.gbExepump.Controls.Add(Me.NumericUpDown1)
        Me.gbExepump.Enabled = False
        Me.gbExepump.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbExepump.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.gbExepump.Location = New System.Drawing.Point(437, 366)
        Me.gbExepump.Name = "gbExepump"
        Me.gbExepump.Size = New System.Drawing.Size(64, 41)
        Me.gbExepump.TabIndex = 80
        Me.gbExepump.TabStop = False
        Me.gbExepump.Text = "Pump"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.BackColor = System.Drawing.SystemColors.Window
        Me.NumericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.NumericUpDown1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NumericUpDown1.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown1.Location = New System.Drawing.Point(6, 16)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(52, 19)
        Me.NumericUpDown1.TabIndex = 3
        Me.NumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown1.Value = New Decimal(New Integer() {500, 0, 0, 0})
        '
        'gbIcon
        '
        Me.gbIcon.BackgroundImage = CType(resources.GetObject("gbIcon.BackgroundImage"), System.Drawing.Image)
        Me.gbIcon.Controls.Add(Me.pbIcon)
        Me.gbIcon.Enabled = False
        Me.gbIcon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbIcon.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.gbIcon.Location = New System.Drawing.Point(437, 305)
        Me.gbIcon.Name = "gbIcon"
        Me.gbIcon.Size = New System.Drawing.Size(64, 58)
        Me.gbIcon.TabIndex = 79
        Me.gbIcon.TabStop = False
        Me.gbIcon.Text = "Icon"
        '
        'pbIcon
        '
        Me.pbIcon.BackColor = System.Drawing.SystemColors.Window
        Me.pbIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pbIcon.Image = CType(resources.GetObject("pbIcon.Image"), System.Drawing.Image)
        Me.pbIcon.Location = New System.Drawing.Point(6, 14)
        Me.pbIcon.Name = "pbIcon"
        Me.pbIcon.Size = New System.Drawing.Size(52, 38)
        Me.pbIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbIcon.TabIndex = 0
        Me.pbIcon.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackgroundImage = CType(resources.GetObject("GroupBox2.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox2.Controls.Add(Me.txtUrl)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.PictureBox11)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.GroupBox2.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(493, 47)
        Me.GroupBox2.TabIndex = 71
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Link für die Verbindung der Bots"
        '
        'txtUrl
        '
        Me.txtUrl.Location = New System.Drawing.Point(6, 17)
        Me.txtUrl.Name = "txtUrl"
        Me.txtUrl.Size = New System.Drawing.Size(384, 22)
        Me.txtUrl.TabIndex = 83
        Me.txtUrl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label7.Location = New System.Drawing.Point(396, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 16)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "/bot.php"
        '
        'PictureBox11
        '
        Me.PictureBox11.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(464, 19)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(17, 18)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox11.TabIndex = 17
        Me.PictureBox11.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.BackgroundImage = CType(resources.GetObject("TabPage2.BackgroundImage"), System.Drawing.Image)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.btnFertig)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(508, 417)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Fertigstellung"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtKey)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.GroupBox3.Location = New System.Drawing.Point(10, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(484, 360)
        Me.GroupBox3.TabIndex = 92
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Verschlüsselung: Polymorphe - DES+Rot13+XOR"
        '
        'txtKey
        '
        Me.txtKey.BackColor = System.Drawing.Color.Black
        Me.txtKey.Cursor = System.Windows.Forms.Cursors.Default
        Me.txtKey.Enabled = False
        Me.txtKey.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKey.ForeColor = System.Drawing.Color.DarkMagenta
        Me.txtKey.Location = New System.Drawing.Point(6, 19)
        Me.txtKey.Name = "txtKey"
        Me.txtKey.ReadOnly = True
        Me.txtKey.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.txtKey.Size = New System.Drawing.Size(472, 334)
        Me.txtKey.TabIndex = 91
        Me.txtKey.Text = ""
        '
        'btnFertig
        '
        Me.btnFertig.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFertig.Image = CType(resources.GetObject("btnFertig.Image"), System.Drawing.Image)
        Me.btnFertig.Location = New System.Drawing.Point(10, 372)
        Me.btnFertig.Name = "btnFertig"
        Me.btnFertig.Size = New System.Drawing.Size(484, 39)
        Me.btnFertig.TabIndex = 90
        Me.btnFertig.Text = "Fertigstellen"
        Me.btnFertig.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnFertig.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnFertig.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.BackgroundImage = CType(resources.GetObject("TabPage3.BackgroundImage"), System.Drawing.Image)
        Me.TabPage3.Controls.Add(Me.PictureBox34)
        Me.TabPage3.Controls.Add(Me.PictureBox33)
        Me.TabPage3.Controls.Add(Me.PictureBox32)
        Me.TabPage3.Controls.Add(Me.PictureBox31)
        Me.TabPage3.Controls.Add(Me.PictureBox30)
        Me.TabPage3.Controls.Add(Me.Label10)
        Me.TabPage3.Controls.Add(Me.PictureBox29)
        Me.TabPage3.Controls.Add(Me.Label9)
        Me.TabPage3.Controls.Add(Me.PictureBox28)
        Me.TabPage3.Controls.Add(Me.Label8)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(508, 417)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "About"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'PictureBox34
        '
        Me.PictureBox34.Image = CType(resources.GetObject("PictureBox34.Image"), System.Drawing.Image)
        Me.PictureBox34.Location = New System.Drawing.Point(25, 212)
        Me.PictureBox34.Name = "PictureBox34"
        Me.PictureBox34.Size = New System.Drawing.Size(458, 182)
        Me.PictureBox34.TabIndex = 69
        Me.PictureBox34.TabStop = False
        '
        'PictureBox33
        '
        Me.PictureBox33.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox33.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox33.Image = CType(resources.GetObject("PictureBox33.Image"), System.Drawing.Image)
        Me.PictureBox33.Location = New System.Drawing.Point(314, 127)
        Me.PictureBox33.Name = "PictureBox33"
        Me.PictureBox33.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox33.TabIndex = 68
        Me.PictureBox33.TabStop = False
        '
        'PictureBox32
        '
        Me.PictureBox32.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox32.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox32.Image = CType(resources.GetObject("PictureBox32.Image"), System.Drawing.Image)
        Me.PictureBox32.Location = New System.Drawing.Point(325, 90)
        Me.PictureBox32.Name = "PictureBox32"
        Me.PictureBox32.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox32.TabIndex = 67
        Me.PictureBox32.TabStop = False
        '
        'PictureBox31
        '
        Me.PictureBox31.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox31.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox31.Image = CType(resources.GetObject("PictureBox31.Image"), System.Drawing.Image)
        Me.PictureBox31.Location = New System.Drawing.Point(281, 162)
        Me.PictureBox31.Name = "PictureBox31"
        Me.PictureBox31.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox31.TabIndex = 66
        Me.PictureBox31.TabStop = False
        '
        'PictureBox30
        '
        Me.PictureBox30.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox30.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox30.Image = CType(resources.GetObject("PictureBox30.Image"), System.Drawing.Image)
        Me.PictureBox30.Location = New System.Drawing.Point(171, 127)
        Me.PictureBox30.Name = "PictureBox30"
        Me.PictureBox30.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox30.TabIndex = 65
        Me.PictureBox30.TabStop = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label10.Location = New System.Drawing.Point(189, 90)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(140, 18)
        Me.Label10.TabIndex = 64
        Me.Label10.Text = "http://Anatoxis.6x.to/"
        '
        'PictureBox29
        '
        Me.PictureBox29.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox29.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox29.Image = CType(resources.GetObject("PictureBox29.Image"), System.Drawing.Image)
        Me.PictureBox29.Location = New System.Drawing.Point(165, 90)
        Me.PictureBox29.Name = "PictureBox29"
        Me.PictureBox29.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox29.TabIndex = 63
        Me.PictureBox29.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label9.Location = New System.Drawing.Point(225, 162)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(56, 18)
        Me.Label9.TabIndex = 62
        Me.Label9.Text = "161509"
        '
        'PictureBox28
        '
        Me.PictureBox28.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox28.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox28.Image = CType(resources.GetObject("PictureBox28.Image"), System.Drawing.Image)
        Me.PictureBox28.Location = New System.Drawing.Point(201, 162)
        Me.PictureBox28.Name = "PictureBox28"
        Me.PictureBox28.Size = New System.Drawing.Size(18, 18)
        Me.PictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox28.TabIndex = 61
        Me.PictureBox28.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label8.Location = New System.Drawing.Point(195, 127)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(123, 18)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Code by Anatoxis"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label6.Location = New System.Drawing.Point(119, 162)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 16)
        Me.Label6.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label5.Location = New System.Drawing.Point(79, 34)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(249, 33)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "* Firesale Botnet *"
        '
        'txtIcon
        '
        Me.txtIcon.Location = New System.Drawing.Point(588, 62)
        Me.txtIcon.Name = "txtIcon"
        Me.txtIcon.Size = New System.Drawing.Size(64, 20)
        Me.txtIcon.TabIndex = 70
        Me.txtIcon.Visible = False
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtID.Location = New System.Drawing.Point(588, 41)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(64, 20)
        Me.txtID.TabIndex = 71
        Me.txtID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtID.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(542, 471)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.txtIcon)
        Me.Controls.Add(Me.txtID)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Opacity = 0.9
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Firesale Botnet by Anatoxis"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.gbAntiCodes.ResumeLayout(False)
        Me.gbAntiCodes.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbBypass.ResumeLayout(False)
        Me.gbBypass.PerformLayout()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbSpread.ResumeLayout(False)
        Me.gbSpread.PerformLayout()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbOptionen.ResumeLayout(False)
        Me.gbOptionen.PerformLayout()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbProcessKiller.ResumeLayout(False)
        Me.gbProcessKiller.PerformLayout()
        Me.gbFakeError.ResumeLayout(False)
        Me.gbFakeError.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbExepump.ResumeLayout(False)
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbIcon.ResumeLayout(False)
        CType(Me.pbIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Mut As System.Windows.Forms.TextBox
    Friend WithEvents txtIcon As System.Windows.Forms.TextBox
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents gbProcessKiller As System.Windows.Forms.GroupBox
    Friend WithEvents gbFakeError As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents txttext As System.Windows.Forms.TextBox
    Friend WithEvents txttitel As System.Windows.Forms.TextBox
    Friend WithEvents gbExepump As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents gbIcon As System.Windows.Forms.GroupBox
    Friend WithEvents pbIcon As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtUrl As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtKill As System.Windows.Forms.TextBox
    Friend WithEvents gbOptionen As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox24 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox23 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents RadioFrage As System.Windows.Forms.RadioButton
    Friend WithEvents RadioAchtung As System.Windows.Forms.RadioButton
    Friend WithEvents RadioInformation As System.Windows.Forms.RadioButton
    Friend WithEvents RadioError As System.Windows.Forms.RadioButton
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents gbBypass As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox26 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox19 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents gbSpread As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox27 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox25 As System.Windows.Forms.PictureBox
    Friend WithEvents txtSprelink As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox20 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox21 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox22 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
    Friend WithEvents cbAutostart As System.Windows.Forms.CheckBox
    Friend WithEvents cbDefender As System.Windows.Forms.CheckBox
    Friend WithEvents cbFirewall As System.Windows.Forms.CheckBox
    Friend WithEvents cbUac As System.Windows.Forms.CheckBox
    Friend WithEvents cbSpread As System.Windows.Forms.CheckBox
    Friend WithEvents cbPris As System.Windows.Forms.CheckBox
    Friend WithEvents cbBypass As System.Windows.Forms.CheckBox
    Friend WithEvents cbRoot As System.Windows.Forms.CheckBox
    Friend WithEvents cbIcon As System.Windows.Forms.CheckBox
    Friend WithEvents cbProcess As System.Windows.Forms.CheckBox
    Friend WithEvents cbExe As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiCodes As System.Windows.Forms.CheckBox
    Friend WithEvents cbFakeError As System.Windows.Forms.CheckBox
    Friend WithEvents cbWicenter As System.Windows.Forms.CheckBox
    Friend WithEvents cbRar As System.Windows.Forms.CheckBox
    Friend WithEvents cbLan As System.Windows.Forms.CheckBox
    Friend WithEvents cbP2p As System.Windows.Forms.CheckBox
    Friend WithEvents cbUsb As System.Windows.Forms.CheckBox
    Friend WithEvents cbSkype As System.Windows.Forms.CheckBox
    Friend WithEvents cbMSN As System.Windows.Forms.CheckBox
    Friend WithEvents cbIcq As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiZA As System.Windows.Forms.CheckBox
    Friend WithEvents gbAntiCodes As System.Windows.Forms.GroupBox
    Friend WithEvents cbAntiVM As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiAA As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiNO As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiOP As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiVP As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiVB As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiSN As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiBI As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiKA As System.Windows.Forms.CheckBox
    Friend WithEvents btnMu As System.Windows.Forms.Button
    Friend WithEvents txtKey As System.Windows.Forms.RichTextBox
    Friend WithEvents btnFertig As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PictureBox29 As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents PictureBox28 As System.Windows.Forms.PictureBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents PictureBox33 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox32 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox31 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox30 As System.Windows.Forms.PictureBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents PictureBox34 As System.Windows.Forms.PictureBox

End Class
