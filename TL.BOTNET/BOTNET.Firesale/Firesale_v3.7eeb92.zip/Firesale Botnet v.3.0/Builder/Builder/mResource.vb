﻿Imports System.Text
Imports System.Runtime.InteropServices

Module mResource
    <DllImport("kernel32.dll")> _
    Private Function BeginUpdateResource(ByVal pFileName As String, _
    <MarshalAs(UnmanagedType.Bool)> ByVal bDeleteExistingResources As Boolean) As IntPtr
    End Function

    <DllImport("kernel32.dll")> _
    Private Function UpdateResource(ByVal hUpdate As IntPtr, _
    ByVal lpType As String, ByVal lpName As String, ByVal wLanguage As UShort, ByVal lpData As Byte(), ByVal cbData As UInteger) As Boolean
    End Function

    <DllImport("kernel32.dll")> _
    Private Function EndUpdateResource(ByVal hUpdate As IntPtr, ByVal fDiscard As Boolean) As Boolean
    End Function

    Public Function addResource(ByVal sFilePath As String, ByVal sData As String)
        Dim hResource As IntPtr = BeginUpdateResource(sFilePath, False)
        Dim bData As Byte() = Encoding.Default.GetBytes(sData)
        UpdateResource(hResource, "DATA", "1", 1031, bData, bData.Length)
        EndUpdateResource(hResource, False)
    End Function
End Module