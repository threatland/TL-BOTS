﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("Firesale Botnet v.3.0")> 
<Assembly: AssemblyDescription("Code by Anatoxis")> 
<Assembly: AssemblyCompany("Anatoxis Tools")> 
<Assembly: AssemblyProduct("http://Anatoxis.6x.to/")> 
<Assembly: AssemblyCopyright("Copyright © Anatoxis")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(True)> 

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("677777a8-a107-4ef8-b66a-2ca32a2d394c")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("3.0.0.0")> 
<Assembly: AssemblyFileVersion("3.0.0.0")> 

<Assembly: NeutralResourcesLanguageAttribute("de-DE")> 