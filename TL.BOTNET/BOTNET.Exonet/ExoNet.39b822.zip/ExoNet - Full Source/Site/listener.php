<?php
require_once('classes/class.bots.php');

$checkBots = new checkBots();

echo $checkBots->updateInfo();

?>

