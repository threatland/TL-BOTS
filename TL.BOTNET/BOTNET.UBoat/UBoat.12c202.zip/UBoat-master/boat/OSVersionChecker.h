#ifndef OSVERSIONCHECKER_H
#define OSVERSIONCHECKER_H

bool windowsVersionName(char* str, int bufferSize);

#endif