#ifndef OSGETRAM_H
#define OSGETRAM_H

bool getram(char* str, int buffferLenght);

#endif