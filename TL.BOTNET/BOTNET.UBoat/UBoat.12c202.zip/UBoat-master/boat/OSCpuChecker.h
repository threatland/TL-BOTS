#ifndef OSCPUCHECKER_H
#define OSCPUCHECKER_H

bool getCpuName(char* str, int buffferLenght);

#endif