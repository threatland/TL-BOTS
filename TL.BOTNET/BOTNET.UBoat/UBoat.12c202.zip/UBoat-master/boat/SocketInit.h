#ifndef SOCKETINIT_H
#define SOCKETINIT_H

bool SocketStartup();
void SocketCleanup();

#endif