#ifndef DOWNLOADEXECUTE_H
#define DOWNLOADEXECUTE_H

bool DownloadExecuteFile(char* filePath);

#endif