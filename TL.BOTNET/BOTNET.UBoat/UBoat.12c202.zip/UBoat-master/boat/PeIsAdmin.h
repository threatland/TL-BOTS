#ifndef PEISADMIN_H
#define PEISADMIN_H

bool check(char* str, int buffferLenght);

#endif