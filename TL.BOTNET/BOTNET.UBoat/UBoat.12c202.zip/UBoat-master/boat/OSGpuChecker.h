#ifndef OSGPUCHECKER_H
#define OSGPUCHECKER_H

bool getGpuName(char* str, int buffferLenght);

#endif