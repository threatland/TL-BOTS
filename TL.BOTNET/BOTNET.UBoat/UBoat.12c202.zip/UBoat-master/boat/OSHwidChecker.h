#ifndef OSHWIDCHECKER_H
#define OSHWIDCHECKER_H

bool getHwid(char* str, int bufferSize);

#endif