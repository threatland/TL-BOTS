#ifndef FLOOD_H
#define FLOOD_H

void TCPFlood(char* destination, unsigned short port, int seconds, int timespersecond = 1);

#endif