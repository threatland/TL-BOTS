#ifndef OSNETVERSIONCHECKER_H
#define OSNETVERSIONCHECKER_H

bool getLastestNETinstalled(char* str, int buffferLenght);

#endif