# UBoat HTTP

A POC HTTP Botnet designed to replicate a full weaponised commercial botnet

![](https://image.ibb.co/m5yi9T/spectral_login.png)
![license](https://img.shields.io/badge/license-MIT-brightgreen.svg)
![awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)
![version](https://img.shields.io/badge/version-0.1.0-lightgrey.svg)

## Disclaimer

**This project should be used for authorized testing or educational purposes only.**

**The main objective behind creating this offensive project was to aid security researchers and to enhance the understanding of commercial HTTP loader style botnets . 
I hope this project helps to contribute to the malware research community and people can develop efficient counter mesures :)**

**Usage of uboat without prior mutual consistency can be considered as an illegal activity. It is the final user's responsibility to obey all applicable local, state and federal laws. Authors assume no liability and are not responsible for any misuse or damage caused by this program.**

## What is a Botnet ? 

https://securityaffairs.co/wordpress/13747/cyber-crime/http-botnets-the-dark-side-of-an-standard-protocol.html


**Please don't bother me asking :)**

## Features 

- Coded in C++ with no dependencies
- Encrypted C&C Communications
- Persistence to prevent your control being lost
- Connection Redundancy (Uses a fallback server address or domain )
- DDoS methods (TCP & UDP Flood)
- Task Creation System ( Altering system HWID,Country,IP,OS.System )
- Remote Commands
- Update and Uninstall other malware
- Download and Execute other malware
- Active as well as Passive Keylogger
- Enable Windows RDP
- Plugin system for easy feature updates

## Getting started ? 

- Download the bot from **https://github.com/Souhardya/UBoat/releases**
- Follow the wiki at **https://github.com/Souhardya/UBoat/wiki**

# TODO :- 

- Fix minor panel bugs 
- Make the authentication system more efficient 

## Project maintained by 

- Souhardya Sardar ( Souhardya@protonmail.com) 
- Tuhinshubhra aka r3dhax0r ( https://github.com/Tuhinshubhra )
- Team Virtually Unvoid Defensive ( https://github.com/virtuallyud ) 

__Screens :__ 

![](https://preview.ibb.co/j7frDo/Screenshot_7.png) 
![](https://preview.ibb.co/cwyiR8/Screenshot_8.png)

__Circa__ : **2018** 
