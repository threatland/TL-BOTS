<?php
	setcookie("phash", "");
	header("Location: index.php");
?>