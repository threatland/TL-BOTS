		  __     __        _            _   _ _____ _____
		  \ \   / /__ _ __| |_ _____  _| \ | | ____|_   _|
		   \ \ / / _ \ '__| __/ _ \ \/ /  \| |  _|   | |
		    \ V /  __/ |  | ||  __/>  <| |\  | |___  | |
		     \_/ \___|_|   \__\___/_/\_\_| \_|_____| |_|
		       [From DarkCoderSc Freewares since 2k6]  
		       
This software is free and cannot be sale or modified without the autorisation from the author.
Using this software outside your own network is illegal in most countries so watch your step.

This tool was design for 100% legit remote assistance.

Be sure you download this file from the official website , http://vertexnet-loader.com/ or http://www.opensc.ws/

�����������������
=> Quick Tips: <=
�����������������

Installation (Panel)
--------------------

You must have a FTP and web host that support PHP/MySQL, i recommend you to choose the most simples webhosts that doesn't
contain any subdomains.

- Upload the whole /Panel/*.* in your FTP server.
- Via phpMyAdmin(for example) create a new database (VertexNet for example) then click on SQL menu and past the whole file content
	(/Panel/SQL/vertexnet.sql) in the text area then run the sql. >> The new tables might apear and be ready for use.
	ALT : You can also use the menu import to download your sql file and automatically execute it.
- Then open your chosen url, normally a login page apear by default logins are : 
			>> User : root
			>> Pass : toor
- Enjoy.

Installation (Loader)
---------------------

If you want to start the loader with windows be sure to chose a path that isn't affect by the Windows Account Control (UAC)
Don't use (Windows, System32 for example or it won't install).

I was using VertexNet v1.1.1
----------------------------

It doesn't require an update but you should anyway

My Crypter corrupt the loader
-----------------------------

I hope you don't bought it, cuz the crypter sucks

I'm not receiving any result (POST PACKETS)
-------------------------------------------

You might not use the good web host for this software, switch to a better one (no subdomains) and if you can not shared.
the BEST is to use WAMP/LAMP + VPN/TOR.

For other questions : DarkCoderSc@Unremote.org.

EOF