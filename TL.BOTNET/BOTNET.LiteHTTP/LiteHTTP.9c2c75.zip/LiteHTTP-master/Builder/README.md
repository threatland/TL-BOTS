This is the builder for the bot. Below is a virus scan (created on a non-distributing scanner):<br>
https://spyralscanner.net/result.php?id=SWSkfdj9Ks

Note that the virus scan above is false positives. MSIL.gen and Gen:Variant are detections from programs that "create" malware, not contain it.

Some of the safe scanners you can use (non-distributing) are:<br>
http://nodistribute.com<br>
https://spyralscanner.net<br>
http://alphaproducts.online/?page=scanner<br>
http://avcheck.net - Not free<br>
https://antiscan.me - Not free<br>


If the site you wish to scan at is <b>not</b> listed here, <b>you probably shouldn't use it to scan malware</b>.
