What is it?
-----------
<b>LiteHTTP</b> is an HTTP bot that is being programmed in C#, on the .NET 2.0 dependency.

Expected Features
-----------------

<b>Panel</b>
<ul>
<li>Custom coded with a sleek yet maneuverable design</li>
<li>Ability to have more than 1 user</li>
<li>User privileges</li>
<li>Action logs for all users</li>
</ul>

<b>Bot</b>
<ul>
<li>Download & execute (with option to inject if native)</li>
<li>Visit webpage (visible or hidden)</li>
<li>Startup (with persistence)</li>
<li>Information about bot (aka. OS, version, installed location, etc.)</li>
<li>Basic botkiller (nothing fancy)</li>
<li>Update</li>
<li>Uninstall</li>
</ul>

If you have any questions or concerns, you can email me here: zettabit@pedev.pw
