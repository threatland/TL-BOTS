<?php
    session_start();
    require_once("gdx/internal.php");

    if(isset($_SESSION["GDX_AUTHENTICATION"]) && $_SESSION["GDX_AUTHENTICATION"] == 1)
    {
        header("Location: main.php");
        exit();
    }

    if(isset($_POST["LongIn"]) && isset($_POST["username"]) && isset($_POST["password"]))
    {
        try
        {
            $Host = MYSQL_HOST;
            $Database = DATABASE_NAME;
            $conn = new PDO("mysql:host=$Host;dbname=$Database", MYSQL_USER, MYSQL_PASSWORD);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $ScAdmins = $conn->query("SELECT * FROM Admins");
            $Admins = $ScAdmins->fetch(PDO::FETCH_ASSOC);
            $PwHash = md5($_POST["password"]);
            
            if($_POST["username"] == $Admins["UserName"] && $PwHash == $Admins["PasswordHash"])
            {
                $_SESSION["GDX_AUTHENTICATION"] = 1;
                header("Location: main.php");
                exit();
            }
            else $err = true;
            $conn = null;
        }
        catch(PDOException $e) {
            //echo $e->getMessage();
        }
    }
?>

<!DOCTYPE HTML>
<html>
<head>
    <link href='css/gdx.css' rel='stylesheet' type='text/css'/>
</head>
<body class='login-body'>
    <div class='login-container'>
        <div class='login-inner'>
            <div class='div-form'>
                <div class='login-container'>
                    <div class='login-inner'>
                        <div class='form-login-inner'>
                            <form action='' method='post'>
                                <p class='form-login-label'>UserName: </p>
                                <input class='form-login-ctrl' type='text' name='username'>
                                <br/><br/>
                                <p class='form-login-label'>Password: </p>
                                <input class='form-login-ctrl' type='password' name='password'>
                                <br/><br/>

                                <?php if(isset($err)) 
                                    echo "<p style='width: 100%; text-align: center; color: red'>Invalid username or password</p>"; 
                                ?>

                                <p><br/></p>
                                <input class='form-login-ctrl' type='submit' name='LongIn' value='Login In'>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>