# OrangBotnet
autobotnet testing client

## Mono bug:
https://github.com/dotnet/corefx/issues/19914

Workaround: delete the netstandard `System.Net.Http.dll` until this is resolved.
