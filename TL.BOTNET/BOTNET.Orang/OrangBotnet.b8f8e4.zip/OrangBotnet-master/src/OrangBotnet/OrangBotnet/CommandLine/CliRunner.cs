﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using CommandLine;
using OrangBotnet.Configuration;
using OrangPillars.Client.Modules;
using RestEase;

namespace OrangBotnet.CommandLine {
    public static class CliRunner {
        [Verb("info", HelpText = "show info about saved state")]
        public class InfoOptions {
            [Option('k', "key", Required = false, HelpText = "whether to include the api key")]
            public bool includeKey { get; set; }
        }

        [Verb("auth", HelpText = "authenticate to autobotnet server")]
        public class AuthOptions {
            [Option('u', "username", Required = true)]
            public string username { get; set; }

            [Option('s', "server", Required = true, HelpText = "the http url of the server to connect to")]
            public string server { get; set; }

            [Option('p', "password", Required = false)]
            public string password { get; set; }

            [Option('i', "invite", Required = false)]
            public string invite { get; set; }
        }

        [Verb("shell", HelpText = "some sort of interactive shell")]
        public class ShellOptions {
            // TODO: options
        }

        [Verb("script", HelpText = "manage the script script")]
        public class ScriptOptions {
            [Option('d', "deploy", Required = false, HelpText = "the file to deploy")]
            public string deployFile { get; set; }

            [Option('f', "fetch", Required = false, HelpText = "the file to fetch the script to")]
            public string fetchFile { get; set; }
        }

        public const int ERR_MISCELLANEOUS = -1;
        public const int ERR_INVALID_ARGUMENT = -2;
        public const int ERR_MISSING_ARGUMENT = -3;

        public static async Task<int> infoProgram(InfoOptions opts) {
            var context = OrangContext.ioc.Resolve<OrangContext>();
            Console.WriteLine($"server: {context.configuration.endpoint}");
            Console.WriteLine($"username: {context.configuration.username}");
            if (opts.includeKey) {
                Console.WriteLine($"key: {context.configuration.key}");
            }

            return 0;
        }

        public static async Task<int> authProgram(AuthOptions opts) {
            if (!Uri.IsWellFormedUriString(opts.server, UriKind.Absolute)) {
                return ERR_INVALID_ARGUMENT;
            }

            var context = OrangContext.ioc.Resolve<OrangContext>();
            context.createClient(opts.server);
            var endpoint = new Uri(opts.server);
            context.createClient(endpoint.AbsoluteUri);
            var serverInfo = await context.client.infoModule.api.getInfo();
            if (serverInfo.inviteRequired && string.IsNullOrWhiteSpace(opts.invite)) {
                return ERR_MISSING_ARGUMENT;
            }

            // check username
            UserModule.User user = null;
            try {
                var userInfo = await context.client.userModule.api.getByUsername(opts.username);
                // log in user
                user = await context.client.userModule.api.login(new UserModule.LoginRequest {
                    username = opts.username,
                    password = opts.password
                });
            } catch (ApiException ex) {
                // TODO: Register
                if (ex.StatusCode == HttpStatusCode.NotFound) {
                    // register user
                    user = await context.client.userModule.api.register(new UserModule.RegisterRequest {
                        username = opts.username,
                        password = opts.password,
                        invitekey = opts.invite
                    });
                } else {
                    throw;
                }
            }

            // save user information
            context.client.userModule.api.apikey = user.apikey;
            context.configuration.endpoint = endpoint.AbsoluteUri;
            context.configuration.username = user.username;
            context.configuration.key = user.apikey;
            context.configuration.save();

            // display the information
            Console.WriteLine($"server: {context.configuration.endpoint}");
            Console.WriteLine($"username: {context.configuration.username}");
            Console.WriteLine($"key: {context.configuration.key}");

            return 0;
        }

        public static async Task<int> shellProgram(ShellOptions opts) {
            var context = OrangContext.ioc.Resolve<OrangContext>();
            context.createClient(context.configuration.endpoint);

            if (context.configuration.key == null) {
                Console.WriteLine("no stored authentication information available.");
                return ERR_MISCELLANEOUS;
            }

            var frameStarted = false;

            // start the GUI on an unawaited task

            // connect to the realtime channel
            context.client.channel.auth(context.configuration.key);
            await context.client.channel.connectAsync();
            Console.WriteLine("connected to realtime channel");

            // run a REPL shell
            Console.WriteLine();
            while (true) {
                try {
                    Console.Write("ab$ ");
                    var command = Console.ReadLine();
                    if (command.StartsWith(">")) {
                        var expr = command.Substring(1);
                        var ctokSource = new CancellationTokenSource();
                        ctokSource.CancelAfter(TimeSpan.FromSeconds(1));
                        var result = await context.client.rtConsole.sendCommand(expr, ctokSource.Token);
                        Console.WriteLine($"[js] {result}");
                    } else if (command == "v") {
                        if (frameStarted) {
                            Console.WriteLine("frame already started.");
                        } else {
                            Task.Run(() => GameBootstrapper.Run())
                                .ContinueWith(t => frameStarted = false);
                        } 
                    } else if (command == "q") {
                        break;
                    }
                } catch (TaskCanceledException ex) {
                    Console.WriteLine("[timeout]");
                    throw;
                }
            }

            await context.client.channel.disconnectAsync();
            Console.WriteLine("gracefully disconnected from realtime channel");

            return 0;
        }

        public static async Task<int> scriptProgram(ScriptOptions opts) {
            var context = OrangContext.ioc.Resolve<OrangContext>();
            context.createClient(context.configuration.endpoint);

            context.client.userModule.api.apikey = context.configuration.key;

            if (opts.deployFile != null) {
                var programSource = File.ReadAllText(opts.deployFile);
                await context.client.userModule.api.deployProgram(new UserModule.UserProgram() {
                    source = programSource
                });
            }

            if (opts.fetchFile != null) {
                var programSource = (await context.client.userModule.api.getUserProgram()).source;
                File.WriteAllText(opts.fetchFile, programSource);
            }

            return 0;
        }
    }
}
