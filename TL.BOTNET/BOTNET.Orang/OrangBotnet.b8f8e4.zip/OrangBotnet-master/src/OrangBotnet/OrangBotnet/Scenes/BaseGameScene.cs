﻿using Nez;

namespace OrangBotnet.Scenes {
    public class BaseGameScene : Scene {
        public override void initialize() {
            base.initialize();

            addRenderer(new DefaultRenderer());
        }
    }
}