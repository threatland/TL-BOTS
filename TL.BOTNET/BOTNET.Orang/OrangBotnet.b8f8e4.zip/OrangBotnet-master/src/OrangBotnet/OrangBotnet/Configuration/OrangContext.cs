﻿using System;
using System.IO;
using CookieIoC;
using Newtonsoft.Json;
using OrangPillars.Client;

namespace OrangBotnet.Configuration {
    public class OrangContext {
        public OrangContext(OrangConfiguration config) {
            configuration = config;
            if (!string.IsNullOrEmpty(configuration.endpoint)) {
                createClient(configuration.endpoint);
            }
        }

        public OrangConfiguration configuration { get; private set; }

        public static CookieJar ioc = new CookieJar();

        public void createClient(string endpoint) {
            client = new SpeercsClient(endpoint);
        }

        public SpeercsClient client { get; private set; }
    }

    public class OrangConfiguration {
        public string username { get; set; }
        public string key { get; set; }
        public string endpoint { get; set; }
        
        public static readonly string configFilePath =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "./OrangPillars/config.json");

        public void save() {
            File.WriteAllText(configFilePath, JsonConvert.SerializeObject(this, Formatting.Indented));
        }

        public bool savedAvailable() {
            return !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(endpoint);
        }
    }
}