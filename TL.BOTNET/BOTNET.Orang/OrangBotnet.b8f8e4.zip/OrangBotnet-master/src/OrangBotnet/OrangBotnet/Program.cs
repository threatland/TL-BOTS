﻿using System;
using System.IO;
using System.Threading.Tasks;
using CommandLine;
using Newtonsoft.Json;
using OrangBotnet.CommandLine;
using OrangBotnet.Configuration;

namespace OrangBotnet {
    public static class Program {
        public static async Task<int> Main(string[] args) {
//            Console.WriteLine(@"
//OrangBotnet Multitool AutoBotnet Client
//Copyright (c) 2018 Nihal Talur (0xFireball).
//This program is free software licensed under the GPLv3.
//");
            loadContext();

            var parserResult =
                Parser.Default.ParseArguments(args, new[] {
                    typeof(CliRunner.AuthOptions), typeof(CliRunner.ShellOptions), typeof(CliRunner.InfoOptions),
                    typeof(CliRunner.ScriptOptions)
                });
            var parsedArgs = (parserResult as Parsed<object>)?.Value;
            var result = -1;
            switch (parsedArgs) {
                case CliRunner.InfoOptions infoOptions:
                    result = await CliRunner.infoProgram(infoOptions);
                    break;
                case CliRunner.AuthOptions authOptions:
                    result = await CliRunner.authProgram(authOptions);
                    break;
                case CliRunner.ShellOptions shellOptions:
                    result = await CliRunner.shellProgram(shellOptions);
                    break;
                case CliRunner.ScriptOptions scriptOptions:
                    result = await CliRunner.scriptProgram(scriptOptions);
                    break;
            }

            return result;
        }

        private static void loadContext() {
            // create a context
            OrangConfiguration config = null;
            if (File.Exists(OrangConfiguration.configFilePath)) {
                config = JsonConvert.DeserializeObject<OrangConfiguration>(
                    File.ReadAllText(OrangConfiguration.configFilePath));
            } else {
                config = new OrangConfiguration();
                var configContents = JsonConvert.SerializeObject(config, Formatting.Indented);
                Directory.CreateDirectory(Path.GetDirectoryName(OrangConfiguration.configFilePath));
                File.WriteAllText(OrangConfiguration.configFilePath, configContents);
            }

            var appContext = new OrangContext(config);
            OrangContext.ioc.Register<OrangContext>(appContext);
        }
    }
}