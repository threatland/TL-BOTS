﻿using Glint;

namespace OrangBotnet {
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class NGame : GlintCore {
        public NGame() : base(width: 1080, height: 608, windowTitle: "OrangBotnet") { }

        protected override void Initialize() {
            base.Initialize();
        }
    }
}