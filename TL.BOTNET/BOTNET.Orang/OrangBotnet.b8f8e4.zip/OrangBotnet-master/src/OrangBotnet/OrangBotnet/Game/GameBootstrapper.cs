﻿namespace OrangBotnet {
    public static class GameBootstrapper {
        public static void Run() {
            var game = new NGame();
            game.Run();
            game.Dispose();
        }
    }
}