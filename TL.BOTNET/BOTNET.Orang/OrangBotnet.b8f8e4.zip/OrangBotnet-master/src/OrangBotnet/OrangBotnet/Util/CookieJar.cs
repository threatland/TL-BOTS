﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

// ReSharper disable once CheckNamespace
namespace CookieIoC {
    /// <summary>
    /// IoC container
    /// </summary>
    public class CookieJar {
        private List<Tuple<Type, object>> instanceRegistry = new List<Tuple<Type, object>>();
        private List<Tuple<Type, Type>> factoryRegistry = new List<Tuple<Type, Type>>();

        /// <summary>
        /// Register an instance into the container
        /// </summary>
        /// <typeparam name="T">The type to associate the instance with</typeparam>
        /// <param name="instance">The instance to register</param>
        /// <returns></returns>
        public T Register<T>(object instance) {
            // Register
            instanceRegistry.Add(new Tuple<Type, object>(typeof(T), instance));
            return (T) instance;
        }

        public void RegisterFactory<TRegistration, TType>() {
            if (!typeof(TRegistration).GetTypeInfo().IsAssignableFrom(typeof(TType).GetTypeInfo())) {
                throw new ArgumentOutOfRangeException("The target type must be assignable to the registration type.");
            }

            factoryRegistry.Add(new Tuple<Type, Type>(typeof(TRegistration), typeof(TType)));
        }

        /// <summary>
        /// Retrieve all registered instances that can be assigned to the requested type
        /// </summary>
        /// <typeparam name="T">The requested type</typeparam>
        /// <returns></returns>
        public IEnumerable<T> ResolveAll<T>() {
            return instanceRegistry.Where(x => typeof(T).GetTypeInfo().IsAssignableFrom(x.Item1.GetTypeInfo()))
                .Select(x => x.Item2)
                .Cast<T>();
        }

        /// <summary>
        /// Retrieve the first registered instance that can be assigned to the requested type
        /// </summary>
        /// <typeparam name="T">The requested type</typeparam>
        /// <returns></returns>
        public T Resolve<T>() {
            return ResolveAll<T>().FirstOrDefault();
        }

        public T Create<T>() {
            var creationType = factoryRegistry
                .Where(x => typeof(T).GetTypeInfo().IsAssignableFrom(x.Item2.GetTypeInfo()))
                .Select(x => x.Item2)
                .FirstOrDefault();
            return (T) Activator.CreateInstance(creationType);
        }

        /// <summary>
        /// Retrieve the last registered instance that can be assigned to the requested type
        /// </summary>
        /// <typeparam name="T">The requested type</typeparam>
        /// <returns></returns>
        public T ResolveLast<T>() {
            return ResolveAll<T>().LastOrDefault();
        }
    }
}