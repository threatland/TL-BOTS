<?php
@session_start();
unset($_SESSION['login']);
@session_destroy();
echo "<script type='text/javascript'>document.location = './';</script>\n";
?>