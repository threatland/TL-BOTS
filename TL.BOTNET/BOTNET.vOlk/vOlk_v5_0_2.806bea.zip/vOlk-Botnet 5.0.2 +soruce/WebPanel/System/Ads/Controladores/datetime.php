<?php 
date_default_timezone_set('America/Lima');
date_default_timezone_set('GMT-5');
echo date('Ymdhisa'); 
?>