<?php
$datos = array(
'server' => 'localhost' ,
'user' => 'root' ,
'pass' => 'volk2288' ,
'db' => 'volk502'
) ;
$DB = new BaseDeDatos( $datos , 'mysql') ;
date_default_timezone_set('America/Lima');
date_default_timezone_set('GMT-5');

?>