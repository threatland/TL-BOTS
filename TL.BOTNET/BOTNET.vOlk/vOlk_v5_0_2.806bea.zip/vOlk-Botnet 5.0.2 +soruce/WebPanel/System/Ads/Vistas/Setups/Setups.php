<?php
@session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }
require_once('../../includes.php');
require_once("../../Configs/Pass.php");


?>
<h2><font face="Tahoma" size="4" color="#666666">Administrator</font></h2>
<font face="Tahoma" size="1">
<div id='mensajebot' name='mensajebot' align='center' style="color:#FF0000"></div>
</font>
<form id='frm_findinfo'>
<form method="POST" action="">
<table width='100%' border='1' cellpadding='3' style='font-size: 9px; border-collapse: collapse; background-color: #000000;' background="archivos/imagen/bg.gif" bordercolor="#666666">
<tr>
	<td width='150px' align='left'><b>
	<font face="Tahoma" size="1" color="#666666">Login IP</font></b><font color="#666666" face="Tahoma"><b><font size="1">: </font></b></font></td>
	<td align='left'><div>
<b>
</font>
</b>
<span style="margin-left:0px; font-weight:700">

<label>
<font color="#FF0000" face="Tahoma" size="1"><?php echo $_SERVER[REMOTE_ADDR] ?>
</font>
</label>
</span>
</div></td>
</tr>
<tr>
	<td align='left' colspan="2"><div>
<p align="center">
<span style="margin-left:0px" id="table_estadisticas" >
<!--  -->

</span>

<div  align="center">

<p><br>
&nbsp;<table width="100%" height="40" background="archivos/bg.gif" style="border-style:solid; border-width:1px; border-collapse:collapse">




<tr>
	<td width='30%' height="19" align='left' bgcolor="#333333">
	<font face="Verdana" size="1" color="#FFFFFF">User Administrator  :</font></td>
	<td align='left' width="70%" bgcolor="#333333"><div>
<span style="margin-left:0px" name="div_1_mensaje" id="div_1_mensaje">
<font size="1" face="Verdana">
<input type="text" style="border:1px solid #000000; width: 300px; font-family:Verdana; font-size:8pt; color:#666666; background-color:#000000" value="<?php echo ADMIN_USUARIO ; ?>" disabled="disabled" name="User" id="User" size="1" />
</font></span>
</div></td>
</tr>



<tr>
	<td width='30%' height="19" align='left' bgcolor="#333333"><font face="Verdana" size="1" color="#FFFFFF">Password Administrator :</font></td>
	<td align='left' width="70%" bgcolor="#333333">
<span style="margin-left:0px" name="div_segundos" id="div_segundos">
<font size="1" face="Verdana">
<input name="Pasw" id="Pasw" type="password" style="border:1px solid #000000; width: 300px; font-family:Verdana; font-size:8pt; color:#666666; background-color:#000000" value="<?php echo ADMIN_PASSWORD ; ?>" size="70" /></font></span></td>
</tr>

   

</table>

<p></div></td>
</tr>



<tr>
	<td align='left' colspan="2">





<font size="1" face="Verdana">
    <input type="button" value='Saved Settings' onclick="SaveUser();" style="font-family: Verdana; font-size: 8pt; color: #666666; border: 1px solid #000000; background-color: #000000" ></font></td>
</tr>



<table>

</form>



<hr size='1' color='#666666'>