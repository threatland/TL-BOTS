<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<h2><font face="Tahoma" size="4" color="#666666"><b>FileZilla Stealer</b>
</font></h2>

<form id='frm_findinfo'>

<table width='100%' border='1' cellpadding='3' style='font-size: 9px; border-collapse: collapse; background-color: #000000;' background="archivos/imagen/bg.gif" bordercolor="#666666">
<tr>
	<td width='150px' align='left'><font color="#666666" face="Tahoma"><b>
	<font size="1">Select</font><font size="1"> Country:</font></b></font><font size="2"></td>
	<td align='left'><div>
</font>
<span style="margin-left:0px">

<label>
<font color="#666666" face="Tahoma">
<font size="1">
<?php require_once('../../Vistas/FileZilla/SelectPais.php') ; ?>
</font>
</font>
</label>
</span>
</div></td>
</tr>
<tr>
	<td align='left' colspan="2"><div>
<p align="center">
<span style="margin-left:0px" >
<!--  -->
<textarea name="table_estadisticas" cols="70" rows="8" id="table_estadisticas" style="border:1px solid #000000; width: 820; height:196; font-family:Tahoma; color:#666666; font-size:8pt; background-color:#000000" ></textarea>

</span>
</div></td>
</tr>



<tr>
	<td align='left' colspan="2"><font color="#666666" face="Arial" size="1"><a href="#" onclick="ExportarFTP();">
	<font color="#CC0000">Exportar FTP's</font></a></font></td>
</tr>



<table>

</form>



<hr size='1' color='#666666'>

<div id='mensajebot' name='mensajebot' align='center' style="color:#FF0000"></div>