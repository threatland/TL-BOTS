<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<h2><font face="Tahoma" size="4" color="#666666"><b>Statistics bots</b>
</font></h2>

<form id='frm_findinfo'>

<table width='100%' border='1' cellspacing='0' cellpadding='3' style='font-size: 9px; border-collapse: collapse; background-color: #000000' background="archivos/imagen/bg.gif">
<tr>
	<td width='150px' align='left'><b>
	<font color="#666666" face="Tahoma" size="1">Select Country:</font></b></td>
	<td align='left'><div>
<span style="margin-left:0px">

<label>
<?php require_once('../../Vistas/Estadisticas/SelectPais.php') ; ?>
</label>
</span>
</div></td>
</tr>

<table>

</form>

<div id="table_estadisticas" name="table_estadisticas" >

</div>


<hr size='1' color='#666666'>

<div id='mensajebot' name='mensajebot' align='center' style="color:#FF0000"></div>