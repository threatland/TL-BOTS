<?php @session_start(); if ( !isset($_SESSION['login']) ){ header ("Location: ../../");  exit() ; }	?>
<?php
require_once('../../includes.php');
$Pais = $DB->Select("SELECT DISTINCT pais FROM zombis WHERE pais!=''");

for($i=0; $i<count($Pais); $i++){
	$Paises .= '<option onclick="Estadisticasbots(\''.$Pais[$i]['pais'].'\')">'.$Pais[$i]['pais'].'</option>' ;
}


$Vacio = $DB->Select("SELECT * FROM zombis WHERE pais IS NULL");
if( count($Vacio) > 0 ){
	$Paises .= '<option value="" onclick="Estadisticasbots(\'Unknown\')">Unknown</option>' ;
}




?>
<select name="pais" id="pais" style="font-family: Tahoma; font-size: 8pt; color: #666666; border: 1px dotted #000000; background-color: #000000" size="1">
  <option selected="selected">Seleccione un Pais</option>
  <?php echo $Paises ; ?>
</select>