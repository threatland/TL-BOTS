import sys,binascii
 
def insert_slashx(string, every=2):
        return '\\x'.join(string[i:i+every] for i in xrange(0, len(string), every))
 
def splitCount(s,count):
        return [''.join(x) for x in zip(*[list(s[z::count]) for z in range(count)])]
 
dogs = '\\x'+insert_slashx(binascii.hexlify(open(sys.argv[1]).read()))
dingle = '","'.join(splitCount(dogs,(128*4))) + '"'
 
print '"'+dingle
