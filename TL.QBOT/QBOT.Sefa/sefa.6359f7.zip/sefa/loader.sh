gcc -static -O3 -lpthread -pthread ~/loader/src/*.c -o ~/load
rm -rf loader