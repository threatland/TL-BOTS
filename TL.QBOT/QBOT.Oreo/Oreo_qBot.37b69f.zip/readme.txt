Ok i made this when i was bored intended to be for personal use
Prob one of the best simple qbots out there if not the best.
Qbot is shit anyway why tf are you using it.
Made by Scarface#1162
Now i release and provide a list of features

- WATCHDOG KEEP-ALIVE
- HTTPHEX
- HTTP
- STD
- VSE
- FLUX
- UDP
- TCP (ALL-SYN-RST-FIN-ACK-PSH)