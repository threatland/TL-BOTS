 __   __ _          _          ____          _     _    _                                       _  _            _  __      __          _                      __  ____    __  __ 
 \ \ / /| |        (_)        |  _ \        | |   | |  | |                                     (_)| |          | | \ \    / /         (_)                    /_ ||___ \  /_ |/_ |
  \ V / | |_  _ __  _   __ _  | |_) |  ___  | |_  | |  | | _ __    ___  ___   _ __ ___   _ __   _ | |  ___   __| |  \ \  / /___  _ __  _  ___   ___   _ __    | |  __) |  | | | |
   > <  | __|| '__|| | / _` | |  _ <  / _ \ | __| | |  | || '_ \  / __|/ _ \ | '_ ` _ \ | '_ \ | || | / _ \ / _` |   \ \/ // _ \| '__|| |/ __| / _ \ | '_ \   | | |__ <   | | | |
  / . \ | |_ | |   | || (_| | | |_) || (_) || |_  | |__| || | | || (__| (_) || | | | | || |_) || || ||  __/| (_| |    \  /|  __/| |   | |\__ \| (_) || | | |  | | ___) |_ | | | |
 /_/ \_\ \__||_|   |_| \__,_| |____/  \___/  \__|  \____/ |_| |_| \___|\___/ |_| |_| |_|| .__/ |_||_| \___| \__,_|     \/  \___||_|   |_||___/ \___/ |_| |_|  |_||____/(_)|_| |_|
                                                                                        | |                                                                                      
                                                                                        |_|                                                                                      



   _  _  __   __ _          _        
  _| || |_\ \ / /| |        (_)       
 |_  __  _|\ V / | |_  _ __  _   __ _ 
  _| || |_  > <  | __|| '__|| | / _` |
 |_  __  _|/ . \ | |_ | |   | || (_| |
   |_||_| /_/ \_\ \__||_|   |_| \__,_|


Cracked Xtria botnet by Drinkz and my 100 other accounts. (Latest verison) 
Uncompiled verison
If you have the slightest idea of
how C++ Works you will be able to
compile all 3 srcs and install the botnet
No this isn't some garbage .c file where you just edit out your "IRC" info and then start scanning. Work it out.
---------------------
FAQ:Why are these files uncompiled: Because you need to learn.
   Will you help set this up for me?: If you're arent some little kid who uses a Torlus P2P Botnet and brags, and really wants to learn more then yes i will help you and teach you
   What is the max attack peak with this: Depends on the amount of bots you obtain, but it's 1000x more power then any router bot you've ever used
   Are the methods C+P'D from pastebin?: No this is not using litespeeds garbage udp/tcp source kids have been using on sst and only replacing the payload+port with for 100 years
   
If you sucessfully set this up enjoy null routing everything