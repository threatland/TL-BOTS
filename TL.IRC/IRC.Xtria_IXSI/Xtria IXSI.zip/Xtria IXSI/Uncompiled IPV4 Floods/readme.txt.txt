In the autorun/Config
if you can't find it contact 