#pragma once

#define HTTP_SERVER "209.141.34.89"
#define HTTP_PORT 80

#define TFTP_SERVER "209.141.34.89"
