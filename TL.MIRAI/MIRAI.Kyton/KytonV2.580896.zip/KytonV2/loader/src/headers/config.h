#pragma once

#define HTTP_SERVER "87.251.82.210"
#define HTTP_PORT 80

#define TFTP_SERVER "87.251.82.210"
