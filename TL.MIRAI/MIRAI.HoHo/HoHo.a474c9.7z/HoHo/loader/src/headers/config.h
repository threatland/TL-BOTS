#pragma once

#define HTTP_SERVER "185.244.25.180"
#define HTTP_PORT 80

#define TFTP_SERVER "185.244.25.180"
