#!/bin/bash
gcc -static -O3 -lpthread -pthread s/*.c -o l