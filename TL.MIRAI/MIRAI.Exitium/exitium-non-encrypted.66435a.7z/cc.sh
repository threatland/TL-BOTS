#!/bin/bash
mkdir /etc/xcompile
cd /etc/xcompile 
echo "downloading the needed bins"
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-i586.tar.bz2
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-m68k.tar.bz2
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-mips.tar.bz2
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-mipsel.tar.bz2
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-powerpc.tar.bz2
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-sh4.tar.bz2
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-sparc.tar.bz2
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-armv4l.tar.bz2
wget https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-armv5l.tar.bz2
wget http://distro.ibiblio.org/slitaz/sources/packages/c/cross-compiler-armv6l.tar.bz2
wget https://landley.net/aboriginal/downloads/old/binaries/1.2.6/cross-compiler-armv7l.tar.bz2
echo "downloaded needed bins"
echo "gona untar em now plz wait"
echo "1"
tar -jxf cross-compiler-i586.tar.bz2
echo "2"
tar -jxf cross-compiler-m68k.tar.bz2
echo "3"
tar -jxf cross-compiler-mips.tar.bz2
echo "4"
tar -jxf cross-compiler-mipsel.tar.bz2
echo "5"
tar -jxf cross-compiler-powerpc.tar.bz2
echo "6"
tar -jxf cross-compiler-sh4.tar.bz2
echo "7"
tar -jxf cross-compiler-sparc.tar.bz2
echo "8"
tar -jxf cross-compiler-armv4l.tar.bz2
echo "9"
tar -jxf cross-compiler-armv5l.tar.bz2
echo "10"
tar -jxf cross-compiler-armv6l.tar.bz2
echo "11"
tar -jxf cross-compiler-armv7l.tar.bz2
echo "dam that took a while"
rm -rf *.tar.bz2
mv cross-compiler-i586 i586
mv cross-compiler-m68k m68k
mv cross-compiler-mips mips
mv cross-compiler-mipsel mipsel
mv cross-compiler-powerpc powerpc
mv cross-compiler-sh4 sh4
mv cross-compiler-sparc sparc
mv cross-compiler-armv4l armv4l
mv cross-compiler-armv5l armv5l
mv cross-compiler-armv6l armv6l
mv cross-compiler-armv7l armv7l
rm -rf *.tar.bz2
echo "stage 2 of the exotic toolchains this might take a whole lot longer"
echo "downloading the exotic bins now this might take very long say thanks to Quincy for this kind of efort"

wget dec10.000webhostapp.com/cross-compilers/aarch64be.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/aarch64.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/arcle-750d.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/arcle-hs38.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/armebv7-eabihf.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/armv5-eabi.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/armv6-eabihf.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/armv7-eabihf.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/armv7m.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/bfin.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/m68k-68xxx.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/m68k-coldfire.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/microblazebe.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/microblazeel.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/mips32el.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/mips32r5el.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/mips32r6el.tar.bz2
wget dec10.000webhostapp.com/cross-compilers/mips32.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/mips32r6el.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/mips64el-n32.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/mips64-n32.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/mips64r6el-n32.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/nios2.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/openrisc.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/powerpc64-e5500.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/powerpc64le-power8-.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/powerpc-e500mc.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/riscv64.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/sh-sh4aeb.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/sh-sh4.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/sparc64.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/sparcv8.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/x86-64-core-i7.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/x86-core2.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/x86-i686.tar.bz2
wget darker-than-dak-ever-will-get.ga/cross-compilers/xtensa-lx60.tar.bz2
echo "done downloading the exotic bins say thanks to Quincy for this efort"
echo "gona untar em now plz wait"
echo "1"
tar -jxf aarch64be.tar.bz2
echo "2"
tar -jxf aarch64.tar.bz2
echo "3"
tar -jxf arcle-750d.tar.bz2
echo "4"
tar -jxf arcle-hs38.tar.bz2
echo "5"
tar -jxf armebv7-eabihf.tar.bz2
echo "6"
tar -jxf armv5-eabi.tar.bz2
echo "7"
tar -jxf armv6-eabihf.tar.bz2
echo "8"
tar -jxf armv7-eabihf.tar.bz2
echo "9"
tar -jxf armv7m.tar.bz2
echo "10"
tar -jxf bfin.tar.bz2
echo "11"
tar -jxf m68k-68xxx.tar.bz2
echo "12"
tar -jxf m68k-coldfire.tar.bz2
echo "13"
tar -jxf microblazebe.tar.bz2
echo "14"
tar -jxf microblazeel.tar.bz2
echo "15"
tar -jxf mips32el.tar.bz2
echo "16"
tar -jxf mips32r5el.tar.bz2
echo "17"
tar -jxf mips32r6el.tar.bz2
echo "18"
tar -jxf mips32.tar.bz2
echo "19"
tar -jxf mips64el-n32.tar.bz2
echo "20"
tar -jxf mips64-n32.tar.bz2
echo "21"
tar -jxf mips64r6el-n32.tar.bz2
echo "22"
tar -jxf nios2.tar.bz2
echo "23"
tar -jxf openrisc.tar.bz2
echo "24"
tar -jxf powerpc64-e5500.tar.bz2
echo "25"
tar -jxf powerpc64le-power8-.tar.bz2
echo "26"
tar -jxf powerpc-e500mc.tar.bz2
echo "27"
tar -jxf riscv64.tar.bz2
echo "28"
tar -jxf sh-sh4aeb.tar.bz2
echo "29"
tar -jxf sh-sh4.tar.bz2
echo "30"
tar -jxf sparc64.tar.bz2
echo "31"
tar -jxf sparcv8.tar.bz2
echo "32"
tar -jxf x86-64-core-i7.tar.bz2
echo "33"
tar -jxf x86-core2.tar.bz2
echo "34"
tar -jxf x86-i686.tar.bz2
echo "35"
tar -jxf xtensa-lx60.tar.bz2
echo "dam that did take hella long sorry for that"

mv aarch64be--uclibc--stable-2018.11-1 aarch64be
mv aarch64--uclibc--stable-2018.11-1 aarch64
mv arcle-750d--uclibc--stable-2018.11-1 arcle-750d
mv arcle-hs38--uclibc--stable-2018.11-1 arcle-hs38
mv armebv7-eabihf--uclibc--stable-2018.11-1 armebv7-eabihf
mv armv5-eabi--uclibc--stable-2018.11-1 armv5-eabi
mv armv6-eabihf--uclibc--stable-2018.11-1 armv6-eabihf
mv armv7-eabihf--uclibc--stable-2018.11-1 armv7-eabihf
mv armv7m--uclibc--stable-2018.11-1 armv7m
mv bfin--uclibc--stable-2018.02-2 bfin
mv m68k-68xxx--uclibc--stable-2018.11-1 m68k-68xxx
mv m68k-coldfire--uclibc--stable-2018.11-1 m68k-coldfire
mv microblazebe--uclibc--stable-2018.11-1 microblazebe
mv microblazeel--uclibc--stable-2018.11-1 microblazeel
mv mips32el--uclibc--stable-2018.11-1 mips32el
mv mips32r5el--uclibc--stable-2018.11-1 mips32r5el
mv mips32r6el--uclibc--stable-2018.11-1 mips32r6el
mv mips32--uclibc--stable-2018.11-1 mips32
mv mips64el-n32--uclibc--stable-2018.11-1 mips64el-n32
mv mips64-n32--uclibc--stable-2018.11-1 mips64-n32
mv mips64r6el-n32--uclibc--stable-2018.11-1 mips64r6el-n32
mv nios2--glibc--stable-2018.11-1 nios2
mv openrisc--uclibc--stable-2018.11-1 openrisc
mv powerpc64-e5500--glibc--stable-2018.11-1 powerpc64-e5500
mv powerpc64le-power8--glibc--stable-2018.11-1 powerpc64le-power8
mv powerpc-e500mc--uclibc--stable-2018.11-1 powerpc-e500mc
mv riscv64--glibc--bleeding-edge-2018.11-1 riscv64
mv sh-sh4aeb--glibc--stable-2018.11-1 sh-sh4aeb
mv sh-sh4--uclibc--stable-2018.11-1 sh-sh4
mv sparc64--glibc--stable-2018.11-1 sparc64
mv sparcv8--uclibc--stable-2018.11-1 sparcv8
mv x86-64-core-i7--uclibc--stable-2018.11-1 x86-64-core-i7
mv x86-core2--uclibc--stable-2018.11-1 x86-core2
mv x86-i686--uclibc--stable-2018.11-1 x86-i686
mv xtensa-lx60--uclibc--stable-2018.11-1 xtensa-lx60
echo "removing junk files"
rm -rf *.tar.bz2
echo "all done enjoy the way of tool chains rep the world"