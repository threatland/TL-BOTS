#ifdef xrep

// scanner addvanced switch case writen by c99 
#include "h/scanner_case.h"
#ifdef linksys
#include "h/linksys_scanner.h"
#endif
#ifdef realtek
#include "h/realtek_scanner.h"
#endif
#ifdef gpon80
#include "h/gpon80_scanner.h"
#endif
#ifdef dlink
#include "h/dlink_scanner.h"
#endif
#ifdef adb
#include "h/adb_scanner.h"
#endif
#ifdef huawei
#include "h/huawei_scanner.h"
#endif

#ifdef tellynet
void tellynet_case(void)
{
#ifdef DEBUG
printf("[tellynet_scanner] initalizing case 1\n");
#endif
tellynet_scanner();
}
#endif

#ifdef huawei
void huawei_case(void)
{
#ifdef DEBUG
printf("[huawei_scanner] initalizing case 2\n");
#endif
huawei_scanner();
}
#endif

#ifdef dlink
void dlink_case(void)
{
#ifdef DEBUG
printf("[dlink_scanner] initalizing scanner case 3\n");
#endif
dlink_scanner();
}
#endif

#ifdef gpon80
void gpon80_case(void)
{
#ifdef DEBUG
printf("[gpon80_scanner] initalizing scanner case 4\n");
#endif
gpon80_scanner();
}
#endif

#ifdef linksys
void linksys_case(void)
{
#ifdef DEBUG
printf("[linksys_scanner] initalizing scanner case 5\n");
#endif
linksys_scanner();
}
#endif


#ifdef realtek
void realtek_case(void)
{
#ifdef DEBUG
printf("[realtek_scanner] initalizing scanner case 6\n");
#endif
realtek_scanner();
}
#endif

#ifdef adb
void adb_case(void)
{
#ifdef DEBUG
printf("[adb_scanner] initalizing scanner case 7\n");
#endif
adb_scanner();
}
#endif

#ifdef tellynet_kill
void tellynet_case_kill(void)
{
#ifdef DEBUG
printf("[tellynet_scanner] initalizing case 1\n");
#endif
tellynet_scanner_kill();
}
#endif

#ifdef huawei_kill
void huawei_case_kill(void)
{
#ifdef DEBUG
printf("[huawei_scanner] initalizing case 2\n");
#endif
huawei_scanner_kill();
}
#endif

#ifdef dlink_kill
void dlink_case_kill(void)
{
#ifdef DEBUG
printf("[dlink_scanner] initalizing scanner case 3\n");
#endif
dlink_scanner_kill();
}
#endif

#ifdef gpon80_kill
void gpon80_case_kill(void)
{
#ifdef DEBUG
printf("[gpon80_scanner] initalizing scanner case 4\n");
#endif
gpon80_scanner_kill();
}
#endif

#ifdef linksys_kill
void linksys_case_kill(void)
{
#ifdef DEBUG
printf("[linksys_scanner] initalizing scanner case 5\n");
#endif
linksys_scanner_kill();
}
#endif


#ifdef realtek_kill
void realtek_case_kill(void)
{
#ifdef DEBUG
printf("[realtek_scanner] initalizing scanner case 6\n");
#endif
realtek_scanner_kill();
}
#endif

#ifdef adb_kill
void adb_case_kill(void)
{
#ifdef DEBUG
printf("[adb_scanner] initalizing scanner case 7\n");
#endif
adb_scanner_kill();
}
#endif

#endif
