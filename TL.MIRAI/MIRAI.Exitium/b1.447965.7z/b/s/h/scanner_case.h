#ifdef xrep
void huawei_case();
void dlink_case();
void realtek_case();
void adb_case();
void linksys_case();
void gpon80_case();
#endif
#ifdef kill_scanner_cases
void huawei_case_kill();
void dlink_case_kill();
void realtek_case_kill();
void adb_case_kill();
void linksys_case_kill();
void gpon80_case_kill();
void tellynet_case_kill();
#endif