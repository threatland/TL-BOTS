#pragma once

#define HTTP_SERVER "159.65.82.169"
#define HTTP_PORT 80

#define TFTP_SERVER "159.65.82.169"
