#pragma once

#define HTTP_SERVER "107.173.240.196"
#define HTTP_PORT 80

#define TFTP_SERVER "107.173.240.196"
