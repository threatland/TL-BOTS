#include <stdio.h>
void lockdown();