#pragma once

#define HTTP_SERVER "194.99.21.173"
#define HTTP_PORT 80

#define TFTP_SERVER "194.99.21.173"
