#pragma once

#define HTTP_SERVER "128.199.202.24"
#define HTTP_PORT 80

#define TFTP_SERVER "128.199.202.24"
